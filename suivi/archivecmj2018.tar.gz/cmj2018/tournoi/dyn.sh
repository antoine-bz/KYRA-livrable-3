# Lancer la commande "source dyn.sh" dans le répertoire tournoi
# avant de lancer les programmes moteur et joueur 

export LD_LIBRARY_PATH=$(pwd)/lib
