#! /bin/sh 

#	./joueur$numJ.exe "Joueur $numJ" &

./1-wololo.exe "Wololo" &
sleep 2
./3-anonyme.exe "JoueurOp" &
sleep 2
./5-anonyme.exe "Floyd" &
sleep 2
./8-naysson.exe "Naysson" &
