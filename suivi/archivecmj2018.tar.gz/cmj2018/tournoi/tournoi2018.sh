#! /bin/sh 

#	./joueur$numJ.exe "Joueur $numJ" &

./1-wololo.exe "Wololo" &
sleep 2
./2-marodJathon.exe "MarodJathon" &
sleep 2
./3-anonyme.exe "JoueurOp" &
sleep 2
./4-picsou.exe "Picsou" &
sleep 2
./5-anonyme.exe "Floyd" &
sleep 2
./6-emilia.exe "Emilia" &
sleep 2
./7-tekyns.exe "Tekyns" &
sleep 2
./8-naysson.exe "Naysson" &
sleep 2
./9-minimalgache.exe "Minimalgache" &
sleep 2
./10-billy.exe "Billy" &
sleep 2
./11-anonyme.exe "Anonyme11" &
sleep 2
./12-anonyme.exe "Anonyme12" &
sleep 2
./13-bob.exe "Bob" &
sleep 2
./14-theRock.exe "TheRock" &
sleep 2
./15-marttige.exe "Marttige" &
