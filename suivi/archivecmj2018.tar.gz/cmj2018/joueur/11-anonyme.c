/********* Moteur de tournoi : joueur ***************/

#include <stdio.h>
#include <stdlib.h>
#include "avalam.h"
#include "moteur.h"
#include <string.h>

/** Dans les commentaires des différentes stratégies, on emploiera la notation
 *  suivante : "le pion(d)" pour le pion de destination d'un coup et "le pion(o)"
 *  pour le pion à l'origine d'un coup.
 */

void choisirCoup(T_Position currentPosition, T_ListeCoups listeCoups) {


	octet o, d, o2, d2, o3, d3;
	int a;
    int i,j,l;
    int k =0;

	octet myColor = currentPosition.trait;

    T_Voisins v;

    /*for(i=0;i<listeCoups.nb; i++) {
        o = listeCoups.coups[i].origine;
        d = listeCoups.coups[i].destination;

        v = getVoisins(o);

        k = 0;

        // on compte le nombre de voisins du pion(d)
        for (j = 0; j < v.nb; j++) {
            if (currentPosition.cols[v.cases[j]].couleur != myColor) k++;
        }

        if((currentPosition.cols[o].couleur != myColor) && (k==0)){
            printf("EVITER DE FAIRE DE LA MERDE");
            ecrireIndexCoup(j);
            return;
        }
    }*/
    /**  STRATÉGIE N°1 : LES ÉLOIGNEMENTS
     *          - isoler un pion de notre couleur s'il n'a qu'un seul voisin
     *              -> éloigner ce voisin sur un pion de couleur adverse
     *              -> sinon sur un pion de notre couleur
     *          - déplacer un pion de notre couleur sur un pion adverse isolé
     */

    for(i=0;i<listeCoups.nb; i++) {
        o = listeCoups.coups[i].origine;
        d = listeCoups.coups[i].destination;

        v = getVoisins(d);

        k = 0;

        // on compte le nombre de voisins du pion(d)
        for (j = 0; j < v.nb; j++) {
            if (currentPosition.cols[v.cases[j]].nb != 0) k++;
        }

        /** \Première_possibilité : Si le pion(d) a un seul voisin et que le pion(d) est de notre couleur :
         *  on parcourt une nouvelle fois l'ensemble des coups possibles.
         *          - Si on trouve un coup ayant la même origine mais une destination différente du pion à isoler
         *          et une couleur différente de la notre : alors on joue ce coup.
         *          - Si on ne trouve pas de coup ayant pour destination un pion adverse, alors on parcourt une
         *          nouvelle fois l'ensemble des coups possibles et on empile sur un pion de notre couleur.
         */

        if ((k == 1) && (currentPosition.cols[d].couleur == myColor)) {

            for (j = 0; j < listeCoups.nb; j++) {
                o2 = listeCoups.coups[j].origine;
                d2 = listeCoups.coups[j].destination;

                if ((o2 == o) && (d2 != d) && (currentPosition.cols[d2].couleur != myColor)) {

                    for (l = 0; l < listeCoups.nb; l++) {
                        o3 = listeCoups.coups[l].origine;
                        d3 = listeCoups.coups[l].destination;

                        if ((o3 == d2) && (d3 != o2)) {
                            v = getVoisins(o3);
                            a = 0;

                            for (k = 0; k < v.nb; k++) {
                                if (((currentPosition.cols[o2].nb + currentPosition.cols[o3].nb +
                                      currentPosition.cols[v.cases[k]].nb) == 5) && (v.cases[k] != o2)) {
                                    a++;
                                }
                            }

                            if(a==0) {
                                //printf("ISOLER NOTRE PION EN DEPLACANT SON SEUL VOISIN SUR UNE COULEUR ADVERSE");
                                ecrireIndexCoup(j); // ISOLER NOTRE PION EN DEPLACANT SON SEUL VOISIN SUR UNE COULEUR ADVERSE
                                return;
                            }
                        }

                    }

                }
            }

            for (j = 0; j < listeCoups.nb; j++) {
                o2 = listeCoups.coups[j].origine;
                d2 = listeCoups.coups[j].destination;

                if ((o2 == o) && (d2 != d)) {

                    for (l = 0; l < listeCoups.nb; l++) {
                        o3 = listeCoups.coups[l].origine;
                        d3 = listeCoups.coups[l].destination;

                        if ((o3 == d2) && (d3 != o2)) {
                            v = getVoisins(o3);
                            a = 0;

                            for (k = 0; k < v.nb; k++) {
                                if (((currentPosition.cols[o2].nb + currentPosition.cols[o3].nb +
                                      currentPosition.cols[v.cases[k]].nb) == 5) && (v.cases[k] != o2)) {
                                    a++;
                                }
                            }

                            if(a==0) {
                               // printf("ISOLER NOTRE PION EN DEPLACANT SON SEUL VOISIN SUR UN AUTRE PION");
                                ecrireIndexCoup(j); // ISOLER NOTRE PION EN DEPLACANT SON SEUL VOISIN SUR UN AUTRE PION
                                return;
                            }
                        }

                    }

                }
            }

        }

        /** \Deuxième_possibilité : Si le pion(d) a un seul voisin et que le pion(d) N'est PAS de notre couleur :
         *  alors on joue ce coup
         */
        else if ((k == 1) && (currentPosition.cols[d].couleur != myColor)) {

            v = getVoisins(o);

            k = 0;

            // on compte le nombre de voisins du pion(d)
            for (j = 0; j < v.nb; j++) {
                if ((currentPosition.cols[v.cases[j]].couleur == myColor)) k++;
            }

            if(k!=0) {
                //printf("ISOLER UN PION ADVERSE EN EMPILANT N'IMP PION DESSUS");
                ecrireIndexCoup(i); //
                return;
            }
        }
    }

    /**
     *
     */
    for(i=0;i<listeCoups.nb; i++) {
        o = listeCoups.coups[i].origine;
        d = listeCoups.coups[i].destination;

        if ((currentPosition.cols[o].couleur == myColor) && ((currentPosition.cols[o].nb+currentPosition.cols[d].nb) == 5)) {

            for (j = 0; j < listeCoups.nb; j++) {
                o2 = listeCoups.coups[j].origine;
                d2 = listeCoups.coups[j].destination;

                if((o2 == o) && (currentPosition.cols[d2].couleur != myColor) && ((currentPosition.cols[o2].nb+currentPosition.cols[d2].nb) == 5)){
                    //printf("PILE DE 5 SPECIALE\n");
                    ecrireIndexCoup(j);
                    return;
                }
            }
        }
    }

    /** STRATÉGIE N°2 :
     *          - faire des empilements classiques
     *          - vérification supplémentaire : cet empilement peut-il conduire a une pile de 5 pour l'adversaire ?
     *      DÉTAIL :
     *      Si un coup permet d'empiler un pion adverse sur un autre, sans faire de pile de 5 :
     *      on parcourt une nouvelle fois les coups.
     *      On regarde les coups possibles par le pion(d) (en retirant comme destination le pion à l'origine
     *      précédemment). Pour chaque voisin du pion(d), si la somme de la hauteur de la première origine et
     *      des deux destinations est égale à 5 : alors on incrémente la variable a.
     *      Si a != 0, on ne joue pas le coup, car l'adversaire pourrait faire une pile de 5.
     */

    for(i=0;i<listeCoups.nb; i++) {
        o = listeCoups.coups[i].origine;
        d = listeCoups.coups[i].destination;

        if ((currentPosition.cols[o].couleur != myColor)
            && (currentPosition.cols[d].couleur != myColor)
            && ((currentPosition.cols[o].nb + currentPosition.cols[d].nb) != 5)
                ) {
            for (j = 0; j < listeCoups.nb; j++) {
                o2 = listeCoups.coups[j].origine;
                d2 = listeCoups.coups[j].destination;

                if ((o2 == d) && (d2 != o)) {
                    v = getVoisins(o2);
                    a =0;

                    for (k = 0; k < v.nb; k++) {
                        if (((currentPosition.cols[o].nb + currentPosition.cols[o2].nb +
                             currentPosition.cols[v.cases[k]].nb) == 5) && (v.cases[k] != o)) {
                            a++;
                        }
                    }

                    if(a==0) {
                        //printf("COMMENT ENCULER LE MONDE ?");
                        ecrireIndexCoup(i);
                        return;
                    }
                }

            }
        }
    }

    /** PILE DE 5 PAR DÉFAUT :
     *          - faire une pile de 5 si possible, aucune cdt particulière
     */
    for(i=0;i<listeCoups.nb; i++) {
        o = listeCoups.coups[i].origine;
        d = listeCoups.coups[i].destination;

        // Si je peux gagner une colonne, je la prends (1+4, 2+3 ...)
        if ( 			(currentPosition.cols[o].couleur == myColor)
                        && 	((currentPosition.cols[o].nb+currentPosition.cols[d].nb) == 5)
                ) {
                    //printf("PILE DE 5 PAR DÉFAUT");
                    ecrireIndexCoup(j);
                    return;
            }
    }

    /** EMPILEMENT PAR DEFAUT :
     *          - empiler un pion adverse sur un pion adverse dans l'ordre des coups
     */

    for(i=0;i<listeCoups.nb; i++) {
        o = listeCoups.coups[i].origine;
        d = listeCoups.coups[i].destination;

        if ((currentPosition.cols[o].couleur != myColor)
            && (currentPosition.cols[d].couleur != myColor)
            && ((currentPosition.cols[o].nb + currentPosition.cols[d].nb) != 5)
                ) {
            //printf("EMPILEMENT PAR DEFAUT");
            ecrireIndexCoup(i);
            return;
        }

    }

    for(i=0;i<listeCoups.nb; i++) {
        o = listeCoups.coups[i].origine;
        d = listeCoups.coups[i].destination;

        if ((currentPosition.cols[o].couleur == myColor) && (currentPosition.cols[d].couleur != myColor)) {
            //printf("NOTRE COULEUR SUR LEUR COULEUR");
            ecrireIndexCoup(i);
            return;
        }

    }
    /**
     *  COUP PAR DEFAUT, SI AUCUNE STRATÉGIE NE PEUT ÊTRE APPLIQUÉE
     */

	while (1) {
		a = rand()%listeCoups.nb;
		o = listeCoups.coups[a].origine; 
		d = listeCoups.coups[a].destination;  
 
		if ( (currentPosition.cols[o].couleur != myColor)
		&& (currentPosition.cols[d].nb != 4) ) {
            //printf("COUP RANDOM");
			ecrireIndexCoup(a);
			return;
		}
	}
	
}


