#include <stdio.h>
#include <stdlib.h>
#include "emilia.h"
#include "moteur.h"

#define SIZE 3

DecisionPattern decisionPattern[SIZE] = { scoreMakerRandom, scoreMakerCastle, scoreMakerDeadlyLoneliness };

/**
 * This function evaluate a gameState and chose the best move to make.
 */
void choisirCoup(T_Position currentPosition, T_ListeCoups listeCoups) {
  Game game = { currentPosition, currentPosition.trait };

  if(SIZE == 0) {
    ecrireIndexCoup(rand()%listeCoups.nb);
    return;
  }

  debug("Let's go through each moves.\n");

  DecisionReturn scores[SIZE][NBCASES];

  // We need to evaluate each move with our design patterns.
  for(int i = 0; i < SIZE; i++) {
    for(int j = 0; j < NBCASES; j++) {
      debug("Pattern %i Stack %i which is %s\n", i, j, COLNAME(emilia_Ui(j, game.gameState).t));
      DecisionReturn currentReturn = decisionPattern[i](
        emilia_Ui(j, game.gameState), &game);
      debug("\tKeept Score: %i\n\n", currentReturn.score);

      scores[i][j] = currentReturn;
    }
  }

  // Select which pattern.
  int maxs[SIZE];

  for(int i = 0; i < SIZE; i++) {
    int currentMax = -2;
    for(int j = 0; j < NBCASES; j++) {
      if(scores[i][j].score > currentMax) {
        currentMax = scores[i][j].score;
      }
    }
    // We only keep the best moves for each patterns.
    maxs[i] = currentMax;
  }

  debug("\n\nLet's chose a Pattern ptdr !\n\n");
  int chosedPattern = 0;
  
  //If multiples with same scores, we need to randomize it.
  int outsidersPattern[SIZE];
  int outsidersNb = 0;
  int currentMax = -2;

  for(int i = 0; i < SIZE; i++) {
    // We only keep the best Pattern(s).
    if(maxs[i] > currentMax) {
      outsidersNb = 1;
      outsidersPattern[0] = i;
      currentMax = maxs[i];
    } else if(maxs[i] == currentMax) {
      outsidersPattern[outsidersNb] = i;
      outsidersNb++;
    }
  }

  if(outsidersNb > 1) {
    // We need to randomize.
    chosedPattern = outsidersPattern[rand()%outsidersNb];
  } else {
    // We only keep the best one, so.
    chosedPattern = outsidersPattern[0];
  }

  debug("\n\nChosed Pattern : %i !\n\n", chosedPattern);

  debug("\n\nLet's find a target!\n\n");

  // We now need to chose a target.
  T_Coup chosedMove;
  int outsidersTarget[NBCASES];
  outsidersNb = 0;
  
  for(int i = 0; i < NBCASES; i++) {
    if(scores[chosedPattern][i].score == maxs[chosedPattern]) {
      outsidersTarget[outsidersNb] = i;
      outsidersNb++;
    }
  }

  if(outsidersNb == 0) {
    // ERROR ! Let's play a random one..
    ecrireIndexCoup(rand()%listeCoups.nb);
    debug("All outsiders, buuh.");
    return;
  }

  if(maxs[chosedPattern] < 0) {
    // Sadness, All moves lead to a bad thing.
    ecrireIndexCoup(rand()%listeCoups.nb);
    debug("All is negative, buuh.");
    return;
  }
  
  int chosedTarget = outsidersTarget[rand()%outsidersNb];
  chosedMove = scores[chosedPattern][chosedTarget].move;

  debug("\n\nChosed Target : %i !\n", chosedTarget);
  debug("\tWith score : %i !\n\n", scores[chosedPattern][chosedTarget].score);

  // All is good !
  for(int i = 0; i < listeCoups.nb; i++) {
    T_Coup currentMove = listeCoups.coups[i];
    if(currentMove.destination == chosedMove.destination
      && currentMove.origine == chosedMove.origine) {
      ecrireIndexCoup(i);
    }
  }

  debug("\n\nI'll make the move %i -> %i !\n\n", chosedMove.origine, chosedMove.destination);

  switch(chosedPattern) {
    case 0:
      debug("\t\tChosen Pattern is Random lol.\n");
      break;
    case 1:
      debug("\t\tChosen Pattern is Castle xd.\n");
      break;
    case 2:
      debug("\t\tChosen Pattern is Deadly mdr.\n");
      break;
  }

}