/*
* General Emilia purpose file.
*/

#include "emilia.h"

/*
* Utils
*/

octet couche3[] = {0, 1, 5, 10, 11, 18, 19, 27, 35, 41, 45, 47, 46, 42, 37, 36,
 29, 28, 20, 21, 12, 6, 2, -1};

octet couche2[] = {3, 4, 9, 16, 17, 26, 34, 40, 44,
 43, 38, 37, 30, 29, 21, 13, 7, -1};

int getCoucheOf(Pile u) {
  return getCoucheOfi(u.i);
}

int getCoucheOfi(octet index) {
  int i = 0;
  while(couche3[i] != -1) {
    if(couche3[i] == index) {
      return 3;
    }
    i++;
  }

  i = 0;
  while(couche2[i] != -1) {
    if(couche2[i] == index) {
      return 2;
    }
    i++;
  }
  return 1;
}

int getCloseCenterMove(T_Coup move, State state) {
  return getCoucheOfi(move.origine) - getCoucheOfi(move.destination);
}

Pile emilia_U(Pile u, State gameState) {
  return emilia_Ui(u.i, gameState);
}

Pile emilia_Ui(octet u, State gameState) {
  Pile toRet = { u, gameState.cols[u].nb, gameState.cols[u].couleur, getVoisins(u) };
  return toRet;
}

/*
* Patterns
*/

int isIsolated(Pile u, State gameState) {
  Voisin ng = u.vd;
  Pile v;
  for(int i = 0; i < ng.nb; i++) {
    v = emilia_Ui(ng.cases[i], gameState);
    if(v.h > 0 && !gate(u, v)) {
      return 0;
    }
  }
  return 1;
}

T_Voisins getSignificantNG(Pile pile, State gameState) {
  T_Voisins toRet;
  toRet.nb = 0;

  for(int i = 0; i < pile.vd.nb; i++) {
    Pile v = emilia_Ui(pile.vd.cases[i], gameState);
    if(v.h != 0 && pile.h != 0 && pile.h + v.h <= 5) {
      toRet.cases[toRet.nb] = pile.vd.cases[i];
      toRet.nb++;
    }
  }

  return toRet;
}

int isNegativeIQMove(T_Coup move, Game* game) {
  Pile u = emilia_Ui(move.destination, game->gameState);
  Pile v = emilia_Ui(move.origine, game->gameState);
  
  Voisin ng = getSignificantNG(u, game->gameState);
  Pile a;
  for(int i = 0; i < ng.nb; i++) {
    a = emilia_Ui(ng.cases[i], game->gameState);
    // Not the moved one && Emillia's piece && The move will lead to a NIQM.
    if(a.i != v.i && a.t != game -> alpha && u.h + v.h + a.h == 5) return 1; 
  }
  return 0;
}

/**
 * Decision Pattern
 */

// The elementary pattern.
DecisionReturn scoreMakerRandom(Pile pile, Game* game) {

  DecisionReturn movables[pile.vd.nb];

  // We will go through each neighbors.
  for(int i = 0; i < pile.vd.nb; i++) {
    Pile currentNG = emilia_Ui(pile.vd.cases[i], game->gameState);
    T_Coup move = { pile.i, currentNG.i };
    debug("\t[Random Pattern] Trying M(%d,%d) !\n", move.origine, move.destination);

    movables[i].move = move;
    movables[i].score = 0;

    if(pile.h == 0 || currentNG.h == 0 || gate(pile, currentNG)) {
      // Not valid, Don't play it.
      movables[i].score = -10;
      continue;
    }

    // Will it allow ennemy to make a Castle .. Pretty bad tbh.
    if(isNegativeIQMove(move, game)) {
      debug("\t[Random Pattern] Ouch, negative IQ move.\n");
      movables[i].score -= 10;
    }

    // Will it allow ennemy to isolate a piece next state?
    T_Position nextState = jouerCoup(game->gameState, move.origine, move.destination);

    // We will score this current move.
    debug("\t[Random Pattern] Scoring, Current Score : %d.\n", movables[i].score);
    for(int j = 0; j < pile.vd.nb; j++) {
      Pile currentPile = emilia_Ui(pile.vd.cases[j], nextState);
      if(j == i) {
        // This is the created piece.
        if(isIsolated(currentPile, nextState)) {
          debug("\t[Random Pattern] We'll isolate.\n");
          if(currentPile.t == game->alpha) {
            // We just created an isolated piece for us, it's good.
            movables[i].score += 10;
            debug("\t[Random Pattern] We'll isolate for us. (+10)\n");
          } else {
            // Uch, we created an isolated ennemy piece, so bad.
            movables[i].score -= 10;
            debug("\t[Random Pattern] We'll make an isolation for an ennemy (-10)\n");
          }
        }
      } else {
        Voisin significantNG = getSignificantNG(currentPile, nextState);
        if(significantNG.nb == 1) {
          debug("\t[Random Pattern] We'll allow an isolation !\n");
          // This piece will only have 1 Significant NG Left. Let's check if it's worth.
          Pile onlyLeftNG = emilia_Ui(significantNG.cases[0], nextState);
          if(currentPile.t != game->alpha) {
            // Ouch, it's an ennemy one.. We should not make this move so..
            movables[i].score -= 10;
          } else {
            // This one is our !
            if(onlyLeftNG.t != currentPile.t) {
              // .. But ennemy can take it, sad..
              movables[i].score -= 10;
            }
            // Otherwise, This is not really bad but not super, ennemy may waste one of
            // our piece or deny us to isolate it, but it's fine..
          }
        }
      }
    }

    if(movables[i].score >= 0) {
      debug("\t[Random Pattern] This is a positive move atm.\n");
      Voisin NGEE = getSignificantNG(currentNG, game->gameState);
          
      int ourNG = 0;
      int hisNG = 0;
      
      for(int k = 0; k < NGEE.nb; k++) {
        Pile k_stack = emilia_Ui(NGEE.cases[k], game->gameState);
        if(k_stack.t != game->alpha) {
          hisNG++;
        } else {
          ourNG++;
        }
      }

      if(pile.t != game->alpha) {
        // We're moving an enemy stack.
        debug("\t[Random Pattern] We're moving ennemie's one.\n");
        if(currentNG.t == game->alpha) {
          // We give a stack to an ennemy.. Not good..
            movables[i].score -= 20;
        } else {
          // We make our ennemy loose a stack, it's good :)
          debug("\t[Random Pattern] Ennemies onto ennemies.\n");
          movables[i].score++;
        }
      } else {
        debug("\t[Random Pattern] We're moving our's !\n");
        if(currentNG.t == game->alpha) {
          movables[i].score--;
        } else {
          if(hisNG == 0) {
            movables[i].score += 10;
          }

          if(ourNG > hisNG) {
            movables[i].score += 10*(ourNG - hisNG);
          }
        }

        if(isIsolated(emilia_Ui(move.destination, nextState), nextState)) {
          movables[i].score += 10;
        }

      }
    }
    debug("\n\n");
  }

  int bestMoves[pile.vd.nb];
  int bestMovesNb = 0;
  int bestScore = -2;

  // We will return our best move !
  for(int i = 0; i < pile.vd.nb; i++) {
    if(movables[i].score > bestScore) {
      bestScore = movables[i].score;
      bestMoves[0] = i;
      bestMovesNb = 1;
    } else if(movables[i].score == bestScore) {
      bestMoves[bestMovesNb] = i;
      bestMovesNb++;
    }
  }

  if(!bestMovesNb) {
    // Negative score move are not made anyway.
    movables[0].score = -1;
    return movables[0];
  } else {
    return movables[bestMoves[rand()%bestMovesNb]];
  }
  
}

DecisionReturn scoreMakerDeadlyLoneliness(Pile u, Game * game){
  Voisin ng = u.vd;
  DecisionReturn toRet;
  toRet.score = -1;
  int v_significant = getSignificantNG(u, game->gameState).nb;
  debug("\t[Deadly Pattern] Searching for Deadly pattern !\n");
  debug("\t[Deadly Pattern] Stack %d have %d Significant Neighbor !\n", u.i, v_significant);

  if(v_significant == 1) {
    debug("\t[Deadly Pattern] One has been found\n");
    Pile v = emilia_Ui(getSignificantNG(u, game->gameState).cases[0], game -> gameState);
    if (v.t == game -> alpha) {
      toRet.move.origine = v.i;
      toRet.move.destination = u.i;
      toRet.score = 1000;
      debug("\t[Deadly Pattern] Isolation made: Our -> Our/en\n");
      return toRet;
    } else {
      if(u.t == v.t){
        toRet.move.origine = u.i;
        toRet.move.destination = v.i;
        toRet.score = 1000;
        debug("\t[Deadly Pattern] Isolation made En u -> En v!\n");
        return toRet;
      } else {
        Voisin ng2 = v.vd;
        Pile v2;
        DecisionReturn movables[ng2.nb];
        debug("\t[Deadly Pattern] Isolation de ouf !\n");

        for(int j = 0; j < ng2.nb; j++) {
          v2 = emilia_Ui(ng2.cases[j], game -> gameState);
          movables[j].move.origine = v.i;
          movables[j].move.destination = v2.i;
          if(v2.i != u.i && !gate(v,v2) && v2.h != 0){
            if(v2.t == v.t) {
                movables[j].score = 1001;
            } else {
                movables[j].score = 900;
            }
            if(isNegativeIQMove(movables[j].move, game)) {
              movables[j].score -= 300;
            }
          }
          else movables[j].score = -1;
        }

        int bestMoves[ng2.nb];
        int bestMovesNb = 0;
        int bestScore = -2;

        // We will return our best move !
        for(int i = 0; i < ng2.nb; i++) {
          if(movables[i].score > bestScore) {
            bestScore = movables[i].score;
            bestMoves[0] = i;
            bestMovesNb = 1;
          } else if(movables[i].score == bestScore) {
            bestMoves[bestMovesNb] = i;
            bestMovesNb++;
          }
        }
        if(!bestMovesNb) {
          // Negative score move are not made anyway.
          movables[0].score = -1;
          return movables[0];
        } else {
          return movables[bestMoves[rand()%bestMovesNb]];
        }
      }
    }
  }

  return toRet;
}

// Can we make a castle from this target ?
DecisionReturn scoreMakerCastle(Pile pile, Game * game ){
  Voisin ng = pile.vd;
  DecisionReturn toRet = {{}, -1};

  Pile a;
  for(int i = 0; i < ng.nb; i++){
    a = emilia_Ui(ng.cases[i], game->gameState);

    if(pile.h == 0 || a.h == 0 || gate(pile, a)) {
      // Not valid, Don't play it.
      continue;
    }

    if (pile.h + a.h == 5 && pile.t == game->alpha && pile.t != a.t) {

      Voisin NGEE = getSignificantNG(a, game->gameState);
          
      int ourNG = 0;
      int hisNG = 0;
      
      for(int k = 0; k < NGEE.nb; k++) {
        Pile k_stack = emilia_Ui(NGEE.cases[k], game->gameState);
        if(k_stack.t != game->alpha) {
          hisNG++;
        } else {
          ourNG++;
        }
      }

      if(hisNG == 0) {
        continue;
      }

      toRet.move.origine = pile.i;
      toRet.move.destination = a.i;
      toRet.score = 20000;

      return toRet;
    } else {
      toRet.move.origine = pile.i;
      toRet.move.destination = a.i;
      toRet.score = -1;
    }
  }
  return toRet;
}