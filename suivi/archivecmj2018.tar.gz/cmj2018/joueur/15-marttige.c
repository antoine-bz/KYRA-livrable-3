
/********* Moteur de tournoi : joueur ***************/

#include <stdio.h>
#include <stdlib.h>
#include "avalam.h"
#include "moteur.h"
#include <string.h>


void choisirCoup(T_Position currentPosition, T_ListeCoups listeCoups) {
	// Cette fonction peut appeler la fonction ecrireIndexCoup(coupChoisi);
	// Pour sélectionner l'index d'un coup à jouer dans la liste l


	int i;
	octet o, d;
	int a;
	octet myColor = currentPosition.trait;

	// afficherListeCoups(listeCoups);

	//COUPS D'OUVERTURES
	printf("Ma couleur : %s\n", COLNAME(currentPosition.trait));
	for(i=0;i<listeCoups.nb; i++) {
        o = listeCoups.coups[i].origine;
        d = listeCoups.coups[i].destination;

        printf("Coup %d : ", i);
        printf("%d (%d - %s) ->", o, currentPosition.cols[o].nb, COLNAME(currentPosition.cols[o].couleur));
        printf("%d (%d - %s) \n", d, currentPosition.cols[d].nb, COLNAME(currentPosition.cols[d].couleur));

        //coups d'ouverture jaune
        if(currentPosition.trait==JAU)
        {
        if (o == 5 && currentPosition.cols[o].couleur == myColor && d == 9 && currentPosition.cols[o].nb == 1 &&
            currentPosition.cols[d].nb == 1) {
            printf(" On choisit ce coup ! \n");
            ecrireIndexCoup(i);
            return;
        }

        if (o == 0 && currentPosition.cols[o].couleur == myColor && d == 2 && currentPosition.cols[o].nb == 1 &&
            currentPosition.cols[d].nb == 1) {
            printf(" On choisit ce coup !\n");
            ecrireIndexCoup(i);
            return;
        }
    }
        //coup d'ouverture rouge
    if(currentPosition.trait==ROU)
    {
       if (o == 26 && currentPosition.cols[o].couleur == myColor && d == 34 && currentPosition.cols[o].nb == 1 &&
            currentPosition.cols[d].nb == 1) {
            printf(" On choisit ce coup !\n");
            ecrireIndexCoup(i);
            return;
        }

       if (o == 27 && currentPosition.cols[o].couleur == myColor && d == 19 && currentPosition.cols[o].nb == 1 &&
            currentPosition.cols[d].nb == 1) {
            printf("On choisit ce coup !\n");
            ecrireIndexCoup(i);
            return;
        }
    }
}

    for(i=0;i<listeCoups.nb; i++) {
        o = listeCoups.coups[i].origine;
        d = listeCoups.coups[i].destination;

		// Si je peux gagner une colonne, je la prends (1+4, 2+3 ...)
		if ((currentPosition.cols[o].couleur == myColor) && ((currentPosition.cols[o].nb+currentPosition.cols[d].nb) == 5)) {
			printf("On choisit ce coup ! \n");
			ecrireIndexCoup(i);
			return; // on quitte la fonction
		}

		//Si il n'y a qu'un seul voisin et que il y a un pion de notre couleur et un pion de la couleur adverse, on prend le pion.
		if(nbVoisins(o)==1 && currentPosition.cols[o].couleur == myColor && currentPosition.cols[d].couleur != myColor && ((currentPosition.cols[o].nb+currentPosition.cols[d].nb) == 5)){
			printf("On choisit ce coup");
			ecrireIndexCoup(i);
			return;
		}
	}


int flag=1;
i=0;
if(currentPosition.cols[d].couleur!=VIDE&&currentPosition.cols[d].couleur!=myColor&&currentPosition.cols[o].nb==2&&currentPosition.cols[d].nb==1)
{
	T_Voisins voisins=getVoisins(d);
	for(i=0;i<voisins.nb;i++)
	{
		if(currentPosition.cols[voisins.cases[i]].nb==2&&currentPosition.cols[voisins.cases[i]].nb!=VIDE&&currentPosition.cols[voisins.cases[i]].nb!=myColor)
		{
			flag=0;
		}

		if(flag!=0){
			printf("On choisit ce coup ! \n");
			ecrireIndexCoup(i);
			return; // on quitte la fonction
		}	
	}

}


//Diagramme : non fonctionnel
/*    for(i=0;i<listeCoups.nb; i++) {
        o = listeCoups.coups[i].origine;
        d = listeCoups.coups[i].destination;

        if(currentPosition.cols[o].nb==2 && currentPosition.cols[o].couleur == myColor
           && currentPosition.cols[o+1].nb==1 && currentPosition.cols[o+1].couleur != myColor
           && currentPosition.cols[o-1].nb==1 && currentPosition.cols[o-1].couleur != myColor
           && currentPosition.cols[o+9].nb==1 && currentPosition.cols[o+9].couleur != myColor
           && currentPosition.cols[o-8].nb==1 && currentPosition.cols[o-8].couleur != myColor
           && currentPosition.cols[o+8].nb==1 && currentPosition.cols[o+8].couleur == myColor
           && d == o-1){
            printf("On choisit ce coup");
            ecrireIndexCoup(i);
            return;
        }

        
    }

*/

        // Sinon, j'empile des pions adverses sauf s'ils conduisent à des tas de 5
	for(i=0;i<listeCoups.nb; i++) {
		o = listeCoups.coups[i].origine;
		d = listeCoups.coups[i].destination;

		if ( (currentPosition.cols[o].couleur != myColor) && (currentPosition.cols[d].couleur != myColor) && ((currentPosition.cols[o].nb+currentPosition.cols[d].nb) < 3)) {
			printf("On choisit ce coup ! \n");
			ecrireIndexCoup(i);
			return; // on quitte la fonction
		}
	}

for(i=0;i<listeCoups.nb; i++) {
        o = listeCoups.coups[i].origine;
        d = listeCoups.coups[i].destination;

i=0;
if(currentPosition.cols[d].couleur!=myColor && currentPosition.cols[o].nb==2 && currentPosition.cols[d].nb==2)
{
	T_Voisins voisins=getVoisins(d);
	for(i=0;i<voisins.nb;i++)
	{
		if(currentPosition.cols[voisins.cases[i]].nb==2)
		{
			printf("On choisit ce coup ! \n");
			ecrireIndexCoup(i);
			return; // on quitte la fonction
		}

		else
		{
			return; // on quitte la fonction
		
		}	
	}

}
}


	// Sinon, je tire au sort


	while (1) {
		a = rand()%listeCoups.nb;
		o = listeCoups.coups[a].origine;
		d = listeCoups.coups[a].destination;

		if ( (currentPosition.cols[o].couleur != myColor)
			 && ((currentPosition.cols[o].nb+currentPosition.cols[d].nb) != 5) ) {
			printf("On choisit ce coup ! \n");
			ecrireIndexCoup(a);
			return; // on quitte la fonction
		}
	}
}





