/*
*    Main file for Emilia's Library.
*    Please refer to "Analyse Gameplay Avalam" for more information.
*/

#ifndef EMILIA_H
#define EMILIA_H

#include <stdio.h>
#include <stdlib.h>
#include "avalam.h"

#define DEBUG 1

#define debug(fmt, ...) \
do { if(DEBUG) fprintf(stderr, fmt, ##__VA_ARGS__); } while(0)

#define isCastle(u) (u.h == 5)
#define areSignificant(u, v) (u.h != 0 && v.h != 0 && u.h + v.h <= 5)
#define gate(u, v) (u.h + v.h > 5)
#define areComplementary(u, v) (u.h + v.h == 5)

typedef T_Position State;
typedef octet      Trait;
typedef T_Voisins  Voisin;

typedef struct {
  State gameState;
  Trait alpha; // Emilia's Color.
} Game;

/*
* Represent a stack IN A CERTAIN STATE.
* Use the U function to get this stack in another state.
*/
typedef struct {
  octet i;
  int h;
  Trait t;
  Voisin vd;
} Pile;

typedef struct {
  T_Coup   move;
  int      score;
} DecisionReturn;

// A function pointer to a Decision making function && his score evaluator function.
typedef DecisionReturn (*DecisionPattern)(Pile, Game*);

int getCoucheOf(Pile u);
int getCoucheOfi(octet index);
int getCloseCenterMove(T_Coup, State);
Pile emilia_U(Pile index, State gameState);
Pile emilia_Ui(octet u, State gameState);
int isIsolated(Pile u, State gameState);
T_Voisins getSignificantNG(Pile pile, State gameState);

int isNegativeIQMove(T_Coup move, Game* game);
DecisionReturn scoreMakerCastle(Pile pile, Game * game);
DecisionReturn scoreMakerRandom(Pile pile, Game* game);
DecisionReturn scoreMakerDeadlyLoneliness(Pile pile, Game* game);

#endif
