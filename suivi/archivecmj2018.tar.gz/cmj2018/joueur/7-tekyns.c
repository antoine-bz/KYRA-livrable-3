/********* Moteur de tournoi : joueur ***************/

#include <stdio.h>
#include "avalam.h"
#include "moteur.h"

void choisirCoup(T_Position currentPosition, T_ListeCoups listeCoups) {
	// Cette fonction peut appeler la fonction ecrireIndexCoup(coupChoisi);
	// Pour sélectionner l'index d'un coup à jouer dans la liste l 
	// EX: TOUJOURS JOUER UN PION ADVERE PAR DESSUS UN PION ADVERSE
	
	int i;
	octet org, dest;

	for (i=0; i < listeCoups.nb; i++) {
		org = listeCoups.coups[i].origine;
		dest = listeCoups.coups[i].destination;

		//*************************verifie pile 4 a deplacer ou verifie prendre pile de 4*********************

		if ((currentPosition.cols[org].nb == 4) && (currentPosition.cols[org].couleur == currentPosition.trait)) {
			ecrireIndexCoup(i); 
			printf("On choisit le coup %d : ", i);
			printf("%d -> %d \n", org, dest);
			return;
		}

		//********************************************verifie prendre pile de 4*******************************//

		if ((currentPosition.cols[org].nb == 1) && (currentPosition.cols[org].couleur == currentPosition.trait) && (currentPosition.cols[dest].nb == 4)) {
			ecrireIndexCoup(i); 
			printf("On choisit le coup %d : ", i);
			printf("%d -> %d \n", org, dest);
			return;
		}

		//*****************************************pile de trois pile de deux *****************************//


		if ((currentPosition.cols[org].nb == 2) && (currentPosition.cols[org].couleur == currentPosition.trait) &&(currentPosition.cols[dest].nb == 3)) {
			ecrireIndexCoup(i); //si il y a une pile de 4 et que l on a un pion a cote on prend la pile	
			printf("On choisit le coup %d : ", i);
			printf("%d -> %d \n", org, dest);
			return;
		}

		if ((currentPosition.cols[org].nb == 3) && (currentPosition.cols[org].couleur == currentPosition.trait) &&(currentPosition.cols[dest].nb == 2)) 					{
			ecrireIndexCoup(i); //si il y a une pile de 4 et que l on a un pion a cote on prend la pile	
			printf("On choisit le coup %d : ", i);
			printf("%d -> %d \n", org, dest);
			return;
		}

		//****************************************pile isolé****************************//

		if(getVoisins(dest).nb == 1 && currentPosition.cols[org].couleur == currentPosition.trait) {
			ecrireIndexCoup(i); //si il y a une pile de 4 et que l on a un pion a cote on prend la pile	
			printf("On choisit le coup %d : ", i);
			printf("%d -> %d \n", org, dest);
			return;
		}		

		/* verifier si il n'y a qu'un seul voisin et la couleur de ce pion

		si pion allié deplacé le pion voisin ailleur

		si pion adverse deplacé le pion voisin sur lui peut importe la couleur car si il est ennemi cela lui fais gagné une tour mais 			perdre 2 pion et si i est allié cela fais gagne une tour


		dans avalam.h il y a une fonction getVoisins(numcase) je pense qu'il faut utiliser la fonction pour trouver le numero du pion 			voisin

		*/

	}

	//********************************************* schema habituel ***********************************//

	for (i=0; i < listeCoups.nb; i++) {
		org = listeCoups.coups[i].origine;
		dest = listeCoups.coups[i].destination;

		if ((currentPosition.cols[org].couleur != currentPosition.trait) && (currentPosition.cols[dest].couleur != currentPosition.trait) && ((currentPosition.cols[dest].nb + currentPosition.cols[org].nb) < 4)) {
			ecrireIndexCoup(i);
			printf("On choisit le coup %d : ", i);
			printf("%d -> %d \n", org, dest);
			return;
		}
	}

	for (i=0; i < listeCoups.nb; i++) {
		org = listeCoups.coups[i].origine;
		dest = listeCoups.coups[i].destination;

 		if(currentPosition.cols[dest].couleur != currentPosition.trait && (currentPosition.cols[org].couleur == currentPosition.trait)) {
			ecrireIndexCoup(i);
			printf("On choisit le coup %d : ", i);
			printf("%d -> %d \n", org, dest);
			return;
		}
	}

}

/*

_________ _______  _                 _        _______ 
\__   __/(  ____ \| \    /\|\     /|( (    /|(  ____ \
   ) (   | (    \/|  \  / /( \   / )|  \  ( || (    \/
   | |   | (__    |  (_/ /  \ (_) / |   \ | || (_____ 
   | |   |  __)   |   _ (    \   /  | (\ \) |(_____  )
   | |   | (      |  ( \ \    ) (   | | \   |      ) |
   | |   | (____/\|  /  \ \   | |   | )  \  |/\____) |
   )_(   (_______/|_/    \/   \_/   |/    )_)\_______


*/

