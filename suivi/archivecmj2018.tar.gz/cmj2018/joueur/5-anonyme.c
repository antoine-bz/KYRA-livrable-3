#include <stdio.h>
#include <stdlib.h>
#include "avalam.h"
#include "moteur.h"


int chercher_coup(T_ListeCoups coups, octet ori, octet dest);

void choisirCoup(T_Position currentPosition, T_ListeCoups listeCoups)
{
    //Var
    int i, j, maxi, jeu, flag;
    int coups[295];
    octet myColor;
    octet o, d;
    int test;
    T_Voisins voisins1,voisins2;

    for(i=0;i<295;i++)
    {
        coups[i]=0;
        //printf(" %d |",coups[i]);
    }

    jeu=0;
    for (i = 0; i < listeCoups.nb; i++)
    {
        o = listeCoups.coups[i].origine;
        d = listeCoups.coups[i].destination;
        myColor=currentPosition.trait;

        //Test d'isolation

        test=0;
        voisins1=getVoisins(d);
        for(j=0;j<voisins1.nb;j++)
        {
            if(currentPosition.cols[voisins1.cases[j]].nb != VIDE && currentPosition.cols[voisins1.cases[j]].nb != 5)
            {
                    test++;
            }
        }
        if(test==1 && currentPosition.cols[d].couleur==myColor) 												//destination de ma couleur
        {
            voisins1=getVoisins(o);
            if(currentPosition.cols[o].couleur==myColor) 														// origine de ma couleur
            {
                for(j=0;j<voisins1.nb;j++)  																	//parcours des voisins de l'origine
                {
                    if(currentPosition.cols[voisins1.cases[j]].couleur != myColor 								//couleur du voisin pas de ma couleur
                       && (currentPosition.cols[voisins1.cases[j]].nb+currentPosition.cols[o].nb)==5) 			//si un des voisins et l'origine du coup font 5
                    {
                        coups[chercher_coup(listeCoups,o,voisins1.cases[j])]+=15;
                    }
                    else if(currentPosition.cols[voisins1.cases[j]].couleur == myColor
                            && (currentPosition.cols[voisins1.cases[j]].nb+currentPosition.cols[o].nb)==5)
                    {
                        coups[chercher_coup(listeCoups,o,voisins1.cases[j])]+=15;
                    }
                    else if(currentPosition.cols[voisins1.cases[j]].couleur != myColor
                            && (currentPosition.cols[voisins1.cases[j]].nb+currentPosition.cols[o].nb<5))		// <=  ------->  <
                    {
                        coups[chercher_coup(listeCoups,o,voisins1.cases[j])]+=10;
                    }
                    else if (currentPosition.cols[voisins1.cases[j]].couleur == myColor
                             && (currentPosition.cols[voisins1.cases[j]].nb+currentPosition.cols[o].nb<5))		// <=  ------->  <
                    {
                        coups[chercher_coup(listeCoups,o,voisins1.cases[j])]+=10;
                    }
                }
                coups[i]+=15;
            }
            else if (currentPosition.cols[o].couleur!=myColor)
            {
                for(j=0;j<voisins1.nb;j++)
                {
                    if(currentPosition.cols[voisins1.cases[j]].couleur == myColor
                       && (currentPosition.cols[voisins1.cases[j]].nb+currentPosition.cols[o].nb<=5))
                    {
                        coups[chercher_coup(listeCoups,o,voisins1.cases[j])]+=5;

                    }
                    else if(currentPosition.cols[voisins1.cases[j]].couleur != myColor
                            && (currentPosition.cols[voisins1.cases[j]].nb+currentPosition.cols[i].nb<=5))
                    {
                        coups[chercher_coup(listeCoups,o,voisins1.cases[j])]+=3;
                    }
                }
                coups[i]-=15;
            }
        }
        else if(test==1 && currentPosition.cols[d].couleur!=myColor) 											//origine ma couleur sur destination pas ma couleur += 20
        {
            if(currentPosition.cols[o].couleur==myColor)
            {
                    coups[i]+=50;																				// 20 ------> 50
            }
            else if (currentPosition.cols[o].couleur!=myColor)													//on empile les jetons averses
            {
                    coups[chercher_coup(listeCoups,d,o)]+=20;													// 10 ------> 20
            }
        }


        voisins2=getVoisins(d);
        test=0;
        for(j=0;j<voisins2.nb;j++)
        {
            if(currentPosition.cols[voisins2.cases[j]].couleur != myColor && currentPosition.cols[voisins2.cases[j]].couleur != VIDE)
            {
                test++;
            }
        }
        if(test==0 && currentPosition.cols[o].couleur==myColor)
        {
            coups[i]+=50;
        }



        //Prends des Tours de 5

        if((currentPosition.cols[o].nb + currentPosition.cols[d].nb == 5)
           && (currentPosition.cols[o].couleur == myColor))
        {
        	if(currentPosition.cols[d].couleur == myColor) coups[i] += 80;										// on prend des tours de 5 (plus de valeur si la destination est adverse)
        	else coups[i] += 200;
        }


        //Test de mouvement

        voisins1=getVoisins(o);
        voisins2=getVoisins(d);
        if(currentPosition.cols[o].nb + currentPosition.cols[d].nb == 5
           && currentPosition.cols[o].couleur != myColor && currentPosition.cols[d].couleur != myColor)			
        {
            if(currentPosition.cols[o].nb<=2 && currentPosition.cols[o].couleur !=myColor)
            {
                for(j=0;j<voisins1.nb;j++)
                {
                    if(currentPosition.cols[voisins1.cases[j]].nb+currentPosition.cols[o].nb==5 
                       && currentPosition.cols[voisins1.cases[j]].couleur==myColor)
                    {
                        coups[chercher_coup(listeCoups,voisins1.cases[j],o)]+=10;
                    }
                    if(currentPosition.cols[voisins1.cases[j]].nb+currentPosition.cols[o].nb==5
                       && currentPosition.cols[voisins1.cases[j]].couleur!=myColor
                       && currentPosition.cols[voisins1.cases[j]].couleur!=VIDE)
                    {
                        coups[chercher_coup(listeCoups,voisins1.cases[j],o)]-=10;
                    }
                    if(currentPosition.cols[voisins1.cases[j]].nb+currentPosition.cols[o].nb<=3
                       && currentPosition.cols[voisins1.cases[j]].couleur!=myColor
                       && currentPosition.cols[voisins1.cases[j]].couleur!=VIDE)
                    {
                        coups[chercher_coup(listeCoups,voisins1.cases[j],o)]+=5;
                    }
                    if(currentPosition.cols[voisins1.cases[j]].nb+currentPosition.cols[o].nb<=3
                       && currentPosition.cols[voisins1.cases[j]].couleur==myColor)
                    {
                        coups[chercher_coup(listeCoups,voisins1.cases[j],o)]+=6;
                    }
                }
            }
            else if (currentPosition.cols[d].nb<=2)
            {
                for(j=0;j<voisins2.nb;j++)
                {
                    if(currentPosition.cols[voisins1.cases[j]].nb+currentPosition.cols[o].nb==5
                       && currentPosition.cols[voisins1.cases[j]].couleur==myColor)
                    {
                        coups[chercher_coup(listeCoups,voisins1.cases[j],d)]+=10;
                    }
                    if(currentPosition.cols[voisins1.cases[j]].nb+currentPosition.cols[o].nb==5
                       && currentPosition.cols[voisins1.cases[j]].couleur!=myColor
                       && currentPosition.cols[voisins1.cases[j]].couleur!=VIDE)
                    {
                        coups[chercher_coup(listeCoups,voisins1.cases[j],d)]-=10;
                    }
                    if(currentPosition.cols[voisins1.cases[j]].nb+currentPosition.cols[o].nb<=3
                       && currentPosition.cols[voisins1.cases[j]].couleur!=myColor
                       && currentPosition.cols[voisins1.cases[j]].couleur!=VIDE)
                    {
                        coups[chercher_coup(listeCoups,voisins1.cases[j],d)]+=5;
                    }
                    if(currentPosition.cols[voisins1.cases[j]].nb+currentPosition.cols[o].nb<=3
                       && currentPosition.cols[voisins1.cases[j]].couleur==myColor)
                    {
                        coups[chercher_coup(listeCoups,voisins1.cases[j],d)]+=6;
                    }
                }
            }
        }

        if(currentPosition.cols[o].couleur!= VIDE && currentPosition.cols[o].couleur!=myColor
                && currentPosition.cols[d].couleur!= VIDE && currentPosition.cols[d].couleur!=myColor
                && (currentPosition.cols[o].nb+currentPosition.cols[d].nb)<=3)
        {
            for(j=0;j<voisins2.nb;j++)
            {
                if ((currentPosition.cols[o].nb + currentPosition.cols[d].nb + currentPosition.cols[voisins2.cases[j]].nb) == 5)
                {
                    coups[i] -= 40;
                }
                else
                {
                    coups[i] += 5;
                }
            }
        }

        flag = 0;
        voisins2=getVoisins(d);
        if( currentPosition.cols[o].couleur == myColor && currentPosition.cols[d].couleur != myColor)
        {
        	for(j=0;j<voisins2.nb;j++)
        	{
	      
        		if(currentPosition.cols[o].nb + currentPosition.cols[d].nb + currentPosition.cols[voisins2.cases[j]].nb == 5
                   && currentPosition.cols[o].nb + currentPosition.cols[d].nb < 5)
                {
                    flag = 1;
                }

                if(currentPosition.cols[o].nb + currentPosition.cols[d].nb + currentPosition.cols[voisins2.cases[j]].nb == 5
                        && currentPosition.cols[voisins2.cases[j]].couleur != myColor && currentPosition.cols[voisins2.cases[j]].couleur != VIDE)
                {
                    flag = 1;
                }
        		//if(currentPosition.cols[])
	        }
	        if(flag != 1)
	        {
	        	coups[i] += 15;																		//A voir
	        }else{
	        	coups[i] -=12;
	        }
        }
        else if( currentPosition.cols[o].couleur == myColor && currentPosition.cols[d].couleur == myColor)
        {
        	for(j=0;j<voisins2.nb;j++)
        	{
	      
        		if(currentPosition.cols[o].nb + currentPosition.cols[d].nb + currentPosition.cols[voisins2.cases[j]].nb == 5
                   && currentPosition.cols[o].nb + currentPosition.cols[d].nb < 5)
                {
                    flag = 1;
                }
                if(currentPosition.cols[o].nb + currentPosition.cols[d].nb + currentPosition.cols[voisins2.cases[j]].nb == 5
                   && currentPosition.cols[voisins2.cases[j]].couleur != myColor && currentPosition.cols[voisins2.cases[j]].couleur != VIDE)
                {
                    flag = 1;
                }
	        }
	        if(flag != 1)
	        {
	        	coups[i] += 8;																			//A voir
	        }else{
	        	coups[i] -=12;
	        }
        }

        flag=0;
        voisins2=getVoisins(d);
        for(j=0;j<voisins2.nb;j++)
        {
            if(currentPosition.cols[voisins2.cases[j]].couleur != myColor && currentPosition.cols[voisins2.cases[j]].couleur != VIDE)
            {
                flag=1;
            }
        }
        if(flag != 1)
        {
            coups[i] += 10;																			//A voir
        }


        voisins2=getVoisins(d);
        for(j=0;j<voisins2.nb;j++)
        {
            if(currentPosition.cols[o].couleur!=myColor)
            {
                if ((currentPosition.cols[o].nb + currentPosition.cols[d].nb +
                     currentPosition.cols[voisins2.cases[j]].nb) == 5)
                {
                    coups[i] -= 40;
                }
                else
                {
                    coups[i] += 2;
                }
            }
            if(currentPosition.cols[o].couleur==myColor)
            {
                if ((currentPosition.cols[o].nb + currentPosition.cols[d].nb +
                     currentPosition.cols[voisins2.cases[j]].nb) == 5 && currentPosition.cols[voisins2.cases[j]].couleur!=myColor)
                {
                    coups[i] -= 40;
                }
                else
                {
                    coups[i] += 2;
                }
            }
        }

        if(currentPosition.cols[d].couleur!=VIDE && currentPosition.cols[d].couleur!=myColor
           && currentPosition.cols[o].nb==2 && currentPosition.cols[d].nb==1)
        {
            voisins2=getVoisins(d);
            for(j=0;j<voisins2.nb;j++)
            {
                if(currentPosition.cols[voisins2.cases[j]].nb!=1
                   && currentPosition.cols[voisins2.cases[j]].nb!=VIDE
                   && currentPosition.cols[voisins2.cases[j]].nb!=myColor)
                {
                    coups[i]-=5;
                }
                else
                {
                    coups[i]+=8;
                }
            }
        }
    }

    maxi=-10000;
    for(i=0;i<listeCoups.nb;i++)
    {
        //printf(" %d |",coups[i]);
        if(maxi<coups[i])
        {
            //printf("<-- %d --> coups: %d",coups[i], i);
            maxi=coups[i];
            jeu=i;
        }
    }

    ecrireIndexCoup(jeu);
}

int chercher_coup(T_ListeCoups coups, octet ori, octet dest)
{
    int i;
    octet o,d;

    for(i=0;i<coups.nb;i++)
    {
        o = coups.coups[i].origine;
        d = coups.coups[i].destination;
        if(o==ori && d==dest)
        {
            return i;
        }
    }
    return 295;
}
