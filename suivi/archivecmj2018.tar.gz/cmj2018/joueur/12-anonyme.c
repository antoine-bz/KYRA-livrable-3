/********* Moteur de tournoi : joueur ***************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "avalam.h"
#include "moteur.h"
#define MAX_ELT 300

/*
typedef struct
{
	int origine;
	int destination;
	int hauteurPossible;
	
}CoupPossible;

typedef struct 
{
	CoupPossible Tab[MAX_ELT];
}EnsembleCoups;
*/


int CompterVoisins (T_Position currentPosition, T_Voisins voisins) {
    int compteur = 0;
    for (int j = 0 ; j < voisins.nb ; j++) {
        //printf("valeur de la case voisinne : %d \n", currentPosition.cols[voisins.cases[j]].nb);
        if (currentPosition.cols[voisins.cases[j]].nb != 0) compteur++;
    }
    return compteur;
}

int ContrerIsolement (T_Position currentPosition, T_ListeCoups listeCoups) {
    T_Voisins voisins;
    octet myColor = currentPosition.trait;
    octet o = 0, d = 0;
    int nbVoisins = 0;

    for (int i = 0 ; i <= NBCASES ; i++) {
    	if (currentPosition.cols[i].nb != 0 )
    	{
	        if (currentPosition.cols[i].couleur != myColor){
	            voisins = getVoisins(i);
	            nbVoisins = CompterVoisins(currentPosition, voisins);
	            if (nbVoisins == 1) {
	                //printf("La case %d a 1 voisin !!!!!\n", i);
	                if (currentPosition.cols[voisins.cases[0]].couleur == myColor){
	                    printf("isolement trouvé\n");
	                    o = voisins.cases[0];
	                    d = i;
	                }
	                else {
	                    printf("isolement trouvé\n");
	                    d = voisins.cases[0];
	                    o = i;
	                }
	            }
	        }
    	}
    }
    if (o == d) {
        printf("pas d'isolement\n");
        return -1; // si on a pas trouvé de coups dans l'analyse de plateau
    }
    else {              // sinon on joue le coup qu'on a trouvé
        printf("ON CONTRE L'ISOLEMENT");
        for (int j = 0; j < listeCoups.nb; ++j) { // les coups de bases jaunes  
            if(o == listeCoups.coups[j].origine
            && d == listeCoups.coups[j].destination) {
                printf(" AVEC %d\n", j);
                return j;
            }
        }
    }
}


int ControlIsolement(T_Position currentPosition, octet o, octet d){

	octet myColor = currentPosition.trait;
	T_Voisins v =  getVoisins(o);
	int k = 0;
	int valide = 0, flag = 1;

	while(k < v.nb && flag ==1){
		//printf("go check mes voisins (case %d) ",o);
		if (currentPosition.cols[v.cases[k]].nb != 0)
		{
			//printf("Le voisin est bien la\n");
			T_Voisins v_v = getVoisins(v.cases[k]);
				if (v_v.nb > 1)
				{
					//printf("Il a plus qu'un voisin donc je peux partir !\n");
					valide = 1;
					flag = 0;
				}else{
					valide = 0;
				}
			}
			k++;
		}
	return valide;

}



int ControlVoisin(T_Position currentPosition, octet o, octet d){

	octet myColor = currentPosition.trait;
	T_Voisins v =  getVoisins(d);
	int k = 0;
	int valide = 0, flag = 1;

	while(k < v.nb && flag ==1){
		//printf("go check les voisins de %d \n",d );
		if (currentPosition.cols[v.cases[k]].nb != 0)
		{
			//printf("Le voisin est bien la\n");
				if ((currentPosition.cols[o].couleur == myColor) && (currentPosition.cols[o].nb + currentPosition.cols[d].nb + currentPosition.cols[v.cases[k]].nb) == 5)
				{
					//printf("origine : %d , destination : %d , voisin de %d : %d \n",o,d,d, v.cases[k]);
					if (strcmp(COLNAME(currentPosition.cols[o].couleur),COLNAME(currentPosition.cols[v.cases[k]].couleur)))
					{
						//printf("Il n'est pas de la meme couleur\n");
						flag = 0;
						valide = 0;
					}
				}else{
					valide = 1;
				}
				
			}
			k++;
		}
	return valide;
}


void choisirCoup(T_Position currentPosition, T_ListeCoups listeCoups) {
	octet myColor = currentPosition.trait;
	octet o,d;
    T_Voisins voisinO, voisinD;
    octet oCoul, dCoul;
	int a,i = 0, coup = 0;
    int ana_plateau;
    
    ana_plateau = ContrerIsolement(currentPosition, listeCoups);
    if(ana_plateau != -1){
        ecrireIndexCoup(ana_plateau);
        return;
    }

    if (myColor == ROU){ // ******************************      ROUGE               
        //printf("Je suis rouge\n");
        for (int j = 0; j < listeCoups.nb; ++j) { // les premiers mouvs très importants
            o = listeCoups.coups[j].origine;
            voisinO = getVoisins(o);
            d = listeCoups.coups[j].destination;
            voisinD = getVoisins(d);

           if ((o == 18 && d == 19) || (o == 29 && d == 28)
           && currentPosition.cols[d].nb != 3
            && currentPosition.cols[d].couleur != myColor
            && currentPosition.cols[o].couleur == myColor){ // 18 -> 19
               ecrireIndexCoup(j);
               return;
            }
            else if (o == 29 && d == 28 && currentPosition.cols[d].couleur != myColor)                                                     // le tricks en 28
            {
                ecrireIndexCoup(j);
                return;
            }
        }
    }
/*
PARTIE DES PREMIERS COUPS MAIS NON FONCTIONNELLE APRES REGROUPEMENT
for (int j = 0; j < listeCoups.nb; ++j) { // les premiers mouvs très importants
        o = listeCoups.coups[j].origine;
        voisinO = getVoisins(o);
        d = listeCoups.coups[j].destination;
		voisinD = getVoisins(d);
		oCoul = currentPosition.cols[o].couleur;
		dCoul = currentPosition.cols[d].couleur;
		if((currentPosition.cols[27].couleur == JAU) && ((o == 35) && (d == 27))){
			ecrireIndexCoup(j);
			return;
		}
		if(o == 18 && d ==19){
			ecrireIndexCoup(j);
			return;
		}
		if((((currentPosition.cols[19].couleur == ROU) && (currentPosition.cols[27].couleur == ROU)) || ((currentPosition.cols[19].nb == 3) && (currentPosition.cols[19].couleur == ROU)) || ((currentPosition.cols[27].nb == 3) && (currentPosition.cols[19].couleur == ROU))) && ((o == 26) && (d == 34))){
			ecrireIndexCoup(j);
			return;
		}
		if((currentPosition.cols[19].couleur == JAU) && (currentPosition.cols[27].couleur == ROU) && ((o == 27) && (d == 19))){
			ecrireIndexCoup(j);
			return;
		}
		if((currentPosition.cols[27].couleur == JAU) && (currentPosition.cols[19].couleur == ROU) && ((o == 19) && (d == 27))){
			ecrireIndexCoup(j);
			return;
		}
        
}

for (int j = 0; j < listeCoups.nb; ++j) { // les premiers mouvs très importants
	    o = listeCoups.coups[j].origine;
	    voisinO = getVoisins(o);
	    d = listeCoups.coups[j].destination;
		voisinD = getVoisins(d);
		oCoul = currentPosition.cols[o].couleur;
		dCoul = currentPosition.cols[d].couleur;
		if((currentPosition.cols[20].couleur == JAU) && ((o == 12) && (d == 20))){
			ecrireIndexCoup(i);
			return;
		}
		if(o == 29 && d == 28){
			ecrireIndexCoup(i);
			return;
		}
		if((((currentPosition.cols[28].couleur == ROU) && (currentPosition.cols[20].couleur == ROU)) || ((currentPosition.cols[28].nb == 3) && (currentPosition.cols[28].couleur == ROU)) || ((currentPosition.cols[20].nb == 3) && (currentPosition.cols[28].couleur == ROU))) && ((o == 21) && (d == 13))){
			ecrireIndexCoup(i);
			return;
		}
		if((currentPosition.cols[28].couleur == JAU) && (currentPosition.cols[20].couleur == ROU) && ((o == 20) && (d == 28))){
			ecrireIndexCoup(i);
			return;
		}
		if((currentPosition.cols[20].couleur == JAU) && (currentPosition.cols[28].couleur == ROU) && ((o == 28) && (d == 20))){
			ecrireIndexCoup(i);
			return;
		}
        
}
        for (int j = 0; j < listeCoups.nb; ++j) {           
            o = listeCoups.coups[j].origine;
            voisinO = getVoisins(o);
            d = listeCoups.coups[j].destination;
            voisinD = getVoisins(d);
            if ( (currentPosition.cols[o].couleur != myColor)
            && (currentPosition.cols[d].couleur != myColor)
            && (currentPosition.cols[d].nb != 4)
            ) {
                printf("On choisit le coup %d \n", j);
                ecrireIndexCoup(j);
                return; // on quitte la fonction
            }
    }
    for (int j = 0; j < listeCoups.nb; ++j) {           // Si je peux gagner une colonne, je la prends
        o = listeCoups.coups[j].origine;
        voisinO = getVoisins(o);
        d = listeCoups.coups[j].destination;
        voisinD = getVoisins(d);
        if ((currentPosition.cols[o].couleur == myColor)
        && (currentPosition.cols[d].couleur != myColor)
        && (currentPosition.cols[d].nb != 4)
        ) {
            printf("On joue jaune sur jaune \n");
            ecrireIndexCoup(j);
            return; // on quitte la fonction
        }else{
        // *********************************             JAUNE
        printf("Je suis jaune\n");
		for (i = 0; i<listeCoups.nb; i++){
		o = listeCoups.coups[i].origine;
		d = listeCoups.coups[i].destination;
		oCoul = currentPosition.cols[o].couleur;
		dCoul = currentPosition.cols[d].couleur;
			if((o == 8 && (d == 4)) && (oCoul == myColor) && (dCoul != myColor)){
			ecrireIndexCoup(i);
			return;
		}
		if(currentPosition.cols[4].nb == 3){
			if((o == 9) && (d == 16)){
				ecrireIndexCoup(i);
				return;
			}else{
				if((o == 7) && (d == 12)){
					ecrireIndexCoup(i);
					return;
				}
			}
		}else{
			if((currentPosition.cols[3].nb == 2) && (currentPosition.cols[4].nb == 2)){
				if((currentPosition.cols[3].couleur == JAU) && ((o == 6) && (d == 2))){
					ecrireIndexCoup(i);
					return;
					}else{
						if((currentPosition.cols[3].couleur == ROU) && ((o == 3) && (d == 2))){
							ecrireIndexCoup(i);
							return;
							}else{
								if((currentPosition.cols[4].nb == 2) && (currentPosition.cols[4].couleur == JAU)){
									if(currentPosition.cols[0].nb == 2){
										if((currentPosition.cols[0].couleur == ROU) && ((o == 4) && (d == 0))){
											ecrireIndexCoup(i);
										return;
		}else{
			if((currentPosition.cols[0].couleur == JAU) && ((o == 3) && (d == 2))){
				ecrireIndexCoup(i);
				return;
									}
								}
							}
						}	
					}
				}
			}
		}
	}
}
}

for (i = 0; i<listeCoups.nb; i++){
	o = listeCoups.coups[i].origine;
	d = listeCoups.coups[i].destination;
	oCoul = currentPosition.cols[o].couleur;
	dCoul = currentPosition.cols[d].couleur;
	if((o == 39) && (d == 43) && (oCoul == myColor) && (dCoul != myColor)){
		ecrireIndexCoup(i);
		return;
	}
	if(currentPosition.cols[43].nb == 3){
		if((o == 38) && (d == 31)){
			ecrireIndexCoup(i);
			return;
		}else{
			if((o == 40) && (d == 35)){
				ecrireIndexCoup(i);
				return;
			}
		}
	}else{
		if((currentPosition.cols[44].nb == 2) && (currentPosition.cols[43].nb == 2)){
			if((currentPosition.cols[3].couleur == JAU) && ((o == 41) && (d == 45))){
				ecrireIndexCoup(i);
				return;
				}else{
					if((currentPosition.cols[3].couleur == ROU) && ((o == 44) && (d == 45))){
						ecrireIndexCoup(i);
						return;	
							}else{
								if((currentPosition.cols[43].nb == 2) && (currentPosition.cols[43].couleur == JAU)){
									if(currentPosition.cols[47].nb == 2){
										if((currentPosition.cols[47].couleur == ROU) && ((o == 43) && (d == 47))){
											ecrireIndexCoup(i);
											return;
											}else{
												if((currentPosition.cols[47].couleur == JAU) && ((o == 44) && (d == 45))){
													ecrireIndexCoup(i);
													return;
												}
											}
										}
									}	
							}
				}
		}
	}
}

        for (int j = 0; j < listeCoups.nb; ++j) { // les coups de bases jaunes  
            o = listeCoups.coups[j].origine;
            voisinO = getVoisins(o);
            d = listeCoups.coups[j].destination;
            voisinD = getVoisins(d);

            if ((o == 16 && d == 11) || (o == 31 && d == 36)
            && currentPosition.cols[d].nb != 3
            && currentPosition.cols[d].couleur != myColor
            && currentPosition.cols[o].couleur == myColor){
                printf("On joue 16 -> 11 \n");
                ecrireIndexCoup(j);
                return; // on quitte la fonction
            }

            if (currentPosition.cols[11].nb == 3
                && currentPosition.cols[11].couleur == ROU){
                if((o == 10 && d == 11) || (o == 17 && d == 11)) {
                    printf("On fait une tour de 3 sur 11 %d\n", d);
                    ecrireIndexCoup(j);
                    return; // on quitte la fonction
                }
            }
        }
        for (int j = 0; j < listeCoups.nb; ++j) { // On prend les tours de 3 ou 5 si possibles
            o = listeCoups.coups[j].origine;
            voisinO = getVoisins(o);
            d = listeCoups.coups[j].destination;
            voisinD = getVoisins(d);
            if ( (currentPosition.cols[o].couleur == myColor) // 
            && (currentPosition.cols[d].couleur != myColor)
            && (currentPosition.cols[d].nb == 4)
            ) {
                printf("On fait une tour de 5 sur %d\n", d);
                ecrireIndexCoup(j);
                return; // on quitte la fonction
            }else if ( (currentPosition.cols[o].couleur == myColor) // On empile les pions adverses
            && (currentPosition.cols[d].couleur != myColor)
            && (currentPosition.cols[d].nb == 2)
            ) {
                printf("On fait une tour de 3 sur %d\n", d);
                ecrireIndexCoup(j);
                return; // on quitte la fonction
            }
        }
*/
	for(i=0;i<listeCoups.nb; i++) {

		o = listeCoups.coups[i].origine;
		d = listeCoups.coups[i].destination;
		int CheckVoisin = ControlVoisin(currentPosition,o,d);
		int CheckIsolement = ControlIsolement(currentPosition,o,d);


		if ((CheckVoisin == 1) && (CheckIsolement == 1))
			{
				printf("Le coup n'est pas risque\n");
			if (currentPosition.cols[o].couleur == myColor)
			{
					/*Cree une tour de 5 si possible*/
				if ((currentPosition.cols[o].couleur == myColor) && ((currentPosition.cols[o].nb+currentPosition.cols[d].nb) == 5)) 
						{
							ecrireIndexCoup(i);
							return;
						}
			
				//printf("je suis bien sur ma couleur\n");
				/*Empeche les tours de 5*/
						T_Voisins v_Atm = getVoisins(d);
				for (int j = 0; j < v_Atm.nb; ++j)
				{
					//printf("je check les voisins de %d\n",d );
					if (currentPosition.cols[v_Atm.cases[j]].nb != 0)
					{
						//printf("le voisin %d n'est pas vide \n",v_Atm.cases[j]);
						if ((currentPosition.cols[d].nb + currentPosition.cols[v_Atm.cases[j]].nb) == 5)
						{
							//printf("on empeche la tour de 5 de se faire !!! \n");
							ecrireIndexCoup(i);
							return;
						}else{
							//printf("%d + %d = %d \n",currentPosition.cols[d].nb, currentPosition.cols[v_Atm.cases[j]].nb,currentPosition.cols[d].nb + currentPosition.cols[v_Atm.cases[j]].nb );
						}
					}
				}

			}

		}
}
while (1) {
		a = rand()%listeCoups.nb;
		o = listeCoups.coups[a].origine; 
		d = listeCoups.coups[a].destination;  
 
		if ( !strcmp(COLNAME(currentPosition.cols[o].couleur),COLNAME(myColor))
		&& (currentPosition.cols[d].nb != 4) ) {
					printf("j'ai trouvé un bon coup de ouf ( %d -> %d)\n",o,d);
			ecrireIndexCoup(a);
			return; // on quitte la fonction 
		}
	}
}
