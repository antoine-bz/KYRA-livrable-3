/********* Moteur de tournoi : joueur ***************/

#include <stdio.h>
#include <stdlib.h>
#include "avalam.h"
#include "moteur.h"


void choisirCoup(T_Position currentPosition, T_ListeCoups listeCoups) {
	// Cette fonction peut appeler la fonction ecrireIndexCoup(coupChoisi);
	// Pour sélectionner l'index d'un coup à jouer dans la liste l 

	// aléatoire 
	// ecrireIndexCoup(rand()%listeCoups.nb);

	int i,h;
	int j=0; 
	octet o, d; 
	int a; 
	octet myColor = currentPosition.trait; 
	T_Voisins Voisin;
	// afficherListeCoups(listeCoups);

	printf("Ma couleur : %s\n", COLNAME(currentPosition.trait));
// Tout d'abords voyons si une tour de 5 est faisable
	for(i=0;i<listeCoups.nb; i++) 
	{
		o = listeCoups.coups[i].origine; 
		d = listeCoups.coups[i].destination;
		Voisin = getVoisins(d);  

		printf("Coup %d : ", i); 
		printf("%d (%d - %s) ->", o, currentPosition.cols[o].nb, COLNAME(currentPosition.cols[o].couleur));
		printf("%d (%d - %s) \n", d, currentPosition.cols[d].nb, COLNAME(currentPosition.cols[d].couleur)); 

// Si je peux gagner une colonne, je la prends (1+4, 2+3 ...)
	if ((currentPosition.cols[o].couleur == myColor)
	  &&(currentPosition.cols[o].nb+currentPosition.cols[d].nb == 5)
	  &&(currentPosition.cols[d].couleur!=myColor))
		{
			if(currentPosition.cols[d].couleur != myColor)
			{
				printf("On choisit T5 ! \n"); 
				ecrireIndexCoup(i);
				return; // on quitte la fonction 
			}
		}
	}

// Maintenant qu'aucune tour de 5 n'est faisable, passons aux tours de 4,3 et 2 dans cet ordre bien précis et voyons la partie isolement de tour

// Voici la partie isolation d'une tour adverse pour nous permettre d'avoir une tour facile
	for(i=0;i<listeCoups.nb; i++) 
	{
		o = listeCoups.coups[i].origine; 
		d = listeCoups.coups[i].destination;
		Voisin = getVoisins(d);

		if ((currentPosition.cols[o].couleur == myColor)
	  	 &&(currentPosition.cols[d].couleur!=myColor))
	  	{	
			j=0;	
			for (h=0; h<=Voisin.nb;h++)
			{
				if( currentPosition.cols[Voisin.cases[h]].nb == 5)
				{
					j++;
				}
				if(currentPosition.cols[Voisin.cases[h]].nb == 0)
				{
					j++;
				}	
			}
			if (j == Voisin.nb)
			{
				printf("On choisit d'isoler ! \n"); 
				ecrireIndexCoup(i);
				return; // on quitte la fonction
			}
	  	}
	}

	for(i=0;i<listeCoups.nb; i++) 
	{
		o = listeCoups.coups[i].origine; 
		d = listeCoups.coups[i].destination;
		Voisin = getVoisins(d);

		if ((currentPosition.cols[o].couleur == myColor)
	  	 &&(currentPosition.cols[d].couleur != myColor))
	  	{	
			j=0;	
			for (h=0; h<=Voisin.nb;h++)
			{
				if( currentPosition.cols[o].nb + currentPosition.cols[d].nb + currentPosition.cols[Voisin.cases[h]].nb != 5 )
				{
					if((currentPosition.cols[Voisin.cases[h]].nb >= 3)
					 &&(currentPosition.cols[o].nb + currentPosition.cols[d].nb >= 3 ))
					{
						j++;
					}
				}
			}
			if (j == Voisin.nb)
			{
				printf("On choisit d'isoler2 ! \n"); 
				ecrireIndexCoup(i);
				return; // on quitte la fonction
			}
	  	}
	}

// C'est la fin de la partie isolation d'une tour 

// On essaye ici de contrer un isolement qui serai fait contre nous 
	for(i=0;i<listeCoups.nb; i++) 
	{
		o = listeCoups.coups[i].origine; 
		d = listeCoups.coups[i].destination;
		Voisin = getVoisins(o);

		if ((currentPosition.cols[o].couleur == myColor)
	  	 &&(currentPosition.cols[d].couleur!=myColor))
	  	{	
			j=0;	
			printf("%d voisins\n",Voisin.nb);
			for (h=0; h<=Voisin.nb;h++)
			{
				if( currentPosition.cols[Voisin.cases[h]].nb == 5)
				{
					j++;
				}
				if(currentPosition.cols[Voisin.cases[h]].nb == 0)
				{
					j++;
				}	
			}
			if (j == Voisin.nb)
			{
				printf("On choisit de contrer l'isolement ! \n"); 
				ecrireIndexCoup(i);
				return; // on quitte la fonction
			}
	  	}
	}
// C'est la fin de la partie qui contre l'isolement


//ici, cela déplace une tour de 1 ou 2 ou 3 adverse sur une autre tour de respectivement 3 ou 2 ou 1 adverse tout en vérifiant qu'une tour de 2 ne fait pas partie des voisins de la tour destinataire
	for(i=0;i<listeCoups.nb; i++) 
	{
		o = listeCoups.coups[i].origine; 
		d = listeCoups.coups[i].destination;
		Voisin = getVoisins(d);
		if((currentPosition.cols[o].nb+currentPosition.cols[d].nb == 4) 
		 &&(currentPosition.cols[o].couleur!=myColor) 
		 &&(currentPosition.cols[d].couleur!=myColor))
		{
			j=0;
			for (h=0; h<=Voisin.nb;h++)
			{
				if( currentPosition.cols[Voisin.cases[h]].nb == 1)
				{
					j++;
				} 
			}
			if (j==0){
					printf("On choisit T4 ! \n"); 
					ecrireIndexCoup(i);
					return; // on quitte la fonction 	
				}
		}
	}
// Fin de déplacement de pions 1 ou 2 ou 3 sur respectivement 3 ou 2 ou 1 adverse

//ici, cela déplace une tour de 2 ou 1 adverse sur une autre tour de respectivement 1 ou 2 adverse tout en vérifiant qu'une tour de 2 ne fait pas partie des voisins de la tour destinataire
	for(i=0;i<listeCoups.nb; i++) 
	{
		o = listeCoups.coups[i].origine; 
		d = listeCoups.coups[i].destination;
		Voisin = getVoisins(d);
		if ((currentPosition.cols[o].nb+currentPosition.cols[d].nb == 3) 
		 &&(currentPosition.cols[o].couleur!=myColor) 
		 &&(currentPosition.cols[d].couleur!=myColor))
		{
			j=0;
			for (h=0; h<=Voisin.nb;h++)
			{
				if( currentPosition.cols[Voisin.cases[h]].nb == 2)
				{
					j++;
				} 
			}
			if (j==0){
					printf("On choisit T3! \n"); 
					ecrireIndexCoup(i);
					return; // on quitte la fonction 	
				}
		}
	}
	
// Fin de déplacement de pions 1 ou 2 sur respectivement 2 ou 1 adverse

//ici, cela déplace une tour de 1 adverse sur une autre tour de 1 adverse tout en vérifiant qu'une tour de 3 ne fait pas partie des voisins de la tour destinataire
	for(i=0;i<listeCoups.nb; i++) 
	{
		o = listeCoups.coups[i].origine; 
		d = listeCoups.coups[i].destination;
		Voisin = getVoisins(d);
		if ((currentPosition.cols[o].nb+currentPosition.cols[d].nb == 2) 
		  &&(currentPosition.cols[o].couleur!=myColor) 
		  &&(currentPosition.cols[d].couleur!=myColor))
		{
			j=0;
			for (h=0; h<=Voisin.nb;h++)
			{
				if(currentPosition.cols[Voisin.cases[h]].nb == 3)
				{
					j++;
				} 
			}
			if (j==0)
			{
					printf("On choisit T2 ! \n"); 
					ecrireIndexCoup(i);
					return; // on quitte la fonction 	
			}
		}
	}
// Fin de déplacement de pions 1 sur 1 adverse

// Voila exactement la même technique qu'au dessus sauf qu'on place une tour allié sur une tour adverse
for(i=0;i<listeCoups.nb; i++) 
	{
		o = listeCoups.coups[i].origine; 
		d = listeCoups.coups[i].destination;
		Voisin = getVoisins(d);
		if ((currentPosition.cols[o].nb+currentPosition.cols[d].nb == 4) 
		  &&(currentPosition.cols[o].couleur==myColor) 
		  &&(currentPosition.cols[d].couleur!=myColor))
		{
			j=0;
			for (h=0; h<=Voisin.nb;h++)
			{
				if(currentPosition.cols[Voisin.cases[h]].nb == 1)
				{
					j++;
				} 
			}
			if (j==0){
					printf("On choisit T4 v2 ! \n"); 
					ecrireIndexCoup(i);
					return; // on quitte la fonction 	
				}
		}
	}

	for(i=0;i<listeCoups.nb; i++) 
	{
		o = listeCoups.coups[i].origine; 
		d = listeCoups.coups[i].destination;
		Voisin = getVoisins(d);
		if ((currentPosition.cols[o].nb+currentPosition.cols[d].nb == 3) 
		  &&(currentPosition.cols[o].couleur==myColor) 
		  &&(currentPosition.cols[d].couleur!=myColor))
		{
			j=0;
			for (h=0; h<=Voisin.nb;h++)
			{
				if(currentPosition.cols[Voisin.cases[h]].nb == 2)
				{
					j++;
				} 
			}
			if (j==0){
					printf("On choisit T3 v2 ! \n"); 
					ecrireIndexCoup(i);
					return; // on quitte la fonction 	
				}
		}
	}

	for(i=0;i<listeCoups.nb; i++) 
	{
		o = listeCoups.coups[i].origine; 
		d = listeCoups.coups[i].destination;
		Voisin = getVoisins(d);
		if ((currentPosition.cols[o].nb+currentPosition.cols[d].nb == 2) 
		  &&(currentPosition.cols[o].couleur==myColor) 
		  &&(currentPosition.cols[d].couleur!=myColor))
		{
			j=0;
			for (h=0; h<=Voisin.nb;h++)
			{
				if(currentPosition.cols[Voisin.cases[h]].nb == 3)
				{
					j++;
				} 
			}
			if (j==0){
					printf("On choisit T2 v2 ! \n"); 
					ecrireIndexCoup(i);
					return; // on quitte la fonction 	
				}
		}
	}
// Fin de la technique qui place une tour alliée sur une tour adverse.

// Ici c'est lorsque on place un pion allié sur un pions adverse sans juger si ce coup est bien ! C'est la coup dit de désespoir 
	for(i=0;i<listeCoups.nb; i++) 
	{
		o = listeCoups.coups[i].origine; 
		d = listeCoups.coups[i].destination;
		if ((currentPosition.cols[o].couleur==myColor) && (currentPosition.cols[d].couleur!=myColor))
		{
			printf("On choisit le coup de désespoir ! \n"); 
			ecrireIndexCoup(i);
			return; // on quitte la fonction
		}
	}
}


