//
// Created by gregoire on 19/05/18.
//
#define max(a,b) \
   ({ __typeof__ (a) _a = (a); \
       __typeof__ (b) _b = (b); \
     _a > _b ? _a : _b; })

#define min(a,b) \
   ({ __typeof__ (a) _a = (a); \
       __typeof__ (b) _b = (b); \
     _a < _b ? _a : _b; })

#include <stdio.h>
#include "avalam.h"
#include "topologie.h"
#include "moteur.h"
#include <stdlib.h>
#include <unistd.h>
#include <stdbool.h>
#include <time.h>
#include <pthread.h>

bool seulvoisin5(T_Voisins voisins,T_Position p );
bool pionIsole(int x, T_Position p);
int evaluation(T_Position plateau, octet color);
//static void  *evaluation (void *  p, void* c,void * s, void * v);
int minmaxr (T_Position p , int depth,int * ajouer,octet Mycolor);
int minmaxj (T_Position p , int depth,int * ajouer,octet Mycolor);








void choisirCoup(T_Position currentPosition, T_ListeCoups listeCoups) {
    // Cette fonction peut appeler la fonction ecrireIndexCoup(coupChoisi);
    // Pour sélectionner l'index d'un coup à jouer dans la liste l

    int move = 1;
    int i;
    octet o, d;
    octet myColor = currentPosition.trait;
    int coupJoue = 0;


    printf("\n\n\n\n JE SUIS : %d \n\n\n\n", myColor);



    // afficherListeCoups(listeCoups);

    printf("Ma couleur : %s\n", COLNAME(currentPosition.trait));
    for (i = 0; i < listeCoups.nb; i++) {
        o = listeCoups.coups[i].origine;
        d = listeCoups.coups[i].destination;
        printf("Coup %d : ", i);
        printf("%d (%d - %s) ->", o, currentPosition.cols[o].nb, COLNAME(currentPosition.cols[o].couleur));
        printf("%d (%d - %s) \n", d, currentPosition.cols[d].nb, COLNAME(currentPosition.cols[d].couleur));


        //On fait les coups d'ouverture jaune si on peut
        if (o == 12 && d == 20 && currentPosition.cols[o].couleur != myColor &&
            currentPosition.cols[d].couleur != myColor && currentPosition.cols[d].couleur != 0 &&
            currentPosition.cols[o].nb == 1 &&
            currentPosition.cols[d].nb == 1 && currentPosition.cols[o + 9].nb == 1) {
            printf("--- Coup ouverture jaune 1 ! ---\n");

            ecrireIndexCoup(i);
            coupJoue = 1;
            return;
        }
        if (o == 29 && d == 20 && currentPosition.cols[o].couleur != myColor &&
            currentPosition.cols[d].couleur != myColor && currentPosition.cols[d].couleur != 0 &&
            currentPosition.cols[o].nb == 1 && currentPosition.cols[o - 8].nb == 1) {
            printf("--- Coup ouverture jaune 2 ! ---\n");
            ecrireIndexCoup(i);
            coupJoue = 1;
            return;
        }



        //On fait les coups d'ouverture rouge si on peut
        if (o == 42 && d == 46 && currentPosition.cols[o].couleur != myColor &&
            currentPosition.cols[d].couleur != myColor && currentPosition.cols[d].couleur != 0 &&
            currentPosition.cols[o].nb == 1) {
            printf("---  Coup ouverture rouge 1 ! ---\n");
            ecrireIndexCoup(i);
            coupJoue = 1;
            return;
        }
        if (o == 44 && d == 46 && currentPosition.cols[o].couleur != myColor &&
            currentPosition.cols[d].couleur != myColor && currentPosition.cols[o].nb == 1) {
            printf("---  Coup ouverture rouge 2 ! ---\n");
            ecrireIndexCoup(i);
            coupJoue = 1;
            return;
        }


        //Si je peux gagner une colonne, je la prends (1+4, 2+3 ...)
        if ((currentPosition.cols[o].couleur == myColor) &&
            ((currentPosition.cols[o].nb + currentPosition.cols[d].nb) == 5)) {

            if (currentPosition.cols[d].couleur != myColor) {
                printf("Je fais une pile de 5 ! \n");
                ecrireIndexCoup(i);
                coupJoue = 1;
                return;
            }
        }


        T_Voisins voisinsD;
        int nbVoisinsIsole = 0;

        for (i = 0; i < listeCoups.nb; i++) {
            o = listeCoups.coups[i].origine;
            d = listeCoups.coups[i].destination;
            voisinsD = getVoisins(d);
            nbVoisinsIsole = 0;
            if (currentPosition.cols[d].couleur != myColor &&
                (currentPosition.cols[o].nb + currentPosition.cols[d].nb) <= 5) {
                for (int m = 0; m < voisinsD.nb; m++) {
                    if (currentPosition.cols[voisinsD.cases[m]].couleur != 0 ||
                        currentPosition.cols[voisinsD.cases[m]].nb != 5) {
                        nbVoisinsIsole++;
                    }
                }
                if (nbVoisinsIsole == 1) {
                    printf("J'isole un pion ! \n");
                    ecrireIndexCoup(i);
                    coupJoue = 1;
                }
            }
        }

        for (i = 0; i < listeCoups.nb; i++) {
            o = listeCoups.coups[i].origine;
            d = listeCoups.coups[i].destination;
/*
            //Si on voit 2 piles isolées de couleurs différentes, on empile direct
            if (nbVoisins(o) == 1 && currentPosition.cols[o].couleur == myColor &&
                currentPosition.cols[d].couleur != myColor &&
                ((currentPosition.cols[o].nb + currentPosition.cols[d].nb) == 5) && coupJoue != 1) {
                printf("**** J'empile 2 pions isolés! ****");
                ecrireIndexCoup(i);
                coupJoue = 1;
            }*/

//      DIAGRAMMES
            if (currentPosition.cols[o].nb == 2 && currentPosition.cols[o].couleur == myColor
                && currentPosition.cols[o + 1].nb == 1 && currentPosition.cols[o + 1].couleur != myColor
                && currentPosition.cols[o - 1].nb == 1 && currentPosition.cols[o - 1].couleur != myColor
                && currentPosition.cols[o + 9].nb == 1 && currentPosition.cols[o + 9].couleur != myColor
                && currentPosition.cols[o - 8].nb == 1 && currentPosition.cols[o - 8].couleur != myColor
                && currentPosition.cols[o + 8].nb == 1 && currentPosition.cols[o + 8].couleur == myColor
                && d == o - 1 && coupJoue != 1) {
                printf("*-*-* Je fais le premier diag ! *-*-*");
                ecrireIndexCoup(i);
                coupJoue = 1;
            }
            if (currentPosition.cols[o].nb == 1 && currentPosition.cols[o].couleur != myColor
                && currentPosition.cols[o + 1].nb == 1 && currentPosition.cols[o + 1].couleur == myColor
                && currentPosition.cols[o + 2].nb == 2 && currentPosition.cols[o + 2].couleur != myColor
                && currentPosition.cols[o + 3].nb == 2 && currentPosition.cols[o + 3].couleur != myColor
                && currentPosition.cols[o + 6].nb == 1 && currentPosition.cols[o + 6].couleur == myColor
                && currentPosition.cols[o + 7].nb == 1 && currentPosition.cols[o + 7].couleur != myColor
                && currentPosition.cols[o + 8].nb == 2 && currentPosition.cols[o + 8].couleur == myColor
                && currentPosition.cols[o - 2].nb == 2 && currentPosition.cols[o - 2].couleur == myColor
                && d == o + 7 && coupJoue != 1) {
                printf("*-*-* je fais le 2nd diag ! *-*-*");
                ecrireIndexCoup(i);
                coupJoue = 1;
            }
            if (currentPosition.cols[o].nb == 2 && currentPosition.cols[o].couleur == myColor
                && currentPosition.cols[o + 1].nb == 2 && currentPosition.cols[o + 1].couleur == myColor
                && currentPosition.cols[o + 7].nb == 1 && currentPosition.cols[o + 2].couleur != myColor
                && currentPosition.cols[o - 3].nb == 2 && currentPosition.cols[o + 3].couleur != myColor
                && currentPosition.cols[o - 4].nb == 1 && currentPosition.cols[o + 6].couleur == myColor
                && currentPosition.cols[o - 6].nb == 2 && currentPosition.cols[o + 7].couleur != myColor
                && currentPosition.cols[o + 2].nb == 0 && currentPosition.cols[o - 2].nb == 0 &&
                currentPosition.cols[o - 5].nb == 0
                && d == o - 3 && coupJoue != 1) {
                printf("*-*-* Je fais le 3ème diag ! *-*-*");
                ecrireIndexCoup(i);
                coupJoue = 1;
            }

            //J'EMPILE LES PIONS ADVERSES
            if (coupJoue != 1 && (currentPosition.cols[o].couleur != myColor) &&
                (currentPosition.cols[d].couleur != myColor) &&
                ((currentPosition.cols[o].nb + currentPosition.cols[d].nb) < 3)) {
                printf("J'empile 2 pions adverses, pas plus ! \n");
                ecrireIndexCoup(i);

            }
        }

        if (myColor == 1) {
            puts("JAUNE");
            int tempscore = minmaxj(currentPosition, 0, &move, currentPosition.trait);
        } else if (myColor == 2) {
            puts("ROUGE");
            int tempscore = minmaxr(currentPosition, 0, &move, currentPosition.trait);
        }
/*
        i = move;
        o = listeCoups.coups[i].origine;
        d = listeCoups.coups[i].destination;
        if(currentPosition.cols[o].nb + currentPosition.cols[d].nb == 4){
            puts("JAI VOULU FAIRE UNE PILE DE 4 \n");
            for(i = 0; i < listeCoups.nb; i++){
                if((currentPosition.cols[o].couleur != myColor) && (currentPosition.cols[d].couleur != myColor) && ((currentPosition.cols[o].nb + currentPosition.cols[d].nb)) < 3) {
                printf("On choisit ce coup ! \n");
                    ecrireIndexCoup(i);
                    return;
                }
            }
        }

*/
        printf("%d\n", move);
        ecrireIndexCoup(move);


    }
}



bool seulvoisin5(T_Voisins voisins,T_Position p ){
    int i =0;
    bool pionEstIsole = true;
    for(i=0; i<voisins.nb;i++){
        if(p.cols[voisins.cases[i]].nb == 5 ||p.cols[voisins.cases[i]].nb == 0){
            continue;
        }else{
            pionEstIsole = false;
        }

    }
    return pionEstIsole;
}

bool pionIsole(int x, T_Position p){
    T_Voisins voisin ;
    bool pionEstIsole = true; // On suppose le pion isolé
    voisin = getVoisins(x);
    for (int i = 0; i < voisin.nb; ++i) {
        if(p.cols[voisin.cases[i]].nb ==0 || p.cols[voisin.cases[i]].nb == 5)    {
            pionEstIsole = true;
        } else
            pionEstIsole = false;
    }
    //seulvoisin5(voisin,p);
    return pionEstIsole;
}

int evaluation(T_Position plateau, octet color){
//static void  *evaluation (void *  p, void* c,void * s, void * v){
    T_Voisins voisins;
    //T_Position * plateau = (T_Position *)p;
    //octet *color = (octet *)c;
    //int *scoreMoi = (int *)s;
    //int *r = (int *)v;
    int scoreMoi = 0;
    int scoreOpp = 0;
    int mespions = 0, sespions = 0;
    const int poidspile4 = 26;
    const int poidspionisole = 21;
    const int poids_pile5 = 12;
    const int pionspossedes = 80;
    const int poids_coin = 0;





    //for (int h = *r-12; h < *r; h++) {
    for (int h = 0; h < 48; ++h) {
        if (plateau.cols[h].nb == 0)
            continue;

        if (plateau.cols[h].nb == color) {
            mespions++;
        } else
            sespions++;


        if (plateau.cols[h].nb == 4 && !pionIsole(h, plateau)) {
            scoreMoi -= poidspile4;
            scoreOpp += poidspile4;
        }


        /**
         * Vérifie si sur une case avec peu de voisins <= 3, on cherche si il y au plus une pile de l'autre couleur et on empile ssi ca fait une pile de 5
         * Vérifie si, en fin de partie, un des voisins d'un de mes pions est seul, cad n'a qu'un voisin. Si oui, on empile . on isole une pile
         */


        voisins = getVoisins(h);
        int auPlusUnVoisin = 0;
        int k;
        if (voisins.nb <= 3 && plateau.cols[h].nb == color) {
            for (k = 0; k < voisins.nb; k++) {
                if (plateau.cols[voisins.cases[k]].nb == 5 || plateau.cols[voisins.cases[k]].couleur == color) {
                    continue;
                } else if (plateau.cols[voisins.cases[k]].couleur != color &&
                           plateau.cols[voisins.cases[k]].nb + plateau.cols[h].nb == 5) {
                    auPlusUnVoisin++;
                    if (auPlusUnVoisin == 1) {
                        scoreMoi += poids_pile5;
                        scoreOpp -= poids_pile5;
                    }
                }
            }
        }

        if (plateau.cols[h].couleur == color) {
            for (k = 0; k < voisins.nb; k++) {

                if (plateau.cols[voisins.cases[k]].couleur != color &&
                    nbVoisins(plateau.cols[voisins.cases[voisins.cases[h]]].nb) == 1 &&
                    plateau.cols[h].nb + plateau.cols[voisins.cases[k]].nb <= 5) {
                    scoreMoi += poidspionisole;
                    scoreOpp -= poidspionisole;
                }
            }
        }




        //gestion des pions placer sur les "coins" pions assez interresant

        switch (h) {
            case 0:
                if (plateau.cols[h].couleur == color) {
                    scoreMoi += poids_coin;
                    scoreOpp -= poids_coin;
                } else if (plateau.cols[h].couleur != color && plateau.cols[h].couleur != VIDE) {
                    scoreMoi -= poids_coin;
                    scoreOpp += poids_coin;
                }
                break;
            case 1:
                if (plateau.cols[h].couleur == color) {
                    scoreMoi += poids_coin;
                    scoreOpp -= poids_coin;
                } else if (plateau.cols[h].couleur != color && plateau.cols[h].couleur != VIDE) {
                    scoreMoi -= poids_coin;
                    scoreOpp += poids_coin;
                }
                break;
            case 20:
                if (plateau.cols[h].couleur == color) {
                    scoreMoi += poids_coin;
                    scoreOpp -= poids_coin;
                } else if (plateau.cols[h].couleur != color && plateau.cols[h].couleur != VIDE) {
                    scoreMoi -= poids_coin;
                    scoreOpp += poids_coin;
                }
                break;
            case 28:
                if (plateau.cols[h].couleur == color) {
                    scoreMoi += poids_coin;
                    scoreOpp -= poids_coin;
                } else if (plateau.cols[h].couleur != color && plateau.cols[h].couleur != VIDE) {
                    scoreMoi -= poids_coin;
                    scoreOpp += poids_coin;
                }
                break;
            case 19:
                if (plateau.cols[h].couleur == color) {
                    scoreMoi += poids_coin;
                    scoreOpp -= poids_coin;
                } else if (plateau.cols[h].couleur != color && plateau.cols[h].couleur != VIDE) {
                    scoreMoi -= poids_coin;
                    scoreOpp += poids_coin;
                }
                break;
            case 27:
                if (plateau.cols[h].couleur == color) {
                    scoreMoi += poids_coin;
                    scoreOpp -= poids_coin;
                } else if (plateau.cols[h].couleur != color && plateau.cols[h].couleur != VIDE) {
                    scoreMoi -= poids_coin;
                    scoreOpp += poids_coin;
                }
                break;
            case 47:
                if (plateau.cols[h].couleur == color) {
                    scoreMoi += poids_coin;
                    scoreOpp -= poids_coin;
                } else if (plateau.cols[h].couleur != color && plateau.cols[h].couleur != VIDE) {
                    scoreMoi -= poids_coin;
                    scoreOpp += poids_coin;
                }
                break;
            case 48:
                if (plateau.cols[h].couleur == color) {
                    scoreMoi += poids_coin;
                    scoreOpp -= poids_coin;
                } else if (plateau.cols[h].couleur != color && plateau.cols[h].couleur != VIDE) {
                    scoreMoi -= poids_coin;
                    scoreOpp += poids_coin;
                }
                break;
            default:;
        }

        if (pionIsole(h, plateau) && plateau.cols[h].couleur == color) {
            scoreMoi += poidspionisole;
            scoreOpp -= poidspionisole;
        } else if (pionIsole(h, plateau) && plateau.cols[h].couleur != color) {
            scoreMoi -= poidspionisole;
            scoreOpp += poidspionisole;
        }

        if (plateau.cols[h].nb == 5) {   // si il ya

            if (plateau.cols[h].couleur == color) {
                scoreMoi += poids_pile5;
                scoreOpp -= poids_pile5;
            } else {
                scoreMoi -= poids_pile5;
                scoreOpp += poids_pile5;
            }

        }
    }


    scoreMoi += mespions * pionspossedes;
    //*scoreMoi += mespions * pionspossedes;
    scoreOpp += sespions * pionspossedes;

    return scoreMoi;
}


int minmaxr (T_Position p , int depth,int * ajouer,octet Mycolor) {
    int  MAXDEPTH = 2;
    int best, Temp;
    T_ListeCoups l = getCoupsLegaux(p);
    if (l.nb<30)
        MAXDEPTH  = 4;
    if (l.nb<30)
        MAXDEPTH  = 6;
    if (depth == MAXDEPTH || l.nb == 0) {
        return evaluation(p,Mycolor);
    }
    if (p.trait == ROU) {
        best = -10000;
        for (int i = 0; i < l.nb; ++i) {
            Temp = minmaxr(jouerCoup(p, l.coups[i].origine, l.coups[i].destination), depth + 1, ajouer, Mycolor);
            if (Temp > best) {
                *ajouer = i;
                best = Temp;
            }
        }
        return best;
    } else if (p.trait == JAU){
        //printf("%d\n",i);
        best=10000;
        for (int i = 0; i < l.nb; ++i) {
            Temp = minmaxr(jouerCoup(p, l.coups[i].origine, l.coups[i].destination), depth + 1, ajouer,Mycolor);
            if (Temp< best) {
                best = Temp;
            }
        }
        return best;
    }
}
int minmaxj (T_Position p , int depth,int * ajouer,octet Mycolor) {
    int  MAXDEPTH = 2;
    int best, Temp;
    T_ListeCoups l = getCoupsLegaux(p);
    if (l.nb<30)
        MAXDEPTH  = 4;
    if (l.nb<30)
        MAXDEPTH  = 6;
    if (depth == MAXDEPTH || l.nb == 0) {
        return evaluation(p,Mycolor);
    }
    if (p.trait == JAU) {
        best = -10000;
        for (int i = 0; i < l.nb; ++i) {
            Temp = minmaxj(jouerCoup(p, l.coups[i].origine, l.coups[i].destination), depth + 1, ajouer,Mycolor);
            if (Temp > best) {
                *ajouer = i;
                best = Temp;
            }
        }
        return best;
    } else if (p.trait == ROU){
        best = 10000;
        for (int i = 0; i < l.nb; ++i) {
            Temp = minmaxj(jouerCoup(p, l.coups[i].origine, l.coups[i].destination), depth + 1, ajouer,Mycolor);
            if (Temp < best) {
                best= Temp;
            }
        }
        return best;

    }
}





//TODO optimiser avec des threads. Ne fonctionne pas encore.
// Une bonne partie des commentaires sont en rapport avec les threads.


/*
int minmaxr (T_Position p , int depth,int * ajouer,octet Mycolor) {

    int  MAXDEPTH = 2;
    /*pthread_t sc1;
    pthread_t sc2;
    pthread_t sc3;
    pthread_t sc4;
    int best, Temp,score1,score2,score3,score4,score,i=12,j;
    T_ListeCoups l = getCoupsLegaux(p);
    if (l.nb<70)
        MAXDEPTH  = 4;
    if (l.nb<30)
        MAXDEPTH  = 6;
    if (depth == MAXDEPTH || l.nb == 0) {
        return evaluation(p,Mycolor);
    }
    /*if (depth == MAXDEPTH || l.nb == 0) {
        pthread_create(&sc1, NULL, evaluation(&p, &Mycolor, &score1, &i), NULL);
        i += 12;
        pthread_create(&sc2, NULL, evaluation(&p, &Mycolor, &score2, &i),NULL);
        i += 12;
        pthread_create(&sc3, NULL, evaluation(&p, &Mycolor, &score3, &i),NULL);
        i += 12;
        pthread_create(&sc4, NULL, evaluation(&p, &Mycolor, &score4, &i),NULL);


        pthread_join (sc1, NULL);
        pthread_join (sc2, NULL);
        pthread_join (sc3, NULL);
        pthread_join (sc4, NULL);


        best = score1 + score2 +score3 +score4;


        return best;
        //evaluation(p,Mycolor,&score);
//            return evaluation(p,Mycolor);
    }
    if (p.trait == ROU) {
        best = -10000;
        for (int i = 0; i < l.nb; ++i) {
            Temp = minmaxr(jouerCoup(p, l.coups[i].origine, l.coups[i].destination), depth + 1, ajouer, Mycolor);
            if (Temp > best) {
                *ajouer = i;
                best = Temp;
            }
        }
        return best;
    } else if (p.trait == JAU){
           //printf("%d\n",i);
        best=10000;
        for (int i = 0; i < l.nb; ++i) {
            Temp = minmaxr(jouerCoup(p, l.coups[i].origine, l.coups[i].destination), depth + 1, ajouer,Mycolor);
            if (Temp< best) {
                best = Temp;
            }
        }
        return best;
    }
}
int minmaxj (T_Position p , int depth,int * ajouer,octet Mycolor) {

    int  MAXDEPTH = 2;
    T_ListeCoups l = getCoupsLegaux(p);
   /* pthread_t sc1;
    pthread_t sc2;
    pthread_t sc3;
    pthread_t sc4;
    int best, Temp,score1,score2,score3,score4,i=12,j;
    if (l.nb<70)
        MAXDEPTH  = 4;
    if (l.nb<30)
        MAXDEPTH  = 6;
    if (depth == MAXDEPTH || l.nb == 0) {
        return evaluation(p,Mycolor);
    }
    /*if (depth == MAXDEPTH || l.nb == 0) {
        printf("JE CREE DES THREADS LOL \n");
//        return evaluation(p,Mycolor);
        pthread_create(&sc1, NULL, evaluation(&p, &Mycolor, &score1, &i), NULL);
        i += 12;
        pthread_create(&sc2, NULL, evaluation(&p, &Mycolor, &score2, &i), NULL);
        i += 12;
        pthread_create(&sc3, NULL, evaluation(&p, &Mycolor, &score3, &i), NULL);
        i += 12;
        pthread_create(&sc4, NULL, evaluation(&p, &Mycolor, &score4, &i), NULL);


        pthread_join(sc1, NULL);
        pthread_join(sc2, NULL);
        pthread_join(sc3, NULL);
        pthread_join(sc4, NULL);

       best = score1 + score2 + score3 + score4;

        return best;
    }

    if (p.trait == JAU) {
        best = -10000;
        for (int i = 0; i < l.nb; ++i) {
            Temp = minmaxj(jouerCoup(p, l.coups[i].origine, l.coups[i].destination), depth + 1, ajouer,Mycolor);
            if (Temp > best) {
                *ajouer = i;
                best = Temp;
            }
        }
        return best;
    } else if (p.trait == ROU){
        best = 10000;
        for (int i = 0; i < l.nb; ++i) {
            Temp = minmaxj(jouerCoup(p, l.coups[i].origine, l.coups[i].destination), depth + 1, ajouer,Mycolor);
            if (Temp < best) {
                best= Temp;
            }
        }
        return best;

    }
}

*/

