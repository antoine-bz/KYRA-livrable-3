
#include <stdio.h>
#include <stdlib.h>
#include "avalam.h"
#include "moteur.h"
int VerifCoup(T_Position currentPosition, T_ListeCoups listeCoups,int coupChoisi);
void bouclefor(int,int,T_ListeCoups);

void choisirCoup(T_Position currentPosition, T_ListeCoups listeCoups) 
{
	// Cette fonction peut appeler la fonction ecrireIndexCoup(coupChoisi);
	// Pour sélectionner l'index d'un coup à jouer dans la liste l 

	// aléatoire 
	// ecrireIndexCoup(rand()%listeCoups.nb);
	int x,y=0,isolation,pion_a_bouger=0,pion_a_sousmetre=0;
	int i,n; 
	octet o, d; 
	int a; 
	octet myColor = currentPosition.trait; 
	int k;
	T_Voisins voisins;
	T_Voisins voisin1;
	int j;
	int nbVoisinsDest, nbVoisinsOri;
	int nbVoisinAdverse;
	int AddVoisinAdverse;
	int l=0;
	//int x=1,y=0,isolation,pion_a_bouger;
	// afficherListeCoups(listeCoups);

	printf("Ma couleur : %s\n", COLNAME(currentPosition.trait));

	//ISOLATION ET CONTRE ISOLATION
	for(i=0;i<listeCoups.nb; i++) 
	{
		o = listeCoups.coups[i].origine; 
		d = listeCoups.coups[i].destination;  

		printf("Coup %d : ", i); 
		printf("%d (%d - %s) ->", o, currentPosition.cols[o].nb, COLNAME(currentPosition.cols[o].couleur));
		printf("%d (%d - %s) \n", d, currentPosition.cols[d].nb, COLNAME(currentPosition.cols[d].couleur));

		nbVoisinsDest=0;
		nbVoisinsOri=0;

		//on parcours les voisins de dest
		for(j=0;j<getVoisins(d).nb;j++)
		{
			if((currentPosition.cols[getVoisins(d).cases[j]].nb == 1) 
			|| (currentPosition.cols[getVoisins(d).cases[j]].nb == 2) 
			|| (currentPosition.cols[getVoisins(d).cases[j]].nb == 3) 
			|| (currentPosition.cols[getVoisins(d).cases[j]].nb == 4))
				nbVoisinsDest++;
		}

		for(j=0;j<getVoisins(o).nb;j++)
		{
			if((currentPosition.cols[getVoisins(o).cases[j]].nb == 1) 
			|| (currentPosition.cols[getVoisins(o).cases[j]].nb == 2) 
			|| (currentPosition.cols[getVoisins(o).cases[j]].nb == 3) 
			|| (currentPosition.cols[getVoisins(o).cases[j]].nb == 4))
				nbVoisinsOri++;
		}

		printf("\n\nnbVoisinsDest : %d\nnbVoisinsOri : %d\n", nbVoisinsDest, nbVoisinsOri);

		//différent cas d'isolation
		if(currentPosition.cols[o].couleur != myColor)	
		{
			voisins=getVoisins(o);
			isolation=0;
			for(y=0;y<voisins.nb;y++)
			{
				if(currentPosition.cols[voisins.cases[y]].nb==0 
				|| currentPosition.cols[voisins.cases[y]].nb==5)
					isolation++;

				if(currentPosition.cols[voisins.cases[y]].nb==1 
				|| currentPosition.cols[voisins.cases[y]].nb==2 
				|| currentPosition.cols[voisins.cases[y]].nb==3 
				|| currentPosition.cols[voisins.cases[y]].nb==4)
					x=voisins.cases[y];
			}

			if(isolation==(voisins.nb)-1)
			{
				if(currentPosition.cols[x].couleur == myColor)
				{
					pion_a_bouger=d;
					pion_a_sousmetre=o;										
				}
			}
		}
						
		if(currentPosition.cols[o].couleur == myColor)
		{
			voisins=getVoisins(o);
			isolation=0;

			for(y=0;y<voisins.nb;y++)
			{
				if(currentPosition.cols[voisins.cases[y]].nb==0 
				|| currentPosition.cols[voisins.cases[y]].nb==5)
					isolation++;

				if(currentPosition.cols[voisins.cases[y]].nb==1 
				|| currentPosition.cols[voisins.cases[y]].nb==2 
				|| currentPosition.cols[voisins.cases[y]].nb==3 
				|| currentPosition.cols[voisins.cases[y]].nb==4)
					x=voisins.cases[y];
			}
			
			if(isolation==(voisins.nb)-1)
			{
				pion_a_bouger=d;
				voisin1=getVoisins(d);
				for(j=0;j<voisin1.nb;j++)
				{
					if(currentPosition.cols[j].couleur != myColor)
					{
						pion_a_sousmetre = voisin1.cases[j];
						bouclefor(pion_a_sousmetre,pion_a_bouger,listeCoups);
					}
				}
			}
		}
		if(o==pion_a_bouger && d==pion_a_sousmetre)
		{
			printf("On choisit ce coup :isoler ! \n");
			ecrireIndexCoup(i);
		return;
		}
		
		

		//contre isolation
		if((currentPosition.cols[o].couleur != myColor)
		&& ((currentPosition.cols[o].nb+currentPosition.cols[d].nb) <= 5)
		&& (nbVoisinsOri==1)
		&& (VerifCoup(currentPosition,listeCoups,i) == 0))
		{
			printf("\n\n\nCONTRE ISOLATION\n\n\n");
			printf("On choisit ce coup ! \n"); 
			ecrireIndexCoup(i);
			return; // on quitte la fonction
		}
	}

	//TOUR POSSIBLE AUTRE QU'ISOLATION OU LES EMPECHER
	for(i=0;i<listeCoups.nb; i++) 
	{
		o = listeCoups.coups[i].origine; 
		d = listeCoups.coups[i].destination;  

		/*printf("Coup %d : ", i); 
		printf("%d (%d - %s) ->", o, currentPosition.cols[o].nb, COLNAME(currentPosition.cols[o].couleur));
		printf("%d (%d - %s) \n", d, currentPosition.cols[d].nb, COLNAME(currentPosition.cols[d].couleur));*/

		nbVoisinAdverse=0;
		AddVoisinAdverse=0;

		//on parcours les voisins de d
		for(j=0;j<getVoisins(d).nb;j++)
		{
			if(currentPosition.cols[getVoisins(d).cases[j]].couleur != myColor)
			{
				nbVoisinAdverse++;
				
				if((currentPosition.cols[getVoisins(d).cases[j]].nb+currentPosition.cols[o].nb+currentPosition.cols[d].nb) < 5) //Si l'addition d'un voisin adverse plus le coup joué(origine + dest) est inférieur à 5
				AddVoisinAdverse=1;
			}

			/*if((currentPosition.cols[d].couleur != myColor)
			&& (currentPosition.cols[getVoisins(d).cases[j]] != myColor)
			&& ((currentPosition.cols[d].nb + currentPosition.cols[getVoisins(d).cases[j]] == 5))
			{
				pion_a_sousmetre1=d;
				pion_a_sousmetre2=getVoisins(d).cases[j];
			}*/
		}

		// printf("TEST: La position %d à %d voisins\n",d,nbVoisins(d));
		// printf("on liste le nombre de pions present sur chaque voisins avec la couleurs du sommet :\n");
		// voisins =getVoisins(d);

		// for (k = 0; k < voisins.nb; ++k)
		// {
		// 	printf("VOISINS :%d (%d - %s)",voisins.cases[k],currentPosition.cols[voisins.cases[k]].nb,COLNAME(currentPosition.cols[voisins.cases[k]].couleur));
		// }
		// if (listeCoups.nb==292 && o==20 && d==29  && (VerifCoup(currentPosition,listeCoups,i) == 0))
		// {
		// 		printf("On choisit ce coup ! \n"); 
		// 		ecrireIndexCoup(i);
		// 		return; // on quitte la fonction 
		// }
		// 	if (listeCoups.nb>250 && o==29 && d==22 && (VerifCoup(currentPosition,listeCoups,i) == 0))
		// {
		// 		printf("On choisit ce coup ! \n"); 
		// 		ecrireIndexCoup(i);
		// 		return; // on quitte la fonction 
		// }

		// Si une tour est faisable sans être reprise et n'ayant pas une taille de 5
		if ((currentPosition.cols[o].couleur == myColor)
		&& (currentPosition.cols[d].couleur != myColor)
		&& ((nbVoisinAdverse == 0) || AddVoisinAdverse==0)
		&&(VerifCoup(currentPosition,listeCoups,i) == 0))
		{
			printf("On choisit ce coup ! \n"); 
			ecrireIndexCoup(i);
			return; // on quitte la fonction
		}

		// Si je peux gagner une colonne, je la prends (1+4, 2+3 ...)
		if ((currentPosition.cols[o].couleur == myColor)
		&& (currentPosition.cols[d].couleur != myColor)
		&& ((currentPosition.cols[o].nb+currentPosition.cols[d].nb) == 5)
		&& (currentPosition.cols[d].couleur != currentPosition.cols[o].couleur))
		{
			printf("On choisit ce coup ! \n"); 
			ecrireIndexCoup(i);
			return; // on quitte la fonction 
		}

		// Si il est possible d'empêcher l'adversaire de faire une tour de 5
		/*if ((currentPosition.cols[o].couleur == myColor)
		){}*/
	} 


	// Sinon, j'empile des pions adverses sauf s'ils conduisent à des tas de 5 ou de 4
	for(i=0;i<listeCoups.nb; i++) 
	{
		o = listeCoups.coups[i].origine; 
		d = listeCoups.coups[i].destination;  

		if ((currentPosition.cols[o].couleur != myColor)
		&& (currentPosition.cols[d].couleur != myColor) 
		&& ((currentPosition.cols[o].nb+currentPosition.cols[d].nb) != 5) 
		&& (currentPosition.cols[o].nb+currentPosition.cols[d].nb) != 4 
		&& (VerifCoup(currentPosition,listeCoups,i) == 0) )  
		{
			printf("On choisit ce coup ! \n"); 
			printf("%d\n",currentPosition.cols[o].couleur );
			ecrireIndexCoup(i);
			return; // on quitte la fonction 
		}
	}


	 
	// Sinon, je tire au sort 

	while (1) 
	{
		a = rand()%listeCoups.nb;
		o = listeCoups.coups[a].origine; 
		d = listeCoups.coups[a].destination;  
 
		if ( (currentPosition.cols[o].couleur != myColor)
		&& ((currentPosition.cols[o].nb+currentPosition.cols[d].nb) != 5) 
		&& VerifCoup(currentPosition,listeCoups,i) == 0) {
			printf("On choisit ce coup ! \n"); 
			ecrireIndexCoup(a);
			return; // on quitte la fonction 
		}
	}
	
}
int VerifCoup(T_Position currentPosition, T_ListeCoups listeCoups,int coupChoisi)
{  //Fonction qui fait des test basique pour voir si le coup choisis par une stratégie ne donne pas un point facile à l'adversaire
		octet o, d; 
		T_Voisins voisins;
		int i;
		o = listeCoups.coups[coupChoisi].origine; 
		d = listeCoups.coups[coupChoisi].destination; 
		voisins =getVoisins(d);

		if((currentPosition.cols[o].couleur != currentPosition.trait)
		&& (currentPosition.cols[d].couleur == currentPosition.trait)
		&& (currentPosition.cols[o].nb+currentPosition.cols[d].nb == 5))
		{
			printf("Coup cadeaux\n");
			return 1;
		}
		

		if (currentPosition.cols[o].nb+currentPosition.cols[d].nb!=5)
		{
			for (i = 0; i < voisins.nb; ++i)
			{

				if ( (currentPosition.cols[voisins.cases[i]].nb+(currentPosition.cols[o].nb+currentPosition.cols[d].nb)==5 )
					//&& (currentPosition.cols[voisins.cases[i]].couleur != currentPosition.trait)
					&& (voisins.cases[i] != o) )
				{
					printf("Coup cadeaux\n");
					return 1;
				}
			}
		}
return 0;
}

void bouclefor(int d,int o,T_ListeCoups listeCoups)
{
	int j;
	octet o1, d1;

	for(j=0;j<listeCoups.nb;j++)
	{
		o1 = listeCoups.coups[j].origine; 
		d1 = listeCoups.coups[j].destination;
		if(o==o1 && d==d1)
		ecrireIndexCoup(j);
	}
}


