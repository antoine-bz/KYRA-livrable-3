#include <stdio.h>
#include <stdlib.h>
#include "avalam.h"
#include "moteur.h"

void initliste(T_ListeCoups *);
T_Voisins Voisinage(T_Position, octet);

T_ListeCoups strat1(T_Position, T_ListeCoups);
T_ListeCoups strat2(T_Position, T_ListeCoups);
T_ListeCoups strat3(T_Position, T_ListeCoups);
T_ListeCoups strat4(T_Position, T_ListeCoups);
T_Coup strat5(T_Position, T_ListeCoups);
T_ListeCoups strat6(T_Position, T_ListeCoups);

T_ListeCoups tact1(T_Position, T_ListeCoups);
T_ListeCoups tact2(T_Position, T_ListeCoups);
T_ListeCoups tact3(T_Position, T_ListeCoups);
T_ListeCoups tact4(T_Position, T_ListeCoups);
T_ListeCoups tact5(T_Position, T_ListeCoups);


void choisirCoup(T_Position currentPosition, T_ListeCoups listeCoups) {

	T_ListeCoups liste;
	T_Coup choix;
	int c=0;
	//printf("%d\n",listeCoups.nb );
	liste = strat1(currentPosition, listeCoups);
	liste = strat4(currentPosition, liste);
	liste = strat6(currentPosition, liste);
	liste = strat2(currentPosition, liste);
	liste = strat3(currentPosition, liste);
	liste = tact4(currentPosition, liste);
	liste = tact5(currentPosition, liste);
	liste = tact1(currentPosition, liste);
	liste = tact3(currentPosition, liste);
	liste = tact2(currentPosition, liste);
	choix = strat5(currentPosition, liste);
	for (int i = 0; i < listeCoups.nb; ++i)
	{
		if (choix.origine == listeCoups.coups[i].origine && choix.destination == listeCoups.coups[i].destination)
		{
			c = i;
		}
	}
	ecrireIndexCoup(c);
	//printf("%d\n",c);
	return;

}

T_ListeCoups strat1(T_Position currentPosition, T_ListeCoups listeCoups){ // valide
	T_ListeCoups liste_red;
	octet o;
	octet d;
	initliste(&liste_red);

	//printf("Entrer dans strat1 \n");
	//printf("%d\n",listeCoups.nb );
	for (int i = 0; i < listeCoups.nb; ++i)
	{
		o = listeCoups.coups[i].origine;
		d = listeCoups.coups[i].destination;
		if (currentPosition.cols[d].couleur != currentPosition.trait)
		{
			addCoup( &liste_red, o, d);
		}
	}
	//printf("%d\n",liste_red.nb );
	if(liste_red.nb == 0){
		return listeCoups;
	}
	else{
		return liste_red;
	}
}

T_ListeCoups strat2(T_Position currentPosition, T_ListeCoups listeCoups){ //valide
	T_ListeCoups liste_red;
	octet o;
	octet d;
	int taille;
	T_Voisins voisins;
	octet v;
	int test;
	initliste(&liste_red);

	//printf("Entrer dans strat2\n");
	//printf("%d\n",listeCoups.nb );
	for (int i = 0; i < listeCoups.nb ; ++i)
	{
		o = listeCoups.coups[i].origine;
		d = listeCoups.coups[i].destination;
		taille = currentPosition.cols[d].nb+currentPosition.cols[o].nb;
		test = 0;
			if (taille == 5)
			{
				if (currentPosition.cols[o].couleur != currentPosition.trait)
				{
					test = 1;
					//printf("refus\n");
				}
			}
			else
			{
				voisins = Voisinage(currentPosition, d);
				for (int j = 0; j < voisins.nb ; ++j)
				{
					v = voisins.cases[j];
					if (taille + currentPosition.cols[v].nb == 5 && v != o && currentPosition.cols[v].couleur != currentPosition.trait)
					{
						test = 1;
						//printf("refus\n");
					}
				}
				
			}
			if (test == 0)
				{
					addCoup( &liste_red, o, d);
					//printf("add %d -> %d",o , d);
				}
		
	}
	//printf("%d\n",liste_red.nb );
	if(liste_red.nb == 0){
		return listeCoups;
	}
	else{
		return liste_red;
	}
}

T_ListeCoups strat3(T_Position currentPosition, T_ListeCoups listeCoups){ // à re-valider
	T_ListeCoups liste_red;
	octet o;
	octet d;
	T_Voisins voisins, voisins2;
	octet k = 0;
	octet m = 0;
	int test = 0;
	initliste(&liste_red);

	//printf("Entrer dans strat3 \n");
	//printf("%d\n",listeCoups.nb );
	for (int i = 0; i < listeCoups.nb; ++i)
	{
		o = listeCoups.coups[i].origine;
		d = listeCoups.coups[i].destination;
		voisins = Voisinage(currentPosition, o);
		test = 0;
		for (int j = 0; j < voisins.nb; ++j)
		{
			k = voisins.cases[j];
			voisins2 = Voisinage( currentPosition, k);
			if(voisins2.nb == 2){
				for (int l = 0; l < 2; ++l)
				{
					if (voisins2.cases[l] != o)
					{
						m = voisins2.cases[l];
					}
					if (d != m && d != k)
					{
						if (currentPosition.cols[k].couleur != currentPosition.trait)
						{
							test = 1;
						}
						else {
							if (currentPosition.cols[m].couleur != currentPosition.trait && currentPosition.cols[m].nb+currentPosition.cols[k].nb <= 5)
							{
								test=1;
							}
						}
					}
					else{
						if (currentPosition.cols[o].couleur != currentPosition.trait)
						{
							if (d == k)
							{
								test=1;
							}
							else{
								if ( currentPosition.cols[k].couleur != currentPosition.trait || currentPosition.cols[m].nb+currentPosition.cols[k].nb+currentPosition.cols[o].nb <= 5)
								{
									test = 1;
								}
							}
						}
						else{
							if (d == k)
							{
								if (currentPosition.cols[m].couleur != currentPosition.trait && currentPosition.cols[m].nb+currentPosition.cols[k].nb+currentPosition.cols[o].nb <= 5)
								{
									test=1;
								}
							}
							else{
								if (currentPosition.cols[k].couleur != currentPosition.trait)
								{
									test=1;
								}
							}
						}
					}
				}
			}

		}
		if (test == 0)
			{
				addCoup(&liste_red, o, d);
			}
	}
	//printf("%d\n",liste_red.nb );
	return liste_red;
}


T_ListeCoups strat4(T_Position currentPosition, T_ListeCoups listeCoups){ // à re-valider
	T_ListeCoups liste_red;
	octet o;
	octet d;
	T_Voisins voisins, voisins2;
	octet k = 0;
	int test = 0;
	initliste(&liste_red);

	//printf("Entrer dans strat4 \n");
	//printf("%d\n",listeCoups.nb );
	for (int i = 0; i < listeCoups.nb; ++i)
	{
		o = listeCoups.coups[i].origine;
		d = listeCoups.coups[i].destination;
		voisins = Voisinage(currentPosition, o);
		test = 0;
		for (int j = 0; j < voisins.nb; ++j)
		{
			k = voisins.cases[j];
			voisins2 = Voisinage(currentPosition, k);
			if(voisins2.nb == 1 && currentPosition.cols[k].couleur != currentPosition.trait){
				if (k != d)
				{
					test = 1;
				}
				else{
					if (currentPosition.cols[o].couleur != currentPosition.trait)
					{
						test=1;
					}
				}
			}
		}
		if(test == 0)
		{
			addCoup(&liste_red, o, d);
		}
	}
	//printf("%d\n",liste_red.nb );
	if(liste_red.nb == 0){
		return listeCoups;
	}
	else{
		return liste_red;
	}
}

T_Coup strat5(T_Position currentPosition, T_ListeCoups listeCoups){ // à re-valider
	octet o;
	octet d;
	T_Voisins voisins, voisins2;
	int k = 0;
	int i = 0;
	int best;
	
	//printf("Entrer dans strat5 \n");
	//printf("%d\n",listeCoups.nb );
	o = listeCoups.coups[i].origine;
	d = listeCoups.coups[i].destination;
	voisins = Voisinage(currentPosition, d);
	i++;
	best = voisins.nb;

	for (i = 1; i < listeCoups.nb; ++i)
	{
		o = listeCoups.coups[i].origine;
		d = listeCoups.coups[i].destination;
		voisins2 = Voisinage(currentPosition, d);
		if (voisins2.nb < best)
		{
			best = voisins2.nb;
			k = i;
		}			
	}
	return listeCoups.coups[k];
}

T_ListeCoups strat6(T_Position currentPosition, T_ListeCoups listeCoups){
	T_ListeCoups liste_red;
	octet o;
	octet d;
	int test=0;
	T_Voisins voisins;
	initliste(&liste_red);

	//printf("Entrer dans strat6 \n");
	//printf("%d\n",listeCoups.nb );
	for (int i = 0; i < listeCoups.nb; ++i)
	{
		o = listeCoups.coups[i].origine;
		d = listeCoups.coups[i].destination;
		voisins = Voisinage(currentPosition, d);
		test=0;
		if (currentPosition.cols[o].nb+currentPosition.cols[d].nb == 5 && currentPosition.cols[o].couleur != currentPosition.trait)
		{
			test = 1;
		}
		if (voisins.nb == 1 && currentPosition.cols[o].couleur != currentPosition.trait)
		{
			test=1;
		}
		if (test == 0)
		{
			addCoup(&liste_red, o, d);
		}
	}
	//printf("%d\n",liste_red.nb );
	if(liste_red.nb == 0){
		return listeCoups;
	}
	else{
		return liste_red;
	}
}


				
T_ListeCoups tact1(T_Position currentPosition, T_ListeCoups listeCoups){ // à re-valider
	T_ListeCoups liste_red;
	octet o;
	octet d;
	initliste(&liste_red);

	//printf("Entrer dans tact1 \n");
	//printf("%d\n",listeCoups.nb );
	for (int i = 0; i < listeCoups.nb; ++i)
	{
		o = listeCoups.coups[i].origine;
		d = listeCoups.coups[i].destination;
		if (currentPosition.cols[o].nb+currentPosition.cols[d].nb == 5 && currentPosition.cols[o].couleur == currentPosition.trait)
		{
			addCoup(&liste_red, o, d);
		}
	}
	//printf("%d\n",liste_red.nb );
	if(liste_red.nb == 0){
		return listeCoups;
	}
	else{
		return liste_red;
	}
}

T_ListeCoups tact2(T_Position currentPosition, T_ListeCoups listeCoups){ // peut etre pb plusieurs fois coups
	T_ListeCoups liste_red;
	octet o;
	octet d;
	T_Voisins voisins, voisins2;
	int k = 0;
	int test = 0;
	initliste(&liste_red);

	//printf("Entrer dans tact2 \n");
	//printf("%d\n",listeCoups.nb );
	for (int i = 0; i < listeCoups.nb; ++i)
	{
		o = listeCoups.coups[i].origine;
		d = listeCoups.coups[i].destination;
		voisins = Voisinage(currentPosition, o);
		test = 0;
		for (int j = 0; j < voisins.nb; ++j)
		{
			if (test == 0)
			{
				k = voisins.cases[j];
				voisins2 = Voisinage(currentPosition, k);
				if (voisins2.nb == 1 && currentPosition.cols[k].couleur == currentPosition.trait && k != d)
				{
					addCoup(&liste_red, o, d);
					test = 1;
				}
			}
		}
	}
	//printf("%d\n",liste_red.nb );
	if(liste_red.nb == 0){
		return listeCoups;
	}
	else{
		return liste_red;
	}
}


T_ListeCoups tact3(T_Position currentPosition, T_ListeCoups listeCoups){
	T_ListeCoups liste_red;
	octet o;
	octet d;
	T_Voisins voisins;
	initliste(&liste_red);

	//printf("Entrer dans tact3 \n");
	//printf("%d\n",listeCoups.nb );
	for (int i = 0; i < listeCoups.nb; ++i)
	{
		o = listeCoups.coups[i].origine;
		d = listeCoups.coups[i].destination;
		voisins = Voisinage(currentPosition, d);
		if (voisins.nb == 1 && currentPosition.cols[d].couleur != currentPosition.trait && currentPosition.cols[o].couleur == currentPosition.trait)
		{
			addCoup(&liste_red, o, d);
		}
	}
	if(liste_red.nb == 0){
		return listeCoups;
	}
	else{
		return liste_red;
	}
}

T_ListeCoups tact4(T_Position currentPosition, T_ListeCoups listeCoups){
	T_ListeCoups liste_red, liste_test;
	octet o;
	octet d;
	int v, v2, test = 0;
	T_Voisins voisins, voisins2;
	initliste(&liste_red);
	initliste(&liste_test);

	//printf("Entrer dans tact4 \n");
	//printf("%d\n",listeCoups.nb );
	for (int i = 0; i < 48; ++i)
	{
		voisins = Voisinage(currentPosition, i);
		if (voisins.nb == 1)
		{
			v = voisins.cases[0];
			if (currentPosition.cols[i].couleur != currentPosition.trait)
			{
				if (currentPosition.cols[v].couleur != currentPosition.trait)
				{
					addCoup(&liste_test, i, v);
				}
				else{
					addCoup(&liste_test, v, i);
				}
			}
			else{
				if (currentPosition.cols[v].couleur != currentPosition.trait)
				{
					voisins2 = Voisinage(currentPosition, v);
					for (int j = 0; j < voisins2.nb; ++j)
					{
						v2 = voisins2.cases[j];
						if (v2 != i)
						{
							addCoup(&liste_test, v, v2);
						}
					}
				}
			}
		}
	}
	for (int q = 0; q < liste_test.nb; ++q)
	{
		for (int r = 0; r < listeCoups.nb; ++r)
		{
			if (liste_test.coups[q].origine == listeCoups.coups[r].origine && liste_test.coups[q].destination == listeCoups.coups[r].destination)
			{
				for (int s = 0; s < liste_red.nb; ++s)
				{
					test = 0;
					if (liste_test.coups[q].origine == liste_red.coups[s].origine && liste_test.coups[q].destination == liste_red.coups[s].destination)
					{
						test=1;
					}
				}
				if (test == 0)
				{
					addCoup(&liste_red, liste_test.coups[q].origine, liste_test.coups[q].destination);
				}
			}
		}
	}
	//printf("%d\n",liste_red.nb );
	if(liste_red.nb == 0){
		return listeCoups;
	}
	else{
		return liste_red;
	}
}





T_ListeCoups tact5(T_Position currentPosition, T_ListeCoups listeCoups){
	T_ListeCoups liste_red, liste_test;
	octet k;
	int test = 0, test2 = 0;
	T_Voisins voisins, voisins2;
	initliste(&liste_red);
	initliste(&liste_test);

	//printf("Entrer dans tact5 \n");
	//printf("%d\n",listeCoups.nb );
	for(int i=0; i < 48; i++)
	{
		
		voisins=Voisinage(currentPosition, i);
		for (int j = 0; j < voisins.nb; ++j)
		{
			k = voisins.cases[j];
			if (currentPosition.cols[i].nb+currentPosition.cols[k].nb == 5 && currentPosition.cols[i].couleur != currentPosition.trait && currentPosition.cols[k].couleur != currentPosition.trait)
			{
				for (int n = 0; n < voisins.nb ; ++n)
				{
					test=0;
					voisins2 = Voisinage(currentPosition, n);
					for (int m = 0; m < voisins.nb; ++i)
					{
						if (m != n && currentPosition.cols[i].nb+currentPosition.cols[n].nb+currentPosition.cols[m].nb != 5)
						{
							test=1;
						}
					}
					if (test == 0)
					{
						addCoup(&liste_test, n, i);
					}
					for (int p = 0; p < voisins2.nb ; ++p)
					{
						if (p != i && currentPosition.cols[i].nb+currentPosition.cols[n].nb+currentPosition.cols[p].nb != 5)
						{
							test2=1;
						}
					}
					if (test == 0)
					{
						addCoup(&liste_test, i, n);
					}
					
				}
			}
		}

	}
	for (int q = 0; q < liste_test.nb; ++q)
	{
		for (int r = 0; r < listeCoups.nb; ++r)
		{
			if (liste_test.coups[q].origine == listeCoups.coups[r].origine && liste_test.coups[q].destination == listeCoups.coups[r].destination)
			{
				for (int s = 0; s < liste_red.nb; ++s)
				{
					test = 0;
					if (liste_test.coups[q].origine == liste_red.coups[s].origine && liste_test.coups[q].destination == liste_red.coups[s].destination)
					{
						test=1;
					}
				}
				if (test == 0)
				{
					addCoup(&liste_red, liste_test.coups[q].origine, liste_test.coups[q].destination);
				}
			}
		}
	}
	//printf("%d\n",liste_red.nb );
	if(liste_red.nb == 0){
		return listeCoups;
	}
	else{
		return liste_red;
	}
}


T_Voisins Voisinage(T_Position currentPosition, octet d){
	T_Voisins voisins, voisinage;
	voisins = getVoisins(d);
	voisinage.nb = 0;
	octet k=0, v;
	for (int i = 0; i < voisins.nb ; ++i)
	{
		v = voisins.cases[i];
		if (currentPosition.cols[v].nb > 0 && currentPosition.cols[v].nb < 5)
		{
			voisinage.nb ++;
			voisinage.cases[k] = v;
			k++;
		}
	}
	return voisinage;
}

void initliste(T_ListeCoups* pliste){
	pliste->nb = 0;
}


