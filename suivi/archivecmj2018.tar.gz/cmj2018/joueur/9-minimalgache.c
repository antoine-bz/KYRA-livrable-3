/***** Joueur Avalam se basant sur un algorithme Minimax *****/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "avalam.h"
#include "moteur.h"

#define MIN 0
#define MAX 1
#define INF 10000

#define MM__DEBUG__

typedef struct {
    int coup;
    int score;
} T_Result;

int eval(T_Position, octet);
T_Result minimax(T_Position, octet, octet);


void choisirCoup(T_Position pos, T_ListeCoups lc){
    octet maCouleur = pos.trait;

    printf("Je suis le joueur %s\n", COLNAME(maCouleur));
    printf("Il y a %i coups possibles...\n", lc.nb);

    #ifdef MM__DEBUG__
    clock_t debut = clock();

    if(lc.nb > 60)
        ecrireIndexCoup(minimax(pos, maCouleur, 3).coup);
    else if(lc.nb <= 60 && lc.nb > 25)
        ecrireIndexCoup(minimax(pos, maCouleur, 5).coup);
    else
        ecrireIndexCoup(minimax(pos, maCouleur, 7).coup);

    clock_t fin = clock();

    double sec = (double)(fin-debut) / CLOCKS_PER_SEC;

    printf("Meilleur coup trouvé en %f secondes\n", sec);

    #else
    if(lc.nb > 60)
        ecrireIndexCoup(minimax(pos, maCouleur, 3).coup);
    else if(lc.nb <= 60 && lc.nb > 25)
        ecrireIndexCoup(minimax(pos, maCouleur, 5).coup);
    else
        ecrireIndexCoup(minimax(pos, maCouleur, 7).coup);

    #endif


}

/*int evalVoisins(octet pos, octet couleur, T_Position curPos){
    int score = 0;
    T_Voisins voisins = getVoisins(pos);

    for(int i = 0; i < nbVoisins(pos); i++){
        if(curPos.cols[voisins.cases[i]].couleur = couleur)
            score++;
        else
            score--;
    }
}*/ // Demanderais beaucoup trop de temps

int eval(T_Position pos, octet couleur){
    int score = 0;

    // On évalue le score
    // On tente de maximiser notre nombre de pièce
    // Et on tâche d'éviter que notre opposant aie des tours de 5
    for(int i = 0; i < NBCASES; i++){
        if(pos.cols[i].couleur == couleur){
            score++;
        }
        else{
            if(pos.cols[i].nb == 5)
                score -= 5;
            else
                score--;
        }
    }

    return score;
}

T_Result minimax(T_Position pos, octet couleur, octet profondeur){
    
    T_Result result;
    int type, bestScore, bestCoup;
    
    // Si nous sommes au cas d'arrêt : on renvoie le score de la position
    if(profondeur == 0){
        result.coup = -1;
        result.score = eval(pos, couleur);

        return result;
    }

    // On détermine si on est sur un noeud joueur ou opposant
    if(pos.trait == couleur){
        type = MAX;
        bestScore = -INF;
        bestCoup = -1;
    }
    else{
        type = MIN;
        bestScore = INF;
        bestCoup = -1;
    }

    T_ListeCoups lc = getCoupsLegaux(pos);

    for(int i = 0; i < lc.nb; i++){
        T_Position posAux = jouerCoup(pos, lc.coups[i].origine, lc.coups[i].destination);
        int eval = minimax(posAux, couleur, profondeur-1).score;

        // On détermine si on est sur un noeud joueur ou opposant
        if((type == MAX && eval > bestScore) || (type == MIN && eval < bestScore)){
            bestScore = eval;
            bestCoup = i;
        }
    }

    result.coup = bestCoup;
    result.score = bestScore;

    // On renvoie notre résultat
    return result;
}