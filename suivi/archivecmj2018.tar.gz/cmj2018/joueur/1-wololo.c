/********* Moteur de tournoi : joueur ***************/

#include <stdio.h>
#include <stdlib.h>
#include "avalam.h"
#include "moteur.h"


void choisirCoup(T_Position currentPosition, T_ListeCoups listeCoups) {
	// Cette fonction peut appeler la fonction ecrireIndexCoup(coupChoisi);
	// Pour sélectionner l'index d'un coup à jouer dans la liste l 

	// aléatoire 
	// ecrireIndexCoup(rand()%listeCoups.nb);

	int i,j,k=0;
	int vois=0,voisCouleur=0,voisCouleur2=0; 
	octet o, d, v, v2; 
	int a; 
	octet myColor = currentPosition.trait; 
	int tabRandom[100];
	T_Voisins voisins,voisins2;

	// afficherListeCoups(listeCoups);

	printf("Ma couleur : %s\n", COLNAME(currentPosition.trait));

	// On teste d'abord si on peut faire une pile de 5 en empilant sur une pile 
	// différente de notre couleur
	for(i=0;i<listeCoups.nb; i++) 
	{
		o = listeCoups.coups[i].origine; 
		d = listeCoups.coups[i].destination; 

		/*printf("Coup %d : ", i); 
		printf("%d (%d - %s) ->", o, currentPosition.cols[o].nb, COLNAME(currentPosition.cols[o].couleur));
		printf("%d (%d - %s) \n", d, currentPosition.cols[d].nb, COLNAME(currentPosition.cols[d].couleur)); */

	if ( 			(currentPosition.cols[o].couleur == myColor)
			    &&  (currentPosition.cols[d].couleur != myColor)
				&& 	((currentPosition.cols[o].nb+currentPosition.cols[d].nb) == 5) 
		) 
		{
			printf("On stocke ce coup dans un tableau --> pile de 5 ma couleur sur celle de l'adv\n"); 
			tabRandom[k]=i;
			printf("k avant incrementation : %d et tabRandom[k]/i : %d\n",k,tabRandom[k]);
			k++;
			printf("valeur de k : %d\n",k );
			//ecrireIndexCoup(i);
			//return; // on quitte la fonction 
		}
	}
	printf("salut\n");
	if (k != 0)
	{
		printf("je passe par la\n");
		a = rand()%(k);
		printf("coucou\n");
		printf("a vaut : %d\n",a);
		printf("tabRandom[a] : %d\n",tabRandom[a]);
		ecrireIndexCoup(tabRandom[a]);
		printf("on joue le coup\n");
		return;
		k=0;
	}
	
	//k=0; // on remet à k à 0

	// Si je peux gagner une colonne, je la prends (1+4, 2+3 ...)
	// SAUF S'IL N'Y A PAS DE MENACE
	for(i=0;i<listeCoups.nb; i++) 
	{
		o = listeCoups.coups[i].origine; 
		d = listeCoups.coups[i].destination;  
		voisCouleur = 0;
		voisCouleur2 = 0;

		/*printf("Coup %d : ", i); 
		printf("%d (%d - %s) ->", o, currentPosition.cols[o].nb, COLNAME(currentPosition.cols[o].couleur));
		printf("%d (%d - %s) \n", d, currentPosition.cols[d].nb, COLNAME(currentPosition.cols[d].couleur)); */

	if ( 			(currentPosition.cols[o].couleur == myColor)
				&& 	((currentPosition.cols[o].nb+currentPosition.cols[d].nb) == 5) 
		) 
		{
			voisins = getVoisins(d);
			voisins2 = getVoisins(o);
			for (j = 0; j < voisins.nb; ++j)
			{
				v = voisins.cases[j];

				if (currentPosition.cols[v].couleur != myColor && currentPosition.cols[v].nb != 5)
					voisCouleur = voisCouleur + 1;
			}

			for (j = 0; i < voisins2.nb; ++j)
			{
				v2 = voisins2.cases[j];

				if (currentPosition.cols[v].couleur != myColor && currentPosition.cols[v].nb != 5)
					voisCouleur2 = voisCouleur2 + 1;
			}

			if (voisCouleur != 0 && voisCouleur2 != 0)
			{
				printf("On stocke ce coup dans un tableau - Pile de 5\n"); 
				tabRandom[k]=i;
				printf("k avant incrementation : %d et tabRandom[k]/i : %d\n",k,tabRandom[k]);
				k++;
				printf("valeur de k : %d\n",k );
				//ecrireIndexCoup(i);
				//return; // on quitte la fonction 
			}
		}
	}
	printf("salut\n");
	if (k != 0)
	{
		printf("je passe par la\n");
		a = rand()%(k);
		printf("coucou\n");
		printf("a vaut : %d\n",a);
		printf("tabRandom[a] : %d\n",tabRandom[a]);
		ecrireIndexCoup(tabRandom[a]);
		printf("on joue le coup\n");
		return;
		k=0;
	}
	//k=0; // on remet à k à 0 

// J'empile mes pions sur ceux de l'adversaire pour faire une pile de 4, sauf s'il y a 
// un pion de l'autre couleur à côté 

	for(i=0;i<listeCoups.nb; i++) 
	{
			o = listeCoups.coups[i].origine; 
			d = listeCoups.coups[i].destination;  
			vois = 0;
			voisCouleur = 0;

		if ( (currentPosition.cols[o].couleur == myColor)
			&& (currentPosition.cols[d].couleur != myColor) 
			&& ((currentPosition.cols[o].nb + currentPosition.cols[d].nb) == 4)
			) 
		{
			//printf("Pile de 4 !!\n");
			voisins = getVoisins(d);
			//printf("On récupère les voisins\n");
			for (j = 0; j < voisins.nb; j++)
			{
				v = voisins.cases[j];
				// On teste tous les voisins de la couleur de l'adversaire
				if (currentPosition.cols[v].couleur != myColor)
				{
					voisCouleur = voisCouleur + 1;
					//printf("Incrémentation de voisCouleur --- empilement sur adversaire, pile de 4\n");
					//printf("Valeur de voisCouleur : %d\n",voisCouleur );
				}

				if (currentPosition.cols[v].nb + currentPosition.cols[o].nb + currentPosition.cols[d].nb != 5
					&& currentPosition.cols[v].couleur != myColor ) // si la pile du voisin est différente de 2
				{
					vois = vois + 1; // on incrémente vois
					//printf("Incrémentation de vois --- empilement sur adversaire, pile de 4\n");
					//printf("Valeur de vois : %d\n",vois );
				}
			}
			if (vois == voisCouleur && voisCouleur != 1) // si vois = nombre de voisins, on peut jouer le coup
				{					// c-a-d il n'y aucun voisin qui est une pile de 2
					// printf("nombre de voisins : %d\n",voisins.nb );
					printf("On stocke ce coup dans un tableau -J'empile mon pion sur l'adversaire --> pile de 4\n"); 
					tabRandom[k]=i;
					printf("k avant incrementation : %d et tabRandom[k]/i : %d\n",k,tabRandom[k]);
					k++;
					printf("valeur de k : %d\n",k );
					//ecrireIndexCoup(i);
					//return; // on quitte la fonction 
				}	
		}
	}
	printf("salut\n");
	if (k != 0)
	{
		printf("je passe par la\n");
		a = rand()%(k);
		printf("coucou\n");
		printf("a vaut : %d\n",a);
		printf("tabRandom[a] : %d\n",tabRandom[a]);
		ecrireIndexCoup(tabRandom[a]);
		printf("on joue le coup\n");
		return;
		k=0;
	}
	//k=0; // on remet à k à 0 

// J'empile mes pions sur ceux de l'adversaire pour faire une pile de 3, sauf s'il y a
// une pile de 2 à côté
	for(i=0;i<listeCoups.nb; i++) 
	{
			o = listeCoups.coups[i].origine; 
			d = listeCoups.coups[i].destination;  
			vois = 0;
			voisCouleur = 0;

		if ( (currentPosition.cols[o].couleur == myColor)
			&& (currentPosition.cols[d].couleur != myColor) 
			&& ((currentPosition.cols[o].nb+currentPosition.cols[d].nb) == 3)
			) 
		{
			//printf("Pile de 3 !!\n");
			voisins = getVoisins(d);
			//printf("On récupère les voisins\n");
			for (j = 0; j < voisins.nb; j++)
			{
				v = voisins.cases[j];
				// On teste tous les voisins de la couleur de l'adversaire
				if (currentPosition.cols[v].couleur != myColor)
				{
					voisCouleur = voisCouleur + 1;
					//printf("Incrémentation de voisCouleur --- empilement sur adversaire, pile de 3\n");
					//printf("Valeur de voisCouleur : %d\n",voisCouleur );
				}

				if (currentPosition.cols[v].nb + currentPosition.cols[o].nb + currentPosition.cols[d].nb != 5
					&& currentPosition.cols[v].couleur != myColor) // si la pile du voisin est différente de 2
				{
					vois = vois + 1; // on incrémente vois
					//printf("Incrémentation de vois --- empilement sur adversaire, pile de 3\n");
					//printf("Valeur de vois : %d\n",vois );
				}
			}
			if (vois == voisCouleur && voisCouleur != 1) // si vois = nombre de voisins, on peut jouer le coup
				{					// c-a-d il n'y aucun voisin qui est une pile de 2
					// printf("nombre de voisins : %d\n",voisins.nb );
					printf("On stocke ce coup dans un tableau -J'empile mon pion sur l'adversaire --> pile de 3\n"); 
					tabRandom[k]=i;
					printf("k avant incrementation : %d et tabRandom[k]/i : %d\n",k,tabRandom[k]);
					k++;
					printf("valeur de k : %d\n",k );
					//ecrireIndexCoup(i);
					//return; // on quitte la fonction 
				}	
		}
	}
	printf("salut\n");
	if (k != 0)
	{
		printf("je passe par la\n");
		a = rand()%(k);
		printf("coucou\n");
		printf("a vaut : %d\n",a);
		printf("tabRandom[a] : %d\n",tabRandom[a]);
		ecrireIndexCoup(tabRandom[a]);
		printf("on joue le coup\n");
		return;
		k=0;
	}
	//k=0; // on remet à k à 0 

// Sinon j'empile mes pions sur ceux de l'adversaire sauf s'ils conduisent à une pile 4
// Et je n'empile pas mes pions si ça donne une pile de 3 et une pile de 2 de différentes couleurs
// Sinon on donne une pile de 5 gratuite pour l'adversaire	
	for(i=0;i<listeCoups.nb; i++) 
	{
			o = listeCoups.coups[i].origine; 
			d = listeCoups.coups[i].destination;
			vois = 0;  
			voisCouleur = 0;

		if ( (currentPosition.cols[o].couleur == myColor)
			&& (currentPosition.cols[d].couleur != myColor) 
			&& ((currentPosition.cols[o].nb+currentPosition.cols[d].nb) != 4)
			) 
		{
			//printf("J'empile mes pions sur ceux de l'adversaire !!\n");
			voisins = getVoisins(d);
			//printf("On récupère les voisins\n");
			for (j = 0; j < voisins.nb; j++)
			{
				v = voisins.cases[j];
				// On teste tous les voisins de la couleur de l'adversaire
				if (currentPosition.cols[v].couleur != myColor)
				{
					voisCouleur = voisCouleur + 1;
					//printf("Incrémentation de voisCouleur --- empilement sur adversaire, pile de 3\n");
					//printf("Valeur de voisCouleur : %d\n",voisCouleur );
				}

				if (currentPosition.cols[o].nb + currentPosition.cols[d].nb + currentPosition.cols[v].nb != 5
					&& currentPosition.cols[v].couleur != myColor )
				{
					// si la pile d'origine + la pile de dest + la pile du voisin est différent de 5
					vois = vois + 1; // on incrémente vois
					// en incrémentant vois, on test tous les voisins de la position de destination
					//printf("Incrémentation de vois --- empilement sur adversaire\n");
					//printf("Valeur de vois : %d\n",vois );
				}
			}
			if (vois == voisCouleur && voisCouleur != 1) // si vois = nombre de voisins, on peut jouer le coup
			{						// c-a-d l'adversaire ne peut pas avoir une pile de 5 gratuite
				// printf("nombre de voisins : %d\n",voisins.nb );
				printf("On stocke ce coup dans un tableau -J'empile mon pion sur l'adversaire\n"); 
				tabRandom[k]=i;
				printf("k avant incrementation : %d et tabRandom[k]/i : %d\n",k,tabRandom[k]);
				k++;
				printf("valeur de k : %d\n",k );
				//ecrireIndexCoup(i);
				//return; // on quitte la fonction 
			}
		}
	}
	printf("salut\n");
	if (k != 0)
	{
		printf("je passe par la\n");
		a = rand()%(k);
		printf("coucou\n");
		printf("a vaut : %d\n",a);
		printf("tabRandom[a] : %d\n",tabRandom[a]);
		ecrireIndexCoup(tabRandom[a]);
		printf("on joue le coup\n");
		return;
		k=0;
	}
	//k=0; // on remet à k à 0 


	// Sinon, j'empile des pions adverses sauf s'ils conduisent à des tas de 5 ou 4
	for(i=0;i<listeCoups.nb; i++) 
	{
			o = listeCoups.coups[i].origine; 
			d = listeCoups.coups[i].destination;  
			vois = 0;

		if ( (currentPosition.cols[o].couleur != myColor)
			&& (currentPosition.cols[d].couleur != myColor) 
			&& ((currentPosition.cols[o].nb+currentPosition.cols[d].nb) != 5 || 
				(currentPosition.cols[o].nb+currentPosition.cols[d].nb) != 4 )
			) 
		{
			voisins = getVoisins(d);
			for (j = 0; j < voisins.nb; ++j)
			{
				v = voisins.cases[j];

				if (currentPosition.cols[v].nb + currentPosition.cols[o].nb + currentPosition.cols[d].nb == 5)
					vois = vois + 1;
			}

			if (vois != 0)
			{
				printf("On stocke ce coup dans un tableau -J'empile les pions de l'adversaire\n"); 
				tabRandom[k]=i;
				printf("k avant incrementation : %d et tabRandom[k]/i : %d\n",k,tabRandom[k]);
				k++;
				printf("valeur de k : %d\n",k );
				//ecrireIndexCoup(i);
				//return; // on quitte la fonction 
			}
				
		}
	}
	printf("salut\n");
	if (k != 0)
	{
		printf("je passe par la\n");
		a = rand()%(k);
		printf("coucou\n");
		printf("a vaut : %d\n",a);
		printf("tabRandom[a] : %d\n",tabRandom[a]);
		ecrireIndexCoup(tabRandom[a]);
		printf("on joue le coup\n");
		return;
		k=0;
	}
	//k=0; // on remet à k à 0 
 
	// Sinon, je tire au sort 

	while (1) 
	{
		a = rand()%listeCoups.nb;
		o = listeCoups.coups[a].origine; 
		d = listeCoups.coups[a].destination;  
 
		if ( (currentPosition.cols[o].couleur != myColor)
		&& ((currentPosition.cols[o].nb+currentPosition.cols[d].nb) != 5) ) 
		{
			printf("On choisit ce coup ! -Full random\n"); 
			ecrireIndexCoup(a);
			return; // on quitte la fonction 
		}
	}
	
}
