/********* Moteur de tournoi : joueur ***************/

#include <stdio.h>
#include <stdlib.h>
#include "avalam.h"
#include "moteur.h"


void choisirCoup(T_Position currentPosition, T_ListeCoups listeCoups) 
{
    //VARIABLES
	int i, j, k, cpt, advert; 
	octet o, d; 
	octet myColor = currentPosition.trait; 
	T_Voisins voisinsD;
	T_Voisins voisinsO;

	//afficherListeCoups(listeCoups);
	printf("Ma couleur : %s\n", COLNAME(currentPosition.trait));

	// ------------------------------ BOUCLE STARTER JAUNE: PRIORITAIRE 1----------------------------- //
	for(i=0;i<listeCoups.nb; i++) 
    {
    	o = listeCoups.coups[i].origine; 
		d = listeCoups.coups[i].destination;

		if(myColor==1)
		{
			if(o == 0 && d == 4)
			{
				if(currentPosition.cols[o].nb == 1 && currentPosition.cols[d].nb == 1)
				{
					printf("STARTER PART 1\n");
					printf("On choisit ce coup ! \n"); 
					ecrireIndexCoup(i);
					return; // on quitte la fonction
				}
			}
			if(o == 7 && d == 2)
			{
					if(currentPosition.cols[o].nb == 1 && currentPosition.cols[d].nb == 1)
					{
							printf("STARTER PART 2\n");
							printf("On choisit ce coup ! \n"); 
							ecrireIndexCoup(i);
							return; // on quitte la fonction
					}
			}
			if(o == 6 && d == 2)
			{
				if(currentPosition.cols[o].nb == 1 && currentPosition.cols[d].nb == 2)
				{
					printf("STARTER PART 3\n");
					printf("On choisit ce coup ! \n"); 
					ecrireIndexCoup(i);
					return; // on quitte la fonction
				}
			}
		}

		/*if(myColor==2)
		{
			if(o == 21 && d == 28)
			{
				if(currentPosition.cols[o].nb == 1 && currentPosition.cols[d].nb == 1)
				{
					printf("On choisit ce coup ! \n"); 
					ecrireIndexCoup(i);
					return; // on quitte la fonction
				}
			}										
		if(o == 29 && d == 30)
		{
			if(currentPosition.cols[o].nb == 1 && currentPosition.cols[d].nb == 1)
				{
					printf("On choisit ce coup ! \n"); 
					ecrireIndexCoup(i);
					return; // on quitte la fonction
				}
			}
		}*/
	}
	
	// ------------------------------ BOUCLE DE LA PRISE DUNE PILE DE 5 : PRIORITAIRE 2----------------------------- //
    for(i=0;i<listeCoups.nb; i++) 
    {
    	o = listeCoups.coups[i].origine; 
		d = listeCoups.coups[i].destination; 
		cpt = 1;
		voisinsD = getVoisins(d);

        if ((currentPosition.cols[o].couleur == myColor) && ((currentPosition.cols[o].nb+currentPosition.cols[d].nb) == 5) && (currentPosition.cols[d].couleur != myColor)) //On prend une pile de 5
        {
			printf("COUP PILE DE 5\n");
            printf("On choisit ce coup ! \n"); 
            ecrireIndexCoup(i);
            return;
        }
	}

	// ------------------------------ BOUCLE DE LA PRISE DUNE PILE AUTRE QUE 5 ET ISOLEMENT : PRIORITAIRE 3----------------------------- //
	for(i=0;i<listeCoups.nb; i++) 
    {
		o = listeCoups.coups[i].origine; 
		d = listeCoups.coups[i].destination; 
		cpt = 1;
		voisinsD = getVoisins(d);
		
		if((currentPosition.cols[d].couleur != myColor) && (voisinsD.nb == 1) && currentPosition.cols[o].couleur == myColor) 
        {
			printf("ISOLEMENT 1 !! \n");
            printf("On choisit ce coup ! \n"); 
            ecrireIndexCoup(i);
            return; 
        }
		if((currentPosition.cols[d].couleur != myColor) && (voisinsD.nb > 1) && currentPosition.cols[o].couleur == myColor) 
        {
			cpt = 1;
			for(j=1;j<=voisinsD.nb;j++)
			{
				if((currentPosition.cols[voisinsD.cases[j]].couleur == myColor) || (currentPosition.cols[o].nb+currentPosition.cols[d].nb+currentPosition.cols[voisinsD.cases[j]].nb) > 5)
				{
					cpt++;
					printf("COMPTEUR %d ----- %d\n", cpt, voisinsD.nb);
				}
			} 
			if(cpt >= voisinsD.nb)
			{
					printf("ISOLEMENT 2 !! \n");
					printf("On choisit ce coup ! \n"); 
					ecrireIndexCoup(i);
					return; 
			}	
        }
	} 

	// ------------------------------ BOUCLE DE LA TECHNIQUE ETOILE: PRIORITAIRE 4----------------------------- //
	for(i=0;i<listeCoups.nb; i++) 
    {
		o = listeCoups.coups[i].origine; 
		d = listeCoups.coups[i].destination; 
		cpt = 1;
		advert = 0;
		voisinsD = getVoisins(d);
		voisinsO = getVoisins(o);
		
		if(currentPosition.cols[o].couleur == myColor && currentPosition.cols[d].couleur != myColor && currentPosition.cols[d].nb==2)
		{
			for(j=1; j<=voisinsD.nb; j++) 
			{
				if(currentPosition.cols[voisinsD.cases[j]].couleur != myColor)
				{
					if(currentPosition.cols[voisinsD.cases[j]].nb+currentPosition.cols[d].nb+currentPosition.cols[o].nb == 5)
					{
						advert=1;
					}
				}
				if(currentPosition.cols[voisinsD.cases[j]].couleur == myColor)
				{
					cpt++;
				}

				if(cpt >=3 && advert == 0)
				{
					printf("TECH ETOILE PART1 !! \n");
					printf("On choisit ce coup ! \n"); 
					ecrireIndexCoup(i);
					return; 
				}
			}
		}
	}

	for(i=0;i<listeCoups.nb; i++) 
    {
		o = listeCoups.coups[i].origine; 
		d = listeCoups.coups[i].destination; 
		cpt = 1;
		advert = 0;
		voisinsD = getVoisins(d);
		voisinsO = getVoisins(o);
		
		advert=0;
		cpt = 1;
		if(currentPosition.cols[o].couleur != myColor && currentPosition.cols[d].couleur != myColor)
		{
			for(j=1; j<=voisinsD.nb; j++) 
			{
				if(currentPosition.cols[voisinsD.cases[j]].couleur == myColor && currentPosition.cols[voisinsD.cases[j]].nb == 1)
				{
					cpt++;
				}
				if(currentPosition.cols[voisinsD.cases[j]].nb+currentPosition.cols[d].nb+currentPosition.cols[o].nb == 5)
				{
					advert=1;
				}
			}
		}
		if(cpt >= 3 && advert == 0)
		{
			printf("TECH ETOILE PART 1 !!\n");
			printf("On choisit ce coup ! \n"); 
			ecrireIndexCoup(i);
			return; 
		}
	}
	
	// ------------------------------ BOUCLE DU COUP DE BASE: PAS PRIORITAIRE---------------------------- //
    for(i=0;i<listeCoups.nb; i++) 
    {
		o = listeCoups.coups[i].origine; 
		d = listeCoups.coups[i].destination; 
		
		voisinsD = getVoisins(d);
		voisinsO = getVoisins(o);
		cpt = 1;
		
		for(j=1; j<=voisinsD.nb; j++)
		{
			if((currentPosition.cols[o].nb+currentPosition.cols[d].nb+currentPosition.cols[voisinsD.cases[j]].nb) == 5 && currentPosition.cols[o].couleur != myColor)
			{
				cpt=2;
			}
		}
		if(currentPosition.cols[o].couleur != myColor && currentPosition.cols[d].couleur != myColor)
			{
				if(voisinsO.nb !=1)
				{
					for(k=1;k<=voisinsD.nb;k++)
					{
						if(currentPosition.cols[o].nb+currentPosition.cols[voisinsO.cases[k]].nb > 5)
						{
							cpt=2;
						}
					}
				}
				if(voisinsD.nb !=1)
				{
					for(k=1;k<=voisinsD.nb;k++)
					{
						if(currentPosition.cols[d].nb+currentPosition.cols[voisinsO.cases[k]].nb > 5)
						{
							cpt=2;
						}
					}
				}
				if(voisinsO.nb == 1 && voisinsD.nb == 1)
				{
					cpt=2;
				}
		}
		if(cpt == 2) //On passe a l'itération suivante dans la boucle
		{
			continue;
		}
		if ((currentPosition.cols[o].couleur != myColor) && (currentPosition.cols[d].couleur != myColor)) 
		{
			printf("COUP DE BASE !!\n");
			printf("On choisit ce coup ! \n"); 
			ecrireIndexCoup(i);
			return; 
		}
	}
}