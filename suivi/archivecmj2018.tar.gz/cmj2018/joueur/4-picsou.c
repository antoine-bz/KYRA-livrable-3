#include <stdio.h>
#include <stdlib.h>
#include "avalam.h"
#include "moteur.h"



void choisirCoup(T_Position currentPosition, T_ListeCoups listeCoups) {
	// Cette fonction peut appeler la fonction ecrireIndexCoup(coupChoisi);
	// Pour sélectionner l'index d'un coup à jouer dans la liste l 

	// aléatoire 
	// ecrireIndexCoup(rand()%listeCoups.nb);

	int i; 
	octet o, d; // O COMME ORIGINE ET D comme destination
	int a; 
	octet myColor = currentPosition.trait; 

//////////////////////////////

        int d_interdite, o_interdite, d_interdite2, o_interdite2, d_interdite3, o_interdite3 ,d_interdite4, o_interdite4, d_interdite5, o_interdite5, d_interdite6, o_interdite6;
	int nvcase, nvcase2;


/////////////////////////////
//coups inutiles 
        int d_inutile, o_inutile, d_inutile2, o_inutile2 ,d_inutile3 , o_inutile3, d_inutile4, o_inutile4;


/////////////////////////////

	// afficherListeCoups(listeCoups);


	printf("Ma couleur : %s\n", COLNAME(currentPosition.trait));

///////////////////////////////////////////////////////////////////////////
// les coups interdits 

	for(i=0;i<listeCoups.nb; i++) {
		o = listeCoups.coups[i].origine; 
		d = listeCoups.coups[i].destination;  

		printf("Coup %d : ", i); 
		printf("%d (%d - %s) ->", o, currentPosition.cols[o].nb, COLNAME(currentPosition.cols[o].couleur));
		printf("%d (%d - %s) \n", d, currentPosition.cols[d].nb, COLNAME(currentPosition.cols[d].couleur)); 

//////////////////////////////////////////////
	// Si colonne à coté = 3

/////////////////////////////////on évite de donner des colonnes de 4 à l'adversaire 


	if ( currentPosition.cols[d].nb == 3 ) {


			printf("le coup peut être dangeureux ! \n"); 
			printf("on reprend 'd', la destination \n"); 

                        nvcase = d;
			nvcase2 = o;

			for(i=0;i<listeCoups.nb; i++) {
				o = listeCoups.coups[i].origine; 
				d = listeCoups.coups[i].destination; 

				if( o == nvcase ) {

					if ( (currentPosition.cols[d].nb == 1) && (currentPosition.cols[d].couleur != myColor) ) {
 
							d_interdite = nvcase;	
							o_interdite = nvcase2;
						}

					}

				}

		 // on ne quitte pas la fonction c'est pas un coup qui est joué 
		}
//////////////////////////////////////////////

	if ( currentPosition.cols[d].nb == 1 ) {


			printf("le coup peut être dangeureux ! \n"); 
			printf("on reprend 'd', la destination \n"); 

                        nvcase = d;
			nvcase2 = o;

			for(i=0;i<listeCoups.nb; i++) {
				o = listeCoups.coups[i].origine; 
				d = listeCoups.coups[i].destination; 

				if( o == nvcase ) {

					if ( (currentPosition.cols[d].nb == 3) && (currentPosition.cols[d].couleur != myColor) ) {
 
							d_interdite2 = nvcase;	
							o_interdite2 = nvcase2;
						}

					}

				}

		 // on ne quitte pas la fonction c'est pas un coup qui est joué 
		}


//////////////////////////////////////////////

	if ( currentPosition.cols[d].nb == 2 ) {


			printf("le coup peut être dangeureux ! \n"); 
			printf("on reprend 'd', la destination \n"); 

                        nvcase = d;
			nvcase2 = o;

			for(i=0;i<listeCoups.nb; i++) {
				o = listeCoups.coups[i].origine; 
				d = listeCoups.coups[i].destination; 

				if( o == nvcase ) {

					if ( (currentPosition.cols[d].nb == 2) && (currentPosition.cols[d].couleur != myColor) ) {
 
							d_interdite3 = nvcase;	
							o_interdite3 = nvcase2;
						}

					}

				}

		 // on ne quitte pas la fonction c'est pas un coup qui est joué 
		}


//////////////////////////////////////////////
int compt;

	if ( currentPosition.cols[d].nb == 2 && currentPosition.cols[d].couleur == myColor  && currentPosition.cols[o].couleur == myColor && currentPosition.cols[o].nb ==3) {


			printf("le coup est peut-être inutile ! \n"); 
			printf("on reprend 'd', la destination \n"); 

                        nvcase = d;
			nvcase2 = o;
			compt = 0;

			for(i=0;i<listeCoups.nb; i++) {
				o = listeCoups.coups[i].origine; 
				d = listeCoups.coups[i].destination; 

				if( o == nvcase ) {

					if ( currentPosition.cols[d].couleur != myColor ) {
						//si au moins un voisin est différent de ma couleur  
						compt++;
						}

					}

				}
                              if(compt == 0){   o_inutile = nvcase2;  d_inutile = nvcase;   }




		 // on ne quitte pas la fonction c'est pas un coup qui est joué 
		}

//////////////////////////////////////////////


	if ( currentPosition.cols[d].nb == 3 && currentPosition.cols[d].couleur == myColor  && currentPosition.cols[o].couleur == myColor && currentPosition.cols[o].nb ==2) {


			printf("le coup est peut-être inutile ! \n"); 
			printf("on reprend 'd', la destination \n"); 

                        nvcase = d;
			nvcase2 = o;
			compt = 0;

			for(i=0;i<listeCoups.nb; i++) {
				o = listeCoups.coups[i].origine; 
				d = listeCoups.coups[i].destination; 

				if( o == nvcase ) {

					if ( currentPosition.cols[d].couleur != myColor ) {
						//si au moins un voisin est différent de ma couleur  
						compt++;
						}

					}

				}
                              if(compt == 0){   o_inutile2 = nvcase2;  d_inutile2 = nvcase;   }




		 // on ne quitte pas la fonction c'est pas un coup qui est joué 
		}

//////////////////////////////////////////////




	if ( currentPosition.cols[d].nb == 1 && currentPosition.cols[d].couleur == myColor  && currentPosition.cols[o].couleur == myColor && currentPosition.cols[o].nb ==4) {


			printf("le coup est peut-être inutile ! \n"); 
			printf("on reprend 'd', la destination \n"); 

                        nvcase = d;
			nvcase2 = o;
			compt = 0;

			for(i=0;i<listeCoups.nb; i++) {
				o = listeCoups.coups[i].origine; 
				d = listeCoups.coups[i].destination; 

				if( o == nvcase ) {

					if ( currentPosition.cols[d].couleur != myColor ) {
						//si au moins un voisin est différent de ma couleur  
						compt++;
						}

					}

				}
                              if(compt == 0){   o_inutile3 = nvcase2;  d_inutile3 = nvcase;   }




		 // on ne quitte pas la fonction c'est pas un coup qui est joué 
		}

//////////////////////////////////////////////



	if ( currentPosition.cols[d].nb == 4 && currentPosition.cols[d].couleur == myColor  && currentPosition.cols[o].couleur == myColor && currentPosition.cols[o].nb ==1) {


			printf("le coup est peut-être inutile ! \n"); 
			printf("on reprend 'd', la destination \n"); 

                        nvcase = d;
			nvcase2 = o;
			compt = 0;

			for(i=0;i<listeCoups.nb; i++) {
				o = listeCoups.coups[i].origine; 
				d = listeCoups.coups[i].destination; 

				if( o == nvcase ) {

					if ( currentPosition.cols[d].couleur != myColor ) {
						//si au moins un voisin est différent de ma couleur  
						compt++;
						}

					}

				}
                              if(compt == 0){   o_inutile4 = nvcase2;  d_inutile4 = nvcase;   }




		 // on ne quitte pas la fonction c'est pas un coup qui est joué 
		}

//////////////////////////////////////////////
int nvcase3, nvcase4;


	if ( currentPosition.cols[d].nb == 1 ) {


			printf("le coup peut être dangeureux ! \n"); 
			printf("on reprend 'd', la destination \n"); 

                        nvcase = d;
			nvcase2 = o;

			for(i=0;i<listeCoups.nb; i++) {
				o = listeCoups.coups[i].origine; 
				d = listeCoups.coups[i].destination; 

				if( o == nvcase ) {

					if ( (currentPosition.cols[d].nb == 1) ) {
 
						nvcase3 =d;	
						nvcase4 =o;
						for(i=0;i<listeCoups.nb; i++) {
			                        o = listeCoups.coups[i].origine; 
			                        d = listeCoups.coups[i].destination; 

						if( o == nvcase3 ) {
													if ( (currentPosition.cols[d].nb == 3) && (currentPosition.cols[d].couleur != myColor) ) {
d_interdite4 = nvcase;	o_interdite4 = nvcase2; }

							}
						}



						}

					}

				}

		 // on ne quitte pas la fonction c'est pas un coup qui est joué 
		}



//////////////////////////////////////////////




	if ( currentPosition.cols[d].nb == 2 ) {


			printf("le coup peut être dangeureux ! \n"); 
			printf("on reprend 'd', la destination \n"); 

                        nvcase = d;
			nvcase2 = o;

			for(i=0;i<listeCoups.nb; i++) {
				o = listeCoups.coups[i].origine; 
				d = listeCoups.coups[i].destination; 

				if( o == nvcase ) {

					if ( (currentPosition.cols[d].nb == 1) ) {
 
						nvcase3 =d;	
						nvcase4 =o;
						for(i=0;i<listeCoups.nb; i++) {
			                        o = listeCoups.coups[i].origine; 
			                        d = listeCoups.coups[i].destination; 

						if( o == nvcase3 ) {
													if ( (currentPosition.cols[d].nb == 2) && (currentPosition.cols[d].couleur != myColor) ) {
d_interdite5 = nvcase;	o_interdite5 = nvcase2; }

							}
						}



						}

					}

				}

		 // on ne quitte pas la fonction c'est pas un coup qui est joué 
		}




///////////////////////////////////////////////



	if ( currentPosition.cols[d].nb == 1 ) {


			printf("le coup peut être dangeureux ! \n"); 
			printf("on reprend 'd', la destination \n"); 

                        nvcase = d;
			nvcase2 = o;

			for(i=0;i<listeCoups.nb; i++) {
				o = listeCoups.coups[i].origine; 
				d = listeCoups.coups[i].destination; 

				if( o == nvcase ) {

					if ( (currentPosition.cols[d].nb == 2) ) {
 
						nvcase3 =d;	
						nvcase4 =o;
						for(i=0;i<listeCoups.nb; i++) {
			                        o = listeCoups.coups[i].origine; 
			                        d = listeCoups.coups[i].destination; 

						if( o == nvcase3 ) {
													if ( (currentPosition.cols[d].nb == 2) && (currentPosition.cols[d].couleur != myColor) ) {
d_interdite6 = nvcase;	o_interdite6 = nvcase2; }

							}
						}



						}

					}

				}

		 // on ne quitte pas la fonction c'est pas un coup qui est joué 
		}


////////////////////////////////////////////////

	}
	

///////////////////////////////////////////////////////////////////////////


for(i=0;i<listeCoups.nb; i++) {
		o = listeCoups.coups[i].origine; 
		d = listeCoups.coups[i].destination;  

		printf("Coup %d : ", i); 
		printf("%d (%d - %s) ->", o, currentPosition.cols[o].nb, COLNAME(currentPosition.cols[o].couleur));
		printf("%d (%d - %s) \n", d, currentPosition.cols[d].nb, COLNAME(currentPosition.cols[d].couleur)); 

	// Si je peux gagner une colonne, je la prends 
        // différents stratégies "si je peux ganger la colonne je prend"



	// 1 -> 4
	if ( (currentPosition.cols[o].couleur == myColor)
		&& (currentPosition.cols[d].nb == 4) && ( o != o_interdite3) && ( d != d_interdite3) && (o != o_inutile3) && (d != d_inutile3)  ) {
			printf("On regarde le coup ! \n");

							ecrireIndexCoup(i);
							return; // on quitte la fonction 
			}


///////////////////////////////////////////////////////////////////////

	// 2->3
	if ( (currentPosition.cols[o].couleur == myColor)
		&& (currentPosition.cols[d].nb == 3) && (currentPosition.cols[o].nb == 2) && (o != o_inutile2) && (d != d_inutile2)  ) {

			printf("On regarde le coup ! \n"); 

							ecrireIndexCoup(i);
							return; // on quitte la fonction 
		}


////////////////////////////////////////////////////////////////////






	// 3->2
	if ( (currentPosition.cols[o].couleur == myColor)
		&& (currentPosition.cols[d].nb == 2) && (currentPosition.cols[o].nb == 3)  && (o != o_inutile) && (d != d_inutile)) {

			printf("On regarde le coup ! \n"); 

							ecrireIndexCoup(i);
							return; // on quitte la fonction 

		}

///////////////////////////////////////////////////////////////////

	// 4->1
	if ( (currentPosition.cols[o].couleur == myColor)
		&& (currentPosition.cols[d].nb == 1) && (currentPosition.cols[o].nb == 4) && (o != o_inutile4) && (d != d_inutile4) ) {

			printf("On regarde le coup ! \n"); 

							ecrireIndexCoup(i);
							return; // on quitte la fonction 

		}

///////////////////////////////////////////////////////////////////
/*
int compt2;

       if ( (currentPosition.cols[o].couleur == myColor) ) {
	   		nvcase = d;
			nvcase2 = o;
                        compt2 = 0;

			for(i=0;i<listeCoups.nb; i++) {
				o = listeCoups.coups[i].origine; 
				d = listeCoups.coups[i].destination; 


				if( o == nvcase ) {
					compt2++;
					}

				}
                              if(compt2 == 1){  printf("On regarde le coup ! \n"); ecrireIndexCoup(i);  }

	


	}
*/

////////////////////////////////////////////////////////////////////
	}


///////////////////////////////////////////////////////////////////////////


 

	// Sinon, j'empile des pions adverses sauf s'ils conduisent à des tas de 5 
 for(i=0;i<listeCoups.nb; i++) {
		o = listeCoups.coups[i].origine; 
		d = listeCoups.coups[i].destination;  

	if ( (currentPosition.cols[o].couleur != myColor)
		&& (currentPosition.cols[d].couleur != myColor) 
		&& (currentPosition.cols[d].nb < 3 && ( o != o_interdite) && ( d != d_interdite) && ( o != o_interdite2) && ( d != d_interdite2) && ( o != o_interdite3) && ( d != d_interdite3)  && ( o != o_interdite4) && ( d != d_interdite4) && ( o != o_interdite5) && ( d != d_interdite5)  && ( o != o_interdite6) && ( d != d_interdite6))
		) {
			printf("On choisit ce coup ! \n"); 
			ecrireIndexCoup(i);
			return; // on quitte la fonction 
		}
	}
 

///////////////////////////////////////////////////////////////////////////



	// Sinon, je tire au sort 

	while (1) {
		a = rand()%listeCoups.nb;
		o = listeCoups.coups[a].origine; 
		d = listeCoups.coups[a].destination;  
 
		if ( (currentPosition.cols[o].couleur != myColor)
		&& (currentPosition.cols[d].nb != 4) && ( o != o_interdite) && ( d != d_interdite) && ( o != o_interdite2) && ( d != d_interdite2) && ( o != o_interdite3) && ( d != d_interdite3)  && ( o != o_interdite4) && ( d != d_interdite4) && ( o != o_interdite5) && ( d != d_interdite5)  && ( o != o_interdite6) && ( d != d_interdite6) ) {
			printf("On choisit ce coup ! \n"); 
			ecrireIndexCoup(a);
			return; // on quitte la fonction 
		}
	}
///////////////////////////////////////////////////////////////////////////	

}



