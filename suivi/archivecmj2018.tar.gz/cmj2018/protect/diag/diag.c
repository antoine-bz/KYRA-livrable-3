#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <dirent.h>

#include <avalam.h>
#include <topologie.h>

#ifndef DEFAULT_JSON_FILE
	#define DEFAULT_JSON_FILE "diag.js"
#endif 

#ifndef DEFAULT_JSON_REP
	#define DEFAULT_JSON_REP "./data"
#endif 

#define MAXLEN_FILE 1000
#define MAXLEN_FILEPATH 1000
#define MAXLEN_BUFFER 100
#define MAXLEN_DESCR 10000
#define MIN(a,b) ((a<=b) ? a : b)

/*
Permet de passer en ligne de commandes :
un numéro du diagramme
une position, type “FEN”
Une fois le programme lancé, saisie du nom du fichier et d’une chaîne de description au clavier, facultatifs
Produit un fichier json avec la position et la description utilisé par avalam-diag

TODO: l'automate de reconnaissance n'est pas robuste... A vérifier et compléter
*/

void writePos(char * filename, T_Position p, int numDiag, char * description, char * fen) ; 



int main(int argc, char ** argv){
	int numCase, numCaseD; 
	T_Score s ; 
	char filename[MAXLEN_FILE]; 
	char buffer[MAXLEN_BUFFER]; 
	char description[MAXLEN_DESCR] = ""; 
	T_Position p; 
	int i,j, max; 
	int nextCol=0; 


	if (argc != 3) {
		fprintf(stderr,"diag <numDiag> <fen>\n");
		return 1; 
	}

	int numDiag = atoi(argv[1]);
	char * strFen = argv[2]; 

	printf("Diagramme %d\n",numDiag);
	printf("Fen : %s\n",strFen);

	// parcours de la chaine //////////////////////////////////////////////
	// minuscules : jaunes 
	for(i=0;i<strlen(strFen);i++) {
		printf1("traitement de %c\n", strFen[i]);
		switch(strFen[i]) {

			case 'u' : 
				if (nextCol==48) continue; 
				p.cols[nextCol].couleur = JAU; p.cols[nextCol++].nb = 1; break; 

			case 'd' : 
				if (nextCol==48) continue; 
				p.cols[nextCol].couleur = JAU; p.cols[nextCol++].nb = 2; break; 

			case 't' : 
				if (nextCol==48) continue; 
				p.cols[nextCol].couleur = JAU; p.cols[nextCol++].nb = 3; break;  

			case 'q' : 
				if (nextCol==48) continue; 
				p.cols[nextCol].couleur = JAU; p.cols[nextCol++].nb = 4; break;  

			case 'c' : 
				if (nextCol==48) continue; 
				p.cols[nextCol].couleur = JAU; p.cols[nextCol++].nb = 5; break;  

			case 'U' : 
				if (nextCol==48) continue; 
				p.cols[nextCol].couleur = ROU; p.cols[nextCol++].nb = 1; break; 

			case 'D' : 
				if (nextCol==48) continue; 
				p.cols[nextCol].couleur = ROU; p.cols[nextCol++].nb = 2; break; 

			case 'T' : 
				if (nextCol==48) continue; 
				p.cols[nextCol].couleur = ROU; p.cols[nextCol++].nb = 3; break;  

			case 'Q' : 
				if (nextCol==48) continue; 
				p.cols[nextCol].couleur = ROU; p.cols[nextCol++].nb = 4; break;  

			case 'C' : 
				if (nextCol==48) continue; 
				p.cols[nextCol].couleur = ROU; p.cols[nextCol++].nb = 5; break;

			case ' ' : if (nextCol!=48) {
										printf1("espace mal placé - nextCol vaut %d\n", nextCol); 										
										if (nextCol<48) { 
											printf1("ajout de %d case(s) vide(s)\n",48-nextCol);
										}
										else {
											printf("Nombre de colonnes dépassé. Ne devrait pas arriver !\n");
											return 2;  
										}
								}

									break;

			case 'J' : case 'j' : 
				p.trait = JAU; break; 

			case 'R' : case 'r' : 
				p.trait = ROU; break;  

			default : 
				// non reconnu
				if (('1'>strFen[i])&&(strFen[i]>'9')) {
					printf1("caractere %c non reconnu\n", strFen[i]); 
					continue;
				} 

				// cas chiffre
				max = strFen[i]-'0'; 

				// Attention au cas où le car. suivant est aussi un entier !
				if (i<strlen(strFen)-1) {
					// il y a un caractere suivant 

					if (('1'<=strFen[i+1])&&(strFen[i+1]<='9')) {
						// C'est aussi un chiffre ! 
					
						// on calcule le nombre obtenu
						max = strFen[i+1]-'0' + 10*(strFen[i]-'0'); 
				
						// Attention : il ne faudrait pas déborder !
						if (nextCol+max> 48) {
							printf0("Nombre de colonnes dépassé. Ne devrait pas arriver !\n");
							printf0("On ne tient pas compte du second nombre !\n");	
							max = strFen[i]-'0';
						} else {
							// On peut en tenir compte : on incrémente i
							i++;
						}
					}
				}

				// Ici on connait le max et on a la bonne valeur de i 
				if (nextCol+max> 48) {
						printf0("Nombre de colonnes dépassé. Ne devrait pas arriver !\n");
						printf0("On ne tient pas compte du premier nombre !\n");
						continue;	
				} else {
					// Nombre OK ou ajustement réalisé
					for(j=0;j<max;j++) {
						p.cols[nextCol].couleur = VIDE; p.cols[nextCol++].nb = 0; 
					}
				}
			
		}
	}
	
	//afficherPosition(p);
	//printf("trait : %s\n", COLNAME(p.trait));
		
	// recup fichier //////////////////////////////////////////////

	printf("Fichier (sera créé dans le répertoire %s s'il existe) ? [%s] ", DEFAULT_JSON_REP, DEFAULT_JSON_FILE); 
	fgets(filename,MAXLEN_FILE,stdin);

	/*fgets()  lit au plus size - 1 caractères depuis stream et les place dans le tampon pointé par s. La lecture s'arrête après EOF ou un retour chariot. Si un retour chariot (newline) est lu, il est placé dans le tampon. Un  octet  nul  (« \0 »)  final  est placé à la fin de la ligne.*/

	// Suppression du \n présent juste avant le \0 final 
	if (filename[strlen(filename)-1] == '\n')
		filename[strlen(filename)-1] = '\0'; 
	//printf("Votre reponse  : .%s.\n", filename);

	if (!strlen(filename)) 
		strcpy(filename,DEFAULT_JSON_FILE);

	printf1("Fichier utilisé : .%s.\n", filename);


	// recup description en HTML //////////////////////////////////////////////
	printf("\nDescription (vous pouvez saisir du HTML, Ctrl+D pour terminer) ? []\n"); 

	while(fgets(buffer,MIN(MAXLEN_DESCR - strlen(description),MAXLEN_BUFFER),stdin) != NULL) {
		//printf("Lu : .%s.\n", buffer);
		strcat(description, buffer); 
		//printf("Decription jusque là : .%s.\n", description); 
		//printf("Taille :%ld\n",strlen(description));
		//printf("restant: %ld\n",MAXLEN_DESCR - strlen(description));

		if ((MAXLEN_DESCR - strlen(description)) <= 1) break;
	}

	// suppression du dernier \n
	if (description[strlen(description)-1] == '\n')
		description[strlen(description)-1] = '\0';

	printf("Description : %s\n", description); 

	// ecriture JSON 
	writePos(filename, p, numDiag, description, strFen);

	return 0; 


	
}



void writePos(char * filename, T_Position p, int numDiag, char * description, char * strFen) {
	FILE * fp; 
	DIR * fd; 
	int i;
	char buffer[ MAXLEN_FILEPATH]; 

	T_Score s = evaluerScore(p); 

	fd = opendir(DEFAULT_JSON_REP); 
	if (fd == NULL) {
		printf("Enregistrement de ./%s\n", filename); 		
		fp = fopen(filename,"w"); 
		if (fp == NULL) {
			printf("Impossible d'ouvrir %s\n", filename); 
			exit(1);	
		}
	} else {
		closedir(fd);
		sprintf(buffer,"%s/%s",DEFAULT_JSON_REP, filename);
		printf("Enregistrement de %s\n",buffer);
		fp = fopen(buffer,"w"); 
		if (fp == NULL) {
			printf("Impossible d'ouvrir %s\n", filename); 
			exit(1);	
		}
	}


	// On écrit le trait 
	fprintf(fp, "traiterJson({\n%s:%d,\n",STR_TURN,p.trait); 

	// numDiag
	fprintf(fp, "%s:%d,\n",STR_NUMDIAG,numDiag); 

	// notes 
	fprintf(fp, "%s:\"%s\",\n",STR_NOTES,description); 

	// fen
 	fprintf(fp, "%s:\"%s\",\n",STR_FEN,strFen); 

	// Les colonnes // attention aux "," ?
	fprintf(fp, "%s:[\n",STR_COLS);

	// première 
	fprintf(fp, "\t{%s:%d, %s:%d}",STR_NB,p.cols[0].nb, STR_COULEUR,p.cols[0].couleur); 	

	// autres
	for(i=1;i<NBCASES;i++) {
		fprintf(fp, ",\n\t{%s:%d, %s:%d}",STR_NB,p.cols[i].nb, STR_COULEUR,p.cols[i].couleur); 	
	}
	fprintf(fp,"\n]\n"); // avec ou sans "," ? 

	fprintf(fp,"});");

	fclose(fp);
}







