traiterJson({
"j":"Kantaou2i",
"r":"exempt",
"ronde":32,
"resultat":"1-0",
"scoreJ":1,
"scoreJ5":0,
"scoreR":0,
"scoreR5":0,
"coups":[

]});