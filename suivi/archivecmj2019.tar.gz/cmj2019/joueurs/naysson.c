/********* Moteur de tournoi : joueur ***************/

#include <stdio.h>
#include <stdlib.h>
#include "avalam.h"
#include "moteur.h"

//#define __DEBUG_ENTAME__

#define SCORE_tour_certaine_inferieur5 200
#define SCORE_tour_certaine_5 201
#define SCORE_tour_voisin_notre_couleur_4 200 //c'est une tour certaine inférieure à 5
#define SCORE_tour_voisin_notre_couleur_inferieur4 150

#define COUPS_MINIMAX 100


typedef enum {MIN,MAX}T_TypeNoeud;

typedef struct {
    int indiceCoup;
    int score;
}T_Resultat;

octet getReelsVoisinsNb(T_Voisins , T_Position );
octet getReelsVoisinsNbAutreCouleur(T_Voisins,octet, T_Position );
octet getReelsVoisinsNbMaCouleur(T_Voisins,octet, T_Position );

int evaluation(T_Position, octet);
T_Resultat algoMinimax(T_Position currentPosition, octet couleur,int profondeur, int profondeurMax);

int DonneLeMin(int tabVoisin[], int taille);
short plateauNiemeCoup(T_Position,short);  //renvoie 1 s'il n'y a eu que n coups dans le plateau
octet presenceTourTrois(T_Position);    // renvoie la position de la seul tour de trois s'il y en a une, sinon renvoie 48
int rechercherIndexCoup(octet, octet,T_ListeCoups);
octet rechercherTourDeux(T_Position, octet *caseTourDeux);  //renvoie la couleur de la case contenant la tour de deux
octet determinerVoisinIsole(T_Voisins listeVoisins, octet couleurCaseConcerne,T_Position currentPosition); // renvoie la position de la case ayant le moins de voisins parmi une liste de position
octet determinerVoisinJauneEntoure(T_Voisins listeVoisinsJaune,T_Position); // renvoie la position de la case jaune ayant le plus de voisins réels parmi la liste des positions
short voisinageVierge(octet position,T_Position currentPosition);


void choisirCoup(T_Position currentPosition, T_ListeCoups listeCoups) {
    // Cette fonction peut appeler la fonction ecrireIndexCoup(coupChoisi);
    // Pour sélectionner l'index d'un coup à jouer dans la liste l

    // aléatoire
    // ecrireIndexCoup(rand()%listeCoups.nb);

    int i;
    octet o, d;
    int a;
    octet myColor = currentPosition.trait;
    T_Voisins voisinsDest, voisinsOrigine;
    int nbDeVoisinsReel;

    octet nbDeVoisinsReelDest;
    octet nbDeVoisinsMaCouleurDest;
    octet nbDeVoisinsAutresCouleurDest;

    octet nbDeVoisinsReelOrigine;
    octet nbDeVoisinsMaCouleurOrigine;
    octet nbDeVoisinsAutresCouleurOrigine;
    int MinTailleVoisin;

    int voisinstab_premierefct[8];
    int voisinstab2_premierefct[8];


    /***************************ENTAME DE LA PARTIE*************************/
    if(myColor==JAU) {
        // Si personne a joué sur le plateau
        if( listeCoups.nb == 292) {
#ifdef __DEBUG_ENTAME__
            printf(" Entame - aucun coup a été joué, on joue le coup 4--->9 (index : 25)\n");
#endif
            ecrireIndexCoup(25);   // pour jouer le coup 4---->9 (rouge sur rouge)
        }
        // S'il n'y a eu que deux coups dans le plateau
        if( plateauNiemeCoup(currentPosition,2) ) {
            octet caseTourTrois= presenceTourTrois(currentPosition);
#ifdef __DEBUG_ENTAME__
            printf(" Entame - Deux coups ont été joués, position de la tour de trois : %d\n",caseTourTrois);
#endif
            // S'il y a une tour de 3
            if( caseTourTrois != 48) {
                /* On éloigne le voisin rouge qui a le plus de voisins réels sur le pion rouge
                 * qui a le plus de voisins jaunes
                 */
                //On recherche la case d'origine
                octet caseVictimeOrigine=0,maxVoisins=0;
                T_Voisins listeVoisinsTourTrois= getVoisins(caseTourTrois);
                for(int i=0; i< listeVoisinsTourTrois.nb;i++) {
                    T_Voisins listeVoisins = getVoisins(listeVoisinsTourTrois.cases[i]);
                    if( currentPosition.cols[listeVoisinsTourTrois.cases[i]].couleur == ROU) {
                        octet nbVoisinsReels = getReelsVoisinsNb(listeVoisins, currentPosition);
#ifdef __DEBUG_ENTAME__
                        printf(" Entame - JAU - Tour de 3 - nbVoisinsReels = %d\n", nbVoisinsReels);
#endif
                        if (nbVoisinsReels > maxVoisins) {
                            maxVoisins = nbVoisinsReels;
                            caseVictimeOrigine = listeVoisinsTourTrois.cases[i];
                        }
                    }
                }
#ifdef __DEBUG_ENTAME__
                printf(" Entame - Le voisin rouge qui a le plus de voisins est en position %d\n",caseVictimeOrigine);
#endif
                // On recherche la case destination
                octet caseVictimeDestination=0,maxVoisinsJaunes=0;
                T_Voisins listeVoisinsCaseVictimeOrigine = getVoisins(caseVictimeOrigine);
                for(int i=0; i< listeVoisinsCaseVictimeOrigine.nb;i++) {
                    T_Voisins listeVoisins = getVoisins(listeVoisinsTourTrois.cases[i]);
                    octet nbVoisinsReelsJaunes = getReelsVoisinsNbMaCouleur(listeVoisins,myColor,currentPosition);
                    if( nbVoisinsReelsJaunes > maxVoisinsJaunes) {
                        maxVoisinsJaunes = nbVoisinsReelsJaunes;
                        caseVictimeDestination = listeVoisinsCaseVictimeOrigine.cases[i];
                    }
                }
#ifdef __DEBUG_ENTAME__
                printf(" Entame - Le pion rouge qui a le plus de voisins jaunes est en position %d\n",caseVictimeDestination);
#endif
                int indexCoupAJouer = rechercherIndexCoup(caseVictimeOrigine,caseVictimeDestination,listeCoups);
#ifdef __DEBUG_ENTAME__
                printf(" Entame - On joue le pion %d sur le pion %d, (index : %d)\n",caseVictimeOrigine,caseVictimeDestination,indexCoupAJouer);
#endif
                if (indexCoupAJouer != -1) {
                    ecrireIndexCoup(indexCoupAJouer);
                    return;
                }

            }
                // Si l'adversaire a joué une tour de 2
            else {
#ifdef __DEBUG_ENTAME__
                printf(" Entame - L'adversaire a joué une tour de 2\n");
#endif
                // si le rouge n'a pas joué chez les voisins de la case 9
                if( voisinageVierge(9,currentPosition) ) {
                    //alors on joue 14->9
                    int indexCoupAJouer = rechercherIndexCoup(14,9,listeCoups);
#ifdef __DEBUG_ENTAME__
                    printf(" Entame - On joue le pion 14 sur le pion 9, (index : %d)\n",indexCoupAJouer);
#endif
                    if (indexCoupAJouer != -1) {
                        ecrireIndexCoup(indexCoupAJouer);
                        return;
                    }
                }
                else {
                    // sinon on joue 33->38
                    int indexCoupAJouer = rechercherIndexCoup(33,38,listeCoups);
#ifdef __DEBUG_ENTAME__
                    printf(" Entame - On joue le pion 33 sur le pion 38, (index : %d)\n",indexCoupAJouer);
#endif
                    if (indexCoupAJouer != -1) {
                        ecrireIndexCoup(indexCoupAJouer);
                        return;
                    }
                }
            }
        }  // fin deuxième couo

    }  // fin pour les coups jaunes

        // Si je suis rouge
    else {
        // Si un seul coup a été joué
        if (plateauNiemeCoup(currentPosition, 1)) {
            /*Le 1er coup a déjà été joué, on distingue 2 cas :
             * une tour de jaunes (adv) et une tour de rouges (nous)
             */
            octet caseVictime; // case ayant la tour 2
            octet couleurTourDeux = rechercherTourDeux(currentPosition, &caseVictime);
#ifdef __DEBUG_ENTAME__
            printf(" Entame - La tour de deux (couleur = %d) est sur la position %d\n", couleurTourDeux, caseVictime);
#endif
            switch (couleurTourDeux) {
                case JAU :
                    /* On empile sur la tour jaune, le pion rouge qui a le moins de voisins réels*/
                    // On a pas le droit de faire des déclarations juste après un case (on met un if)
                    if (0 == 1 - 1) {
                        T_Voisins listeVoisinsJaune = getVoisins(caseVictime);
                        octet caseEnfileur = determinerVoisinIsole(listeVoisinsJaune, ROU, currentPosition);
                        int indexCoupAJouer = rechercherIndexCoup(caseEnfileur, caseVictime, listeCoups);
#ifdef __DEBUG_ENTAME__
                        printf(" Entame - On joue le pion %d sur le pion %d, (index : %d)\n", caseEnfileur, caseVictime,
                               indexCoupAJouer);
#endif
                        if (indexCoupAJouer != -1) {
                            ecrireIndexCoup(indexCoupAJouer);
                            return;
                        }
                    }
                    break;

                case ROU :
                    //todo : vers celui qui a le plus de cases
                    /*On empile le voisin jaune qui a le plus de voisins
                     * sur le jaune qui a le plus de voisins réels
                     */
                    // On a pas le droit de faire des déclarations juste après un case (on met un if)
                    if (0 == 1 - 1) {
                        T_Voisins listeVoisinsJaune = getVoisins(caseVictime);
                        octet caseEnfileurDeux = determinerVoisinJauneEntoure(listeVoisinsJaune, currentPosition);
                        T_Voisins listeVoisinsJauneTwo = getVoisins(caseEnfileurDeux);
                        octet caseEnfile = determinerVoisinJauneEntoure(listeVoisinsJauneTwo, currentPosition);

                        int indexCoupAJouer = rechercherIndexCoup(caseEnfileurDeux, caseEnfile, listeCoups);
#ifdef __DEBUG_ENTAME__
                        printf(" Entame - On joue le pion %d sur le pion %d, (index : %d)\n", caseEnfileurDeux,
                               caseEnfile, indexCoupAJouer);
#endif
                        if (indexCoupAJouer != -1) {
                            ecrireIndexCoup(indexCoupAJouer);
                            return;
                        }
                    }
                    break;

                default:
                    printf(" Gros problème sur la fonction qui gère l'entame de la partie\n");
            }
        }
    }

/*****************************FIN ENTAME DE LA PARTIE************************/


    //Si je peux assurer 2 tours à la place d'une seule tour, je fais ca
    for(i=0;i<listeCoups.nb; i++) {//tour de 5
        o = listeCoups.coups[i].origine;
        d = listeCoups.coups[i].destination;
        voisinsDest=getVoisins(d);
        voisinsOrigine=getVoisins(o);
        printf("%d --> %d\n", o, d);

        if (currentPosition.cols[o].couleur == myColor && currentPosition.cols[d].couleur != myColor){ //si l'origine est de ma couleur et la destination de sa couleur
            printf("premierif\n");
            nbDeVoisinsAutresCouleurDest = getReelsVoisinsNbAutreCouleur(voisinsDest,myColor,currentPosition);

            for (int p=0;p<=voisinsDest.nb;p++)
                voisinstab_premierefct[p] = 6;

            for (int p=0;p<=voisinsDest.nb;p++){
                if (currentPosition.cols[voisinsDest.cases[p]].couleur != myColor && currentPosition.cols[voisinsDest.cases[p]].nb>0)
                    voisinstab_premierefct[p] = currentPosition.cols[voisinsDest.cases[p]].nb;
            }

            for (int p=0;p<=voisinsDest.nb;p++)
            {
                if (voisinstab_premierefct[p]!=6){
                    printf("%d La taille du voisin\n", voisinstab_premierefct[p]);
                }
            }

            MinTailleVoisin=DonneLeMin(voisinstab_premierefct, voisinsDest.nb);
            printf("MinTailleVoisin %d\n", MinTailleVoisin);
            if (currentPosition.cols[o].nb + currentPosition.cols[d].nb + MinTailleVoisin > 5) { //si je joue ce coup la et que la tour obtenue sera une tour assurée
                nbDeVoisinsMaCouleurDest = getReelsVoisinsNbMaCouleur(voisinsDest,myColor,currentPosition);
                nbDeVoisinsReelDest = getReelsVoisinsNb(voisinsDest,currentPosition);
                nbDeVoisinsReelOrigine = getReelsVoisinsNb(voisinsOrigine,currentPosition);
                nbDeVoisinsMaCouleurOrigine = getReelsVoisinsNbMaCouleur(voisinsOrigine,myColor,currentPosition);
                nbDeVoisinsAutresCouleurOrigine = getReelsVoisinsNbAutreCouleur(voisinsOrigine,myColor,currentPosition);
                printf("MinTaillevoisin if OK\n");
                for (int p = 0;p<=voisinsOrigine.nb;p++){

                    printf("Couleur du voisin %d et case %d\n",currentPosition.cols[voisinsOrigine.cases[p]].couleur, voisinsOrigine.cases[p]);
                    printf("Taille empilage deux tours de ma couleur + %d\n",currentPosition.cols[voisinsOrigine.cases[p]].nb + currentPosition.cols[o].nb);

                    if (currentPosition.cols[voisinsOrigine.cases[p]].couleur==myColor && (currentPosition.cols[voisinsOrigine.cases[p]].nb + currentPosition.cols[o].nb)<=5); //si je peux empiler deux pions de ma couleur pour avoir une tour de 5
                    {
                        //si ce voisin est une tour assuré, je joue pas la tour de 5 mais privilégie les 2 tours de ma couleur assurée
                        T_Voisins voisinsDuVoisin;
                        voisinsDuVoisin = getVoisins(voisinsOrigine.cases[p]);
                        printf("Avant Dernier if\n");
                        for (int t=0;t<=voisinsDuVoisin.nb;t++)
                            voisinstab2_premierefct[t] = 6;

                        for (int t=0;t<=voisinsDuVoisin.nb;t++){
                            if (currentPosition.cols[voisinsDuVoisin.cases[t]].couleur != myColor && currentPosition.cols[voisinsDuVoisin.cases[t]].nb>0)
                                voisinstab2_premierefct[t] = currentPosition.cols[voisinsDuVoisin.cases[t]].nb;
                        }

                        MinTailleVoisin=DonneLeMin(voisinstab_premierefct, voisinsDuVoisin.nb);
                        printf("MinTailleVoisin %d\n", MinTailleVoisin);
                        printf("MinTailleVoisin + ... + >= 5? %d\n", MinTailleVoisin);
                        printf("%d >=5?n", MinTailleVoisin + currentPosition.cols[o].nb + currentPosition.cols[d].nb);
                        if (MinTailleVoisin + currentPosition.cols[o].nb + currentPosition.cols[d].nb >= 5) {
                            ecrireIndexCoup(i);
                            printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nYYYYYYYYYYYYYYYYYYEEEEEEEEEEEESSSSSSSSSSSSSS\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
                            return;
                        }
                    }
                }
            }
        }
    }

    printf("Je fais pas la premiere fct\n\n\n");
//SI c'est une tour de 5, je prend
    for(i=0;i<listeCoups.nb; i++) {//tour de 5
        o = listeCoups.coups[i].origine;
        d = listeCoups.coups[i].destination;

        // Si je peux gagner une colonne, je la prends (1+4, 2+3 ...)
        if ( 			(currentPosition.cols[o].couleur == myColor)
                        && 	((currentPosition.cols[o].nb+currentPosition.cols[d].nb) == 5)
                ) {
            ecrireIndexCoup(i);
            return; // on quitte la fonction
        }
    }


    //si un pion a nous a un seul voisin, on le prend et on l'éloigne pour assurer une tour

    int origine_ancien_coup = 0;
    for (i = 0; i < listeCoups.nb; i++) {
        o = listeCoups.coups[i].origine;
        d = listeCoups.coups[i].destination;
        T_Voisins mesVoisinsOrigine = getVoisins(o), mesVoisinsDest = getVoisins(d);

        nbDeVoisinsReel=0;

        for (int j=0;j<mesVoisinsDest.nb;j++){
            if (currentPosition.cols[mesVoisinsDest.cases[j]].nb>0){
                nbDeVoisinsReel++;
            }
        }


        if (currentPosition.cols[d].couleur == myColor && nbDeVoisinsReel == 1) {
            printf("Mon pion a un seul voisin, J'essaie de l'isoler\n\n\n\n");
            //je teste l'origine du coup d'avant
            if (origine_ancien_coup == o) {
                printf("C'est bon, j'isole ma tour à la case %d\n\n\n\n", d);
                ecrireIndexCoup(i - 1);
                return;
            }
            printf("Jouer le coup d'avant ne fonctionne pas car la position d'origine est %d est celle d'avant était %d\n\n\n",
                   o, origine_ancien_coup);
            //je Teste l'origine du coup d'après
            if (listeCoups.coups[i + 1].origine) {
                printf("C'est bon, j'isole ma tour à la case %d\n\n\n\n", d);
                ecrireIndexCoup(i + 1);
                return;
            }
            printf("Jouer le coup d'après ne fonctionne pas car la position d'origine est %d est celle d'après était %d\n\n\n",
                   o, listeCoups.coups[i + 1].origine);
        }
        origine_ancien_coup = o;
    }





    //si je peux avoir une tour isolée ou une tour imprenable par l'adversaire
    for(i=0;i<listeCoups.nb; i++) {
        o = listeCoups.coups[i].origine;
        d = listeCoups.coups[i].destination;
        T_Voisins mesVoisins = getVoisins(d);
        int nbDeVoisinsAdverse;
        int MinTailleAdverse;

        int tabVoisins[8]; //Le tableau des voisins réels
        tabVoisins[0]=6;
        tabVoisins[1]=6;
        tabVoisins[2]=6;
        tabVoisins[3]=6;
        tabVoisins[4]=6;
        tabVoisins[5]=6;

        nbDeVoisinsReel=0;

        for (int j=0;j<mesVoisins.nb;j++){
            if (currentPosition.cols[mesVoisins.cases[j]].nb>0){
                nbDeVoisinsReel++;
            }
        }

        if (currentPosition.cols[o].couleur==myColor) {//si le pion que je m'apprete à mettre au dessus d'une tour est de ma couleur, sinon aucun intérêt
            switch (nbDeVoisinsReel) {
                case 1 :
                    ecrireIndexCoup(i);
                    //printf("Je prend la tour car je suis son seul voisin, je suis donc assuré de la garder");
                    return; //tour imprenable car son seul voisin c'est nous
                case 2 :
                    if (currentPosition.cols[mesVoisins.cases[0]].couleur != myColor)
                    {
                        tabVoisins[0] = currentPosition.cols[mesVoisins.cases[0]].nb;
                    }
                    if (currentPosition.cols[mesVoisins.cases[1]].couleur != myColor)
                    {
                        tabVoisins[1] = currentPosition.cols[mesVoisins.cases[1]].nb;
                    }
                    MinTailleAdverse = DonneLeMin(tabVoisins, 2);
                    //printf("Mintailleadverse : %d et Somme tour avec le min: %d\n", MinTailleAdverse,currentPosition.cols[o].nb + currentPosition.cols[d].nb + MinTailleAdverse);
                    if (MinTailleAdverse == 6 ||
                        ((currentPosition.cols[o].nb + currentPosition.cols[d].nb + MinTailleAdverse) >=
                         5))//si égal à 0 c'est que les voisins sont de ma couleur OU que ma taille + la taille de la destination + la plus petite tour adverse supérieure ou égal à 5 (cela vet dire que si je joue ce coup, ses tours voisines sont trop grandes pour prendre ma tour)
                    {

                        printf("Tour assuré 2 voisins!! je joue\n\n");
                        printf("La couleur du pion d'origine est %d\n",currentPosition.cols[o].couleur);
                        printf("Je joue car :\nLe premier voisin a une taille de %d et est %d\nle deuxieme %d et est %d\nLe min est donc %d\n", tabVoisins[0],currentPosition.cols[mesVoisins.cases[0]].couleur,tabVoisins[1],currentPosition.cols[mesVoisins.cases[1]].couleur,MinTailleAdverse);
                        ecrireIndexCoup(i);
                        return;
                    }
                    break;
                case 3:
                    if (currentPosition.cols[mesVoisins.cases[0]].couleur != myColor) {
                        tabVoisins[0] = currentPosition.cols[mesVoisins.cases[0]].nb;
                    }
                    if (currentPosition.cols[mesVoisins.cases[1]].couleur != myColor) {
                        tabVoisins[1] = currentPosition.cols[mesVoisins.cases[1]].nb;
                    }
                    if (currentPosition.cols[mesVoisins.cases[2]].couleur != myColor) {
                        tabVoisins[2] = currentPosition.cols[mesVoisins.cases[2]].nb;
                    }
                    MinTailleAdverse = DonneLeMin(tabVoisins, 3);


                    if (MinTailleAdverse == 6 ||
                        ((currentPosition.cols[o].nb + currentPosition.cols[d].nb + MinTailleAdverse) >=
                         5))//si égal à 0 c'est que les voisins sont de ma couleur OU que ma taille + la taille de la destination + la plus petite tour adverse supérieure ou égal à 5 (cela vet dire que si je joue ce coup, ses tours voisines sont trop grandes pour prendre ma tour)
                    {
                        printf("Tour assuré 3 voisins!! je joue\n\n");
                        printf("La couleur du pion d'origine est %d\n",currentPosition.cols[o].couleur);
                        printf("Je joue car :\nLe premier voisin a une taille de %d et est %d\nle deuxieme %d et est %d\n et le troisieme %d et est %d\nLe min est donc %d\n", tabVoisins[0],currentPosition.cols[mesVoisins.cases[0]].couleur,tabVoisins[1],currentPosition.cols[mesVoisins.cases[1]].couleur,tabVoisins[2],currentPosition.cols[mesVoisins.cases[2]].couleur,MinTailleAdverse);
                        ecrireIndexCoup(i);
                        return;
                    }
                    break;
                case 4:
                    if (currentPosition.cols[mesVoisins.cases[0]].couleur != myColor)
                        tabVoisins[0] = currentPosition.cols[mesVoisins.cases[0]].nb;
                    if (currentPosition.cols[mesVoisins.cases[1]].couleur != myColor)
                        tabVoisins[1] = currentPosition.cols[mesVoisins.cases[1]].nb;
                    if (currentPosition.cols[mesVoisins.cases[2]].couleur != myColor)
                        tabVoisins[2] = currentPosition.cols[mesVoisins.cases[2]].nb;
                    if (currentPosition.cols[mesVoisins.cases[3]].couleur != myColor)
                        tabVoisins[3] = currentPosition.cols[mesVoisins.cases[3]].nb;
                    MinTailleAdverse = DonneLeMin(tabVoisins, 4);


                    if (MinTailleAdverse == 6 ||
                        ((currentPosition.cols[o].nb + currentPosition.cols[d].nb + MinTailleAdverse) >=
                         5))//si égal à 0 c'est que les voisins sont de ma couleur OU que ma taille + la taille de la destination + la plus petite tour adverse supérieure ou égal à 5 (cela vet dire que si je joue ce coup, ses tours voisines sont trop grandes pour prendre ma tour)
                    {
                        printf("Tour assuré 4 voisins!! je joue\n\n");
                        printf("La couleur du pion d'origine est %d\n",currentPosition.cols[o].couleur);
                        printf("Je joue car :\nLe premier voisin a une taille de %d et est %d\nle deuxieme %d et est %d\n et le troisieme %d et est %d\nLe quatrieme %d et est %d\nLe min est donc %d\n", tabVoisins[0],currentPosition.cols[mesVoisins.cases[0]].couleur,tabVoisins[1],currentPosition.cols[mesVoisins.cases[1]].couleur,tabVoisins[2],currentPosition.cols[mesVoisins.cases[2]].couleur,tabVoisins[3],currentPosition.cols[mesVoisins.cases[3]].couleur,MinTailleAdverse);
                        ecrireIndexCoup(i);
                        return;
                    }
                    break;
                case 5:
                    //todo:prendre la tour et la mettre sur un pion adverse si on peux
                    if (currentPosition.cols[mesVoisins.cases[0]].couleur != myColor)
                        tabVoisins[0] = currentPosition.cols[mesVoisins.cases[0]].nb;
                    if (currentPosition.cols[mesVoisins.cases[1]].couleur != myColor)
                        tabVoisins[1] = currentPosition.cols[mesVoisins.cases[1]].nb;
                    if (currentPosition.cols[mesVoisins.cases[2]].couleur != myColor)
                        tabVoisins[2] = currentPosition.cols[mesVoisins.cases[2]].nb;
                    if (currentPosition.cols[mesVoisins.cases[3]].couleur != myColor)
                        tabVoisins[3] = currentPosition.cols[mesVoisins.cases[3]].nb;
                    if (currentPosition.cols[mesVoisins.cases[4]].couleur != myColor)
                        tabVoisins[4] = currentPosition.cols[mesVoisins.cases[4]].nb;
                    MinTailleAdverse = DonneLeMin(tabVoisins, 5);
                    //printf("Mintailleadverse : %d et Somme tour avec le min: %d\n", MinTailleAdverse,currentPosition.cols[o].nb + currentPosition.cols[d].nb + MinTailleAdverse);

                    if (MinTailleAdverse == 6 ||
                        ((currentPosition.cols[o].nb + currentPosition.cols[d].nb + MinTailleAdverse) >=
                         5))//si égal à 0 c'est que les voisins sont de ma couleur OU que ma taille + la taille de la destination + la plus petite tour adverse supérieure ou égal à 5 (cela vet dire que si je joue ce coup, ses tours voisines sont trop grandes pour prendre ma tour)
                    {
                        printf("Tour assuré 5 voisins!! je joue\n\n");
                        printf("La couleur du pion d'origine est %d\n",currentPosition.cols[o].couleur);
                        printf("Je joue car :\nLe premier voisin a une taille de %d et est %d\nle deuxieme %d et est %d\n et le troisieme %d et est %d\nLe quatrieme %d et est %d\nLe ciquieme a une taille de %d et est %d\nLe min est donc %d\n", tabVoisins[0],currentPosition.cols[mesVoisins.cases[0]].couleur,tabVoisins[1],currentPosition.cols[mesVoisins.cases[1]].couleur,tabVoisins[2],currentPosition.cols[mesVoisins.cases[2]].couleur,tabVoisins[3],currentPosition.cols[mesVoisins.cases[3]].couleur,tabVoisins[4],currentPosition.cols[mesVoisins.cases[4]].couleur,MinTailleAdverse);
                        ecrireIndexCoup(i);
                        return;
                    }
                    break;
            }
        }
    }



    //Si une tour potentielle de trois avec au moins 2 voisins
    for (i=0;i<listeCoups.nb;i++){


        o = listeCoups.coups[i].origine;
        d = listeCoups.coups[i].destination;
        T_Voisins mesVoisins = getVoisins(d);

        nbDeVoisinsReel=0; //correspondra aux voisins de ma couleur

        for (int j=0;j<mesVoisins.nb;j++){

            if (currentPosition.cols[mesVoisins.cases[j]].nb>0 && currentPosition.cols[mesVoisins.cases[j]].couleur==myColor){
                nbDeVoisinsReel++;
            }
        }

        if (nbDeVoisinsReel>2){
            ecrireIndexCoup(i);
        }
    }



    //J'empeche l'isolation de mon adversaire en ramenant son pion isolé vers les miens
    /*for (i=0;i<listeCoups.nb;i++){

        o = listeCoups.coups[i].origine;
        d = listeCoups.coups[i].destination;
        int nbDeVoisinAutreCouleur;
        int jouePas;
        T_Voisins mesVoisinsOrigine = getVoisins(o), mesVoisinsDest = getVoisins(d);

        FILE *file;

        file=fopen("Mescommentaires.txt","w");

        for (int p=0;p<=mesVoisinsOrigine.nb;p++){

            if (currentPosition.cols[mesVoisinsOrigine.cases[p]].nb>0 && currentPosition.cols[mesVoisinsOrigine.cases[p]].couleur!=myColor) //si le voisin est de sa couleur
            {
                printf("\n\n\n\n\n\nPremier If %d", o);
                for (int k=0;k<=mesVoisinsDest.nb;k++){
                    if ((currentPosition.cols[mesVoisinsDest.cases[k]].nb + currentPosition.cols[mesVoisinsDest.cases[k]].nb + currentPosition.cols[o].nb+currentPosition.cols[d].nb)==5){

                        fprintf(file,"JE JOUE CA\n\n\n\n\n\n");
                        ecrireIndexCoup(i);
                        return;
                    }
                }
            }
        }
        fclose(file);
    }*/



    for(i=0;i<listeCoups.nb; i++) {
        o = listeCoups.coups[i].origine;
        d = listeCoups.coups[i].destination;

        if ( (currentPosition.cols[o].couleur != myColor)
             && (currentPosition.cols[d].couleur != myColor)
             && ((currentPosition.cols[o].nb+currentPosition.cols[d].nb) < 3)
                ) {
            ecrireIndexCoup(i);
            printf("J'empile deux pions\n");
            return; // on quitte la fonction
        }
    }


    /******************************MINIMAX*****************************/
    int indexCoup;
    if( listeCoups.nb <= COUPS_MINIMAX ) {
        // Entre 70 et 100
        if (listeCoups.nb >= 60) {
#ifdef __DEBUG_MINIMAX__
            printf(" Minimax - nombre de coups entre 70 et 100 : profondeur de 3\n");
#endif
            indexCoup = algoMinimax(currentPosition, myColor, 0, 3).indiceCoup;
            o = listeCoups.coups[indexCoup].origine;
            d = listeCoups.coups[indexCoup].destination;
            if ( (currentPosition.cols[o].couleur != myColor)
                 && ((currentPosition.cols[o].nb+currentPosition.cols[d].nb) != 5) ) {
                ecrireIndexCoup(indexCoup);
                return; // on quitte la fonction
            }
        }
            // Entre 40 et 70
        else if(listeCoups.nb >=40) {
#ifdef __DEBUG_MINIMAX__
            printf(" Minimax - nombre de coups entre 40 et 70 : profondeur de 4\n");
#endif
            indexCoup = algoMinimax(currentPosition, myColor, 0, 4).indiceCoup;
            o = listeCoups.coups[indexCoup].origine;
            d = listeCoups.coups[indexCoup].destination;
            if ( (currentPosition.cols[o].couleur != myColor)
                 && ((currentPosition.cols[o].nb+currentPosition.cols[d].nb) != 5) ) {
                ecrireIndexCoup(indexCoup);
                return; // on quitte la fonction
            }
        }
            // Moins de 40
        else {
#ifdef __DEBUG_MINIMAX__
            printf(" Minimax - nombre de coups inférieur à 40 : profondeur de 6\n");
#endif
            indexCoup = algoMinimax(currentPosition, myColor, 0, 6).indiceCoup;
            o = listeCoups.coups[indexCoup].origine;
            d = listeCoups.coups[indexCoup].destination;
            if ( (currentPosition.cols[o].couleur != myColor)
                 && ((currentPosition.cols[o].nb+currentPosition.cols[d].nb) != 5) ) {
                ecrireIndexCoup(indexCoup);
                return; // on quitte la fonction
            }
        }
    }


    /****************************FIN MINIMAX****************************/


    // Sinon, je tire au sort

    while (1) {
        a = rand()%listeCoups.nb;
        o = listeCoups.coups[a].origine;
        d = listeCoups.coups[a].destination;

        if ( (currentPosition.cols[o].couleur != myColor)
             && ((currentPosition.cols[o].nb+currentPosition.cols[d].nb) != 5) ) {
            printf("On choisit au hasard ! \n");
            ecrireIndexCoup(a);
            return; // on quitte la fonction
        }
    }

}

int DonneLeMin(int tabVoisin[], int taille){
    int min=6;
    for (int i=0;i<taille;i++){
        if (tabVoisin[i]<min)
            min=tabVoisin[i];
    }
    return min;
}

octet getReelsVoisinsNbMaCouleur(T_Voisins mesVoisins,octet myColor,T_Position currentPosition) {
    octet nbDeVoisinsReel = 0; //correspondra aux voisins de ma couleur

    for (int j = 0; j < mesVoisins.nb; j++) {

        if (currentPosition.cols[mesVoisins.cases[j]].nb > 0 &&
            currentPosition.cols[mesVoisins.cases[j]].couleur == myColor) {
            nbDeVoisinsReel++;
        }
    }
    return nbDeVoisinsReel;
}

octet getReelsVoisinsNbAutreCouleur(T_Voisins mesVoisins,octet myColor,T_Position currentPosition){
    octet nbDeVoisinsReel=0; //correspondra aux voisins de ma couleur

    for (int j=0;j<mesVoisins.nb;j++){

        if (currentPosition.cols[mesVoisins.cases[j]].nb>0 && currentPosition.cols[mesVoisins.cases[j]].couleur!=myColor){
            nbDeVoisinsReel++;
        }
    }
    return nbDeVoisinsReel;
}

octet getReelsVoisinsNb(T_Voisins mesVoisins,T_Position currentPosition){
    octet nbDeVoisinsReel=0; //correspondra aux voisins de ma couleur

    for (int j=0;j<mesVoisins.nb;j++){
        printf(" getReelsVoisinsNb - On étudie mesVoisins.cases[j] = %d && currentPosition.cols[mesVoisins.cases[j]].nb = %d\n",mesVoisins.cases[j],currentPosition.cols[mesVoisins.cases[j]].nb);
        if (currentPosition.cols[mesVoisins.cases[j]].nb!=0){
            nbDeVoisinsReel++;
        }
    }
    return nbDeVoisinsReel;
}


//renvoie 1 s'il n'y a eu que n coups dans le plateau
short plateauNiemeCoup(T_Position currentPosition,short nieme){
    // Il y a eu que 2 coups ssi 2 cases vides
    octet casesVides=0,caseConcerne=0;
    while( caseConcerne < 48 ) {
        if( currentPosition.cols[caseConcerne].couleur == VIDE) {
            casesVides++;
        }
        caseConcerne++;
    }
    return ( casesVides == nieme);
}

octet presenceTourTrois(T_Position currentPosition) {
// renvoie la position de la seul tour de trois s'il y en a une, sinon renvoie -1
    octet caseTourTrois=48,caseConcerne=0;
    while( caseConcerne < 48 && caseTourTrois == 48) {
        if( currentPosition.cols[caseConcerne].nb == 3 ) {
            caseTourTrois=caseConcerne;
        }
        caseConcerne++;
    }
    return caseTourTrois;
}

int rechercherIndexCoup(octet origine, octet destination,T_ListeCoups listeCoups) {
    //On commence à l'index maximum
    int indexConcerne=listeCoups.nb-1, trouve=0;
    while( indexConcerne != -1 && trouve != 1 ) {
        if( listeCoups.coups[indexConcerne].origine == origine && listeCoups.coups[indexConcerne].destination == destination ) {
            trouve++;
        }
        else {
            indexConcerne--;
        }
    }
    return indexConcerne;
}

octet rechercherTourDeux(T_Position currentPosition, octet *caseTourDeux) {
//renvoie la couleur de la case contenant la tour de deux
    *caseTourDeux=48;
    octet caseConcerne=0;
    while( caseConcerne < 48 && *caseTourDeux == 48) {
        if (currentPosition.cols[caseConcerne].nb == 2) {
            *caseTourDeux = caseConcerne;
        }
        else {
            caseConcerne++;
        }
    }
    // Si on a trouvé la tour de 2
    if( *caseTourDeux != 48) {
        return currentPosition.cols[*caseTourDeux].couleur;
    }
    else {
        return VIDE;
    }

}

octet determinerVoisinIsole(T_Voisins listeVoisins, octet couleurCaseConcerne,T_Position currentPosition) {
// renvoie la position de la case couleurCase ayant le moins de voisins d'autre couleur parmi une liste de position
    octet minVoisins=9,caseIsole=0;
    for(octet caseConcerne=0; caseConcerne<listeVoisins.nb;caseConcerne++) {
        // Exemple : RED, pour chaque voisin rouge
        if( currentPosition.cols[listeVoisins.cases[caseConcerne]].couleur == couleurCaseConcerne ) {
            T_Voisins listeVoisinsCaseConcerne = getVoisins(caseConcerne);
            octet nombreVoisinsAdverses = getReelsVoisinsNbAutreCouleur(listeVoisinsCaseConcerne,couleurCaseConcerne,currentPosition);
            if( nombreVoisinsAdverses < minVoisins) {
                minVoisins = nombreVoisinsAdverses;
                caseIsole=listeVoisins.cases[caseConcerne];
            }
        }
    }
    return caseIsole;
}

octet determinerVoisinJauneEntoure(T_Voisins listeVoisinsJaune, T_Position currentPosition) {
    // renvoie la position de la case jaune ayant le plus de voisins réels parmi la liste des positions
    octet maxVoisins=0,caseEntoure=0;
    for(octet caseConcerne=0; caseConcerne<listeVoisinsJaune.nb;caseConcerne++) {
        if( currentPosition.cols[listeVoisinsJaune.cases[caseConcerne]].couleur == JAU ) {
#ifdef __DEBUG_ENTAME__
            printf(" determinerVoisinJauneEntoure - Voisin étudié : %d\n",listeVoisinsJaune.cases[caseConcerne]);
#endif
            T_Voisins listeVoisinsCaseConcerne = getVoisins(caseConcerne);
            octet nombreVoisinsAdverses = getReelsVoisinsNb(listeVoisinsCaseConcerne,currentPosition);
            if( nombreVoisinsAdverses > maxVoisins) {
                maxVoisins = nombreVoisinsAdverses;
                caseEntoure=listeVoisinsJaune.cases[caseConcerne];
            }
        }
    }
#ifdef __DEBUG_ENTAME__
    printf(" determinerVoisinJauneEntoure - La case jaune la plus entourée est la %d\n",caseEntoure);
#endif
    return caseEntoure;
}

short voisinageVierge(octet position,T_Position currentPosition) {
    octet vierge=1,iteration=0;
    T_Voisins listeVoisins=getVoisins(position);
    while( iteration != listeVoisins.nb && vierge ) {
        // S'il y a une tour de 2
        if( currentPosition.cols[listeVoisins.cases[iteration]].nb>1) {
            vierge=0;
        }
        iteration++;
    }

    return vierge;
}

int evaluation(T_Position currentPosition, octet myColor) {

    int SCORE = 0;


    //Je traite pour ma couleur et j'ajoute les points

    for (int i = 0; i <= 48; i++) {//car il y a 48 cases
        T_Voisins mesVoisins = getVoisins(i);
        int nbDeVoisinsAdverse;
        int MinTailleAdverse;
        int taille = 0;
        int tabVoisins[8];
        tabVoisins[0] = 6;
        tabVoisins[1] = 6;
        tabVoisins[2] = 6;
        tabVoisins[3] = 6;
        tabVoisins[4] = 6;
        tabVoisins[5] = 6;


        if (currentPosition.cols[i].couleur ==
            myColor) {//si la tour actuelle est de ma couleur, je rentre dans la fonction qui ajoute les points
            if (currentPosition.cols[i].nb == 5) {
                SCORE += SCORE_tour_certaine_5;
            }


            switch (mesVoisins.nb) {
                case 0:
                    //tour sans voisins mais pas tour de 5
                    SCORE += SCORE_tour_certaine_inferieur5;
                    printf("j'ajoute %d points car tour certaine sans voisin à la case\n",
                           SCORE_tour_certaine_inferieur5);
                    break;
                case 1 :
                    taille = 1;
                    if (currentPosition.cols[mesVoisins.cases[0]].couleur == myColor) {
                        if (currentPosition.cols[i].nb == 4) {
                            SCORE += SCORE_tour_voisin_notre_couleur_4;
                            printf("j'ajoute %d points car tour certaine avec un unique voisin à la case\n",
                                   SCORE_tour_voisin_notre_couleur_4);
                        } else {
                            SCORE += SCORE_tour_certaine_inferieur5;
                            printf("j'ajoute %d points car tour certaine avec un unique voisin à la case\n",
                                   SCORE_tour_certaine_inferieur5);
                        }
                    }
                    break; //tour pas imprenable mais presque car son seul voisin c'est nous
                case 2 :
                    if (currentPosition.cols[mesVoisins.cases[0]].couleur != myColor &&
                        currentPosition.cols[mesVoisins.cases[0]].nb > 0) {
                        tabVoisins[0] = currentPosition.cols[mesVoisins.cases[0]].nb;
                    }
                    if (currentPosition.cols[mesVoisins.cases[1]].couleur != myColor &&
                        currentPosition.cols[mesVoisins.cases[1]].nb > 0) {
                        tabVoisins[1] = currentPosition.cols[mesVoisins.cases[1]].nb;
                    }
                    MinTailleAdverse = DonneLeMin(tabVoisins, 2);
                    taille = 2;
                    //printf("Mintailleadverse : %d et Somme tour avec le min: %d\n", MinTailleAdverse,currentPosition.cols[o].nb + currentPosition.cols[d].nb + MinTailleAdverse);
                    if (MinTailleAdverse == 6 ||
                        ((currentPosition.cols[i].nb + MinTailleAdverse) >=
                         5))//si égal à 0 c'est que les voisins sont de ma couleur OU que ma taille + la taille de la destination + la plus petite tour adverse supérieure ou égal à 5 (cela vet dire que si je joue ce coup, ses tours voisines sont trop grandes pour prendre ma tour)
                    {
                        //La position est Bonne!
                        if (currentPosition.cols[i].nb == 4) {
                            SCORE += SCORE_tour_voisin_notre_couleur_4;
                            printf("j'ajoute %d points car tour certaine avec 2 voisins à la case\n",
                                   SCORE_tour_voisin_notre_couleur_4);
                        } else {
                            SCORE += SCORE_tour_voisin_notre_couleur_inferieur4;
                            printf("j'ajoute %d points car tour certaine avec 2 voisins à la case\n",
                                   SCORE_tour_voisin_notre_couleur_inferieur4);
                        }
                    }
                    break;
                case 3:
                    if (currentPosition.cols[mesVoisins.cases[0]].couleur != myColor &&
                        currentPosition.cols[mesVoisins.cases[0]].nb > 0) {
                        tabVoisins[0] = currentPosition.cols[mesVoisins.cases[0]].nb;
                    }
                    if (currentPosition.cols[mesVoisins.cases[1]].couleur != myColor &&
                        currentPosition.cols[mesVoisins.cases[1]].nb > 0) {
                        tabVoisins[1] = currentPosition.cols[mesVoisins.cases[1]].nb;
                    }
                    if (currentPosition.cols[mesVoisins.cases[2]].couleur != myColor &&
                        currentPosition.cols[mesVoisins.cases[2]].nb > 0) {
                        tabVoisins[2] = currentPosition.cols[mesVoisins.cases[2]].nb;
                    }
                    MinTailleAdverse = DonneLeMin(tabVoisins, 3);
                    taille = 3;
                    //printf("Mintailleadverse : %d et Somme tour avec le min: %d\n", MinTailleAdverse,currentPosition.cols[o].nb + currentPosition.cols[d].nb + MinTailleAdverse);

                    if (MinTailleAdverse == 6 ||
                        ((currentPosition.cols[i].nb + MinTailleAdverse) >=
                         5))//si égal à 0 c'est que les voisins sont de ma couleur OU que ma taille + la taille de la destination + la plus petite tour adverse supérieure ou égal à 5 (cela vet dire que si je joue ce coup, ses tours voisines sont trop grandes pour prendre ma tour)
                    {
                        //La position est Bonne!
                        if (currentPosition.cols[i].nb == 4) {
                            SCORE += SCORE_tour_voisin_notre_couleur_4;
                            printf("j'ajoute %d points car tour certaine avec 3 voisins à la case\n",
                                   SCORE_tour_voisin_notre_couleur_4);
                        } else {
                            SCORE += SCORE_tour_voisin_notre_couleur_inferieur4;
                            printf("j'ajoute %d points car tour certaine avec3 voisins à la case\n",
                                   SCORE_tour_voisin_notre_couleur_inferieur4);
                        }
                    }
                    break;
                case 4:
                    if (currentPosition.cols[mesVoisins.cases[0]].couleur != myColor &&
                        currentPosition.cols[mesVoisins.cases[0]].nb > 0)
                        tabVoisins[0] = currentPosition.cols[mesVoisins.cases[0]].nb;
                    if (currentPosition.cols[mesVoisins.cases[1]].couleur != myColor &&
                        currentPosition.cols[mesVoisins.cases[1]].nb > 0)
                        tabVoisins[1] = currentPosition.cols[mesVoisins.cases[1]].nb;
                    if (currentPosition.cols[mesVoisins.cases[2]].couleur != myColor &&
                        currentPosition.cols[mesVoisins.cases[2]].nb > 0)
                        tabVoisins[2] = currentPosition.cols[mesVoisins.cases[2]].nb;
                    if (currentPosition.cols[mesVoisins.cases[3]].couleur != myColor &&
                        currentPosition.cols[mesVoisins.cases[3]].nb > 0)
                        tabVoisins[3] = currentPosition.cols[mesVoisins.cases[3]].nb;
                    MinTailleAdverse = DonneLeMin(tabVoisins, 4);
                    taille = 4;
                    //printf("Mintailleadverse : %d et Somme tour avec le min: %d\n", MinTailleAdverse,currentPosition.cols[o].nb + currentPosition.cols[d].nb + MinTailleAdverse);

                    if (MinTailleAdverse == 6 ||
                        ((currentPosition.cols[i].nb + MinTailleAdverse) >=
                         5))//si égal à 0 c'est que les voisins sont de ma couleur OU que ma taille + la taille de la destination + la plus petite tour adverse supérieure ou égal à 5 (cela vet dire que si je joue ce coup, ses tours voisines sont trop grandes pour prendre ma tour)
                    {
                        //La position est Bonne!
                        if (currentPosition.cols[i].nb == 4) {
                            SCORE += SCORE_tour_voisin_notre_couleur_4;
                            printf("j'ajoute %d points car tour certaine avec 4 voisins à la case\n",
                                   SCORE_tour_voisin_notre_couleur_4);
                        } else {
                            SCORE += SCORE_tour_voisin_notre_couleur_inferieur4;
                            printf("j'ajoute %d points car tour certaine inférieuse à 4 voisins à la case\n",
                                   SCORE_tour_voisin_notre_couleur_inferieur4);
                        }
                    }
                    break;
                case 5:
                    //todo:prendre la tour et la mettre sur un pion adverse si on peux
                    if (currentPosition.cols[mesVoisins.cases[0]].couleur != myColor &&
                        currentPosition.cols[mesVoisins.cases[0]].nb > 0)
                        tabVoisins[0] = currentPosition.cols[mesVoisins.cases[0]].nb;
                    if (currentPosition.cols[mesVoisins.cases[1]].couleur != myColor &&
                        currentPosition.cols[mesVoisins.cases[1]].nb > 0)
                        tabVoisins[1] = currentPosition.cols[mesVoisins.cases[1]].nb;
                    if (currentPosition.cols[mesVoisins.cases[2]].couleur != myColor &&
                        currentPosition.cols[mesVoisins.cases[2]].nb > 0)
                        tabVoisins[2] = currentPosition.cols[mesVoisins.cases[2]].nb;
                    if (currentPosition.cols[mesVoisins.cases[3]].couleur != myColor &&
                        currentPosition.cols[mesVoisins.cases[3]].nb > 0)
                        tabVoisins[3] = currentPosition.cols[mesVoisins.cases[3]].nb;
                    if (currentPosition.cols[mesVoisins.cases[4]].couleur != myColor &&
                        currentPosition.cols[mesVoisins.cases[4]].nb > 0)
                        tabVoisins[4] = currentPosition.cols[mesVoisins.cases[4]].nb;
                    taille = 5;
                    MinTailleAdverse = DonneLeMin(tabVoisins, 5);
                    //printf("Mintailleadverse : %d et Somme tour avec le min: %d\n", MinTailleAdverse,currentPosition.cols[o].nb + currentPosition.cols[d].nb + MinTailleAdverse);

                    if (MinTailleAdverse == 6 ||
                        ((currentPosition.cols[i].nb + MinTailleAdverse) >=
                         5))//si égal à 0 c'est que les voisins sont de ma couleur OU que ma taille + la taille de la destination + la plus petite tour adverse supérieure ou égal à 5 (cela vet dire que si je joue ce coup, ses tours voisines sont trop grandes pour prendre ma tour)
                    {
                        //La position est Bonne!
                        if (currentPosition.cols[i].nb == 4) {
                            SCORE += SCORE_tour_voisin_notre_couleur_4;
                            printf("j'ajoute %d points car tour certaine avec 5 voisins à la case\n",
                                   SCORE_tour_voisin_notre_couleur_4);
                        } else {
                            SCORE += SCORE_tour_voisin_notre_couleur_inferieur4;
                            printf("j'ajoute %d points car tour certaine avec 5 voisins à la case\n",
                                   SCORE_tour_voisin_notre_couleur_inferieur4);
                        }
                    }
                    break;
            }


	if (currentPosition.cols[i].nb==3){
	T_Voisins voisins = getVoisins(i);
	int pionMaCouleur=0;
for (int p=0;p<=voisins.nb;p++){
if (currentPosition.cols[voisins.cases[i]].couleur==myColor)
pionMaCouleur++;

if (pionMaCouleur>1){
SCORE+=50;
}
}
	
	}

            /*if (currentPosition.cols[i].nb==3){
                //On regarde les voisins (sachant que le nb de voisins est donné dans le case du dessus)todo:si sup à 5..

            }*/
        }

        if (myColor == 1)myColor = 2; else myColor = 1;

        if (currentPosition.cols[i].couleur ==
            myColor) {//si la tour actuelle est de ma couleur, je rentre dans la fonction qui ajoute les points
            if (currentPosition.cols[i].nb == 5) {
                SCORE -= SCORE_tour_certaine_5;
            }
            switch (mesVoisins.nb) {

                case 0:
                    //tour sans voisins mais pas tour de 5
                    SCORE -= SCORE_tour_certaine_inferieur5;
                    printf("j'ajoute %d points car tour certaine sans voisin à la case\n",
                           SCORE_tour_certaine_inferieur5);
                    break;
                case 1 :
                    taille = 1;
                    if (currentPosition.cols[mesVoisins.cases[0]].couleur == myColor) {
                        if (currentPosition.cols[i].nb == 4) {
                            SCORE -= SCORE_tour_voisin_notre_couleur_4;
                            printf("j'ajoute %d points car tour certaine avec un unique voisin à la case\n",
                                   SCORE_tour_voisin_notre_couleur_4);
                        } else {
                            SCORE -= SCORE_tour_certaine_inferieur5;
                            printf("j'ajoute %d points car tour certaine avec un unique voisin à la case\n",
                                   SCORE_tour_certaine_inferieur5);
                        }
                    }
                    break; //tour pas imprenable mais presque car son seul voisin c'est nous
                case 2 :
                    if (currentPosition.cols[mesVoisins.cases[0]].couleur != myColor &&
                        currentPosition.cols[mesVoisins.cases[0]].nb > 0) {
                        tabVoisins[0] = currentPosition.cols[mesVoisins.cases[0]].nb;
                    }
                    if (currentPosition.cols[mesVoisins.cases[1]].couleur != myColor &&
                        currentPosition.cols[mesVoisins.cases[1]].nb > 0) {
                        tabVoisins[1] = currentPosition.cols[mesVoisins.cases[1]].nb;
                    }
                    MinTailleAdverse = DonneLeMin(tabVoisins, 2);
                    taille = 2;
                    //printf("Mintailleadverse : %d et Somme tour avec le min: %d\n", MinTailleAdverse,currentPosition.cols[o].nb + currentPosition.cols[d].nb + MinTailleAdverse);
                    if (MinTailleAdverse == 6 ||
                        ((currentPosition.cols[i].nb + MinTailleAdverse) >=
                         5))//si égal à 0 c'est que les voisins sont de ma couleur OU que ma taille + la taille de la destination + la plus petite tour adverse supérieure ou égal à 5 (cela vet dire que si je joue ce coup, ses tours voisines sont trop grandes pour prendre ma tour)
                    {
                        //La position est Bonne!
                        if (currentPosition.cols[i].nb == 4) {
                            SCORE -= SCORE_tour_voisin_notre_couleur_4;
                            printf("j'ajoute %d points car tour certaine avec 2 voisins à la case\n",
                                   SCORE_tour_voisin_notre_couleur_4);
                        } else {
                            SCORE -= SCORE_tour_voisin_notre_couleur_inferieur4;
                            printf("j'ajoute %d points car tour certaine avec 2 voisins à la case\n",
                                   SCORE_tour_voisin_notre_couleur_inferieur4);
                        }
                    }
                    break;
                case 3:
                    if (currentPosition.cols[mesVoisins.cases[0]].couleur != myColor &&
                        currentPosition.cols[mesVoisins.cases[0]].nb > 0) {
                        tabVoisins[0] = currentPosition.cols[mesVoisins.cases[0]].nb;
                    }
                    if (currentPosition.cols[mesVoisins.cases[1]].couleur != myColor &&
                        currentPosition.cols[mesVoisins.cases[1]].nb > 0) {
                        tabVoisins[1] = currentPosition.cols[mesVoisins.cases[1]].nb;
                    }
                    if (currentPosition.cols[mesVoisins.cases[2]].couleur != myColor &&
                        currentPosition.cols[mesVoisins.cases[2]].nb > 0) {
                        tabVoisins[2] = currentPosition.cols[mesVoisins.cases[2]].nb;
                    }
                    MinTailleAdverse = DonneLeMin(tabVoisins, 3);
                    taille = 3;
                    //printf("Mintailleadverse : %d et Somme tour avec le min: %d\n", MinTailleAdverse,currentPosition.cols[o].nb + currentPosition.cols[d].nb + MinTailleAdverse);

                    if (MinTailleAdverse == 6 ||
                        ((currentPosition.cols[i].nb + MinTailleAdverse) >=
                         5))//si égal à 0 c'est que les voisins sont de ma couleur OU que ma taille + la taille de la destination + la plus petite tour adverse supérieure ou égal à 5 (cela vet dire que si je joue ce coup, ses tours voisines sont trop grandes pour prendre ma tour)
                    {
                        //La position est Bonne!
                        if (currentPosition.cols[i].nb == 4) {
                            SCORE -= SCORE_tour_voisin_notre_couleur_4;
                            printf("j'ajoute %d points car tour certaine avec 3 voisins à la case\n",
                                   SCORE_tour_voisin_notre_couleur_4);
                        } else {
                            SCORE -= SCORE_tour_voisin_notre_couleur_inferieur4;
                            printf("j'ajoute %d points car tour certaine avec3 voisins à la case\n",
                                   SCORE_tour_voisin_notre_couleur_inferieur4);
                        }
                    }
                    break;
                case 4:
                    if (currentPosition.cols[mesVoisins.cases[0]].couleur != myColor &&
                        currentPosition.cols[mesVoisins.cases[0]].nb > 0)
                        tabVoisins[0] = currentPosition.cols[mesVoisins.cases[0]].nb;
                    if (currentPosition.cols[mesVoisins.cases[1]].couleur != myColor &&
                        currentPosition.cols[mesVoisins.cases[1]].nb > 0)
                        tabVoisins[1] = currentPosition.cols[mesVoisins.cases[1]].nb;
                    if (currentPosition.cols[mesVoisins.cases[2]].couleur != myColor &&
                        currentPosition.cols[mesVoisins.cases[2]].nb > 0)
                        tabVoisins[2] = currentPosition.cols[mesVoisins.cases[2]].nb;
                    if (currentPosition.cols[mesVoisins.cases[3]].couleur != myColor &&
                        currentPosition.cols[mesVoisins.cases[3]].nb > 0)
                        tabVoisins[3] = currentPosition.cols[mesVoisins.cases[3]].nb;
                    MinTailleAdverse = DonneLeMin(tabVoisins, 4);
                    taille = 4;
                    //printf("Mintailleadverse : %d et Somme tour avec le min: %d\n", MinTailleAdverse,currentPosition.cols[o].nb + currentPosition.cols[d].nb + MinTailleAdverse);

                    if (MinTailleAdverse == 6 ||
                        ((currentPosition.cols[i].nb + MinTailleAdverse) >=
                         5))//si égal à 0 c'est que les voisins sont de ma couleur OU que ma taille + la taille de la destination + la plus petite tour adverse supérieure ou égal à 5 (cela vet dire que si je joue ce coup, ses tours voisines sont trop grandes pour prendre ma tour)
                    {
                        //La position est Bonne!
                        if (currentPosition.cols[i].nb == 4) {
                            SCORE -= SCORE_tour_voisin_notre_couleur_4;
                            printf("j'ajoute %d points car tour certaine avec 4 voisins à la case\n",
                                   SCORE_tour_voisin_notre_couleur_4);
                        } else {
                            SCORE -= SCORE_tour_voisin_notre_couleur_inferieur4;
                            printf("j'ajoute %d points car tour certaine avec 4 voisins à la case\n",
                                   SCORE_tour_voisin_notre_couleur_inferieur4);
                        }
                    }
                    break;
                case 5:
                    //todo:prendre la tour et la mettre sur un pion adverse si on peux
                    if (currentPosition.cols[mesVoisins.cases[0]].couleur != myColor &&
                        currentPosition.cols[mesVoisins.cases[0]].nb > 0)
                        tabVoisins[0] = currentPosition.cols[mesVoisins.cases[0]].nb;
                    if (currentPosition.cols[mesVoisins.cases[1]].couleur != myColor &&
                        currentPosition.cols[mesVoisins.cases[1]].nb > 0)
                        tabVoisins[1] = currentPosition.cols[mesVoisins.cases[1]].nb;
                    if (currentPosition.cols[mesVoisins.cases[2]].couleur != myColor &&
                        currentPosition.cols[mesVoisins.cases[2]].nb > 0)
                        tabVoisins[2] = currentPosition.cols[mesVoisins.cases[2]].nb;
                    if (currentPosition.cols[mesVoisins.cases[3]].couleur != myColor &&
                        currentPosition.cols[mesVoisins.cases[3]].nb > 0)
                        tabVoisins[3] = currentPosition.cols[mesVoisins.cases[3]].nb;
                    if (currentPosition.cols[mesVoisins.cases[4]].couleur != myColor &&
                        currentPosition.cols[mesVoisins.cases[4]].nb > 0)
                        tabVoisins[4] = currentPosition.cols[mesVoisins.cases[4]].nb;
                    taille = 5;
                    MinTailleAdverse = DonneLeMin(tabVoisins, 5);
                    //printf("Mintailleadverse : %d et Somme tour avec le min: %d\n", MinTailleAdverse,currentPosition.cols[o].nb + currentPosition.cols[d].nb + MinTailleAdverse);

                    if (MinTailleAdverse == 6 ||
                        ((currentPosition.cols[i].nb + MinTailleAdverse) >=
                         5))//si égal à 0 c'est que les voisins sont de ma couleur OU que ma taille + la taille de la destination + la plus petite tour adverse supérieure ou égal à 5 (cela vet dire que si je joue ce coup, ses tours voisines sont trop grandes pour prendre ma tour)
                    {
                        //La position est Bonne!
                        if (currentPosition.cols[i].nb == 4) {
                            SCORE -= SCORE_tour_voisin_notre_couleur_4;
                            printf("j'ajoute %d points car tour certaine avec 5 voisins à la case\n",
                                   SCORE_tour_voisin_notre_couleur_4);
                        } else {
                            SCORE -= SCORE_tour_voisin_notre_couleur_inferieur4;
                            printf("j'ajoute %d points car tour certaine avec 5 voisins à la case\n",
                                   SCORE_tour_voisin_notre_couleur_inferieur4);
                        }
                    }
                    break;
            }//todo: tour de 3 avec 2 voisins de notre couleur minimum

            /*if (currentPosition.cols[i].nb==3){
                //On regarde les voisins (sachant que le nb de voisins est donné dans le case du dessus)todo:si sup à 5..

            }*/
        }
	if (currentPosition.cols[i].nb==3){
		T_Voisins voisins = getVoisins(i);
		int pionMaCouleur=0;
		for (int p=0;p<=voisins.nb;p++){
			if (currentPosition.cols[voisins.cases[i]].couleur==myColor)
				pionMaCouleur++;

			if (pionMaCouleur>1){
				SCORE-=50;
			}
		}
	
	}
    }


    return SCORE;
}


T_Resultat algoMinimax(T_Position position, octet couleur,int profondeur,int profondeurMax) {
#ifdef __DEBUG_MINIMAX__
    printf(" algoMinimax - Entrée dans la fonction avec une profondeur de %d\n",profondeur);
#endif

    // Cas de base (fin de la récursivité)
    if( profondeur == profondeurMax) {
#ifdef __DEBUG_MINIMAX__
        printf(" algoMinimax - Fin de la récursivité (profondeur de %d)\n",profondeur);
#endif
        T_Resultat renvoi={-1,evaluation(position,couleur)};
        return renvoi;
    }



    T_ListeCoups listeCoups = getCoupsLegaux(position);
    int nombreCoups = listeCoups.nb;
    T_TypeNoeud type;
    T_Resultat meilleurResultat;


    // On se trouve dans une profondeur paire ou impaire ?
    if( position.trait == couleur) {
#ifdef __DEBUG_MINIMAX__
        printf(" algoMinimax - profondeur paire : type MAX\n");
#endif
        type=MAX;
        meilleurResultat.score=-10001;
        meilleurResultat.indiceCoup=-1;
    }
    else {
#ifdef __DEBUG_MINIMAX__
        printf(" algoMinimax - profondeur impaire : type MIN\n");
#endif
        type=MIN;
        meilleurResultat.score=10001;
        meilleurResultat.indiceCoup=-1;
    }


    T_Resultat evalResultat;

    // Parcours de la totalité des noeuds fils du noeud entré en paramètre.     (Cas général)
    for(int indexCoupActuel=0; indexCoupActuel<nombreCoups;indexCoupActuel++) {
        T_Position posAuxiliaire=jouerCoup(position,listeCoups.coups[indexCoupActuel].origine,listeCoups.coups[indexCoupActuel].destination);
        evalResultat=algoMinimax(posAuxiliaire,couleur,profondeur+1,profondeurMax);

        // partie MAX <=====> le meilleur résultat doit être le plus grand possible ||||||||| partie MIN <========> le "meilleur" résultat doit être le plus petit possible
        if( ( (type==MAX) && (evalResultat.score >= meilleurResultat.score) ) || ( ( type==MIN ) && ( evalResultat.score <= meilleurResultat.score ) ) ) {
#ifdef __DEBUG_MINIMAX__
            printf(" algoMinimax - parcours des noeuds fils (profondeur : %d) - on change le meilleur resultat à l'index %d\n",profondeur,indexCoupActuel);
#endif
            meilleurResultat.score=evalResultat.score;
            meilleurResultat.indiceCoup=indexCoupActuel;
        }
    }

#ifdef __DEBUG_MINIMAX__
    printf(" algoMinimax - Sortie de la fonction de profondeur %d avec l'index %d\n",profondeur,meilleurResultat.indiceCoup);
#endif
    return meilleurResultat;
}


