traiterJson({
"j":"Savalami",
"r":"exempt",
"ronde":13,
"resultat":"1-0",
"scoreJ":1,
"scoreJ5":0,
"scoreR":0,
"scoreR5":0,
"coups":[

]});