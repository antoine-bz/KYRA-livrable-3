traiterJson({
"j":"Airalam",
"r":"exempt",
"ronde":2,
"resultat":"1-0",
"scoreJ":1,
"scoreJ5":0,
"scoreR":0,
"scoreR5":0,
"coups":[

]});