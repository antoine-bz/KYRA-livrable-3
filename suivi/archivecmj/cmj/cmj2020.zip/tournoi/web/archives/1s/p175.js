traiterJson({
"j":"exempt",
"r":"Savalami",
"ronde":26,
"resultat":"0-1",
"scoreJ":0,
"scoreJ5":0,
"scoreR":1,
"scoreR5":0,
"coups":[

]});