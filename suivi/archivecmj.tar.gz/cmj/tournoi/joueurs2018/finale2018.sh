#! /bin/sh 

#	./joueur$numJ.exe "Joueur $numJ" &


./floyd2.exe "2018-floyd-v2" &
sleep 2 
./floyd.exe "2018-floyd" &
sleep 2
./naysson.exe "2018-naysson" & 
sleep 2
