#! /bin/sh 

#	./joueur$numJ.exe "Joueur $numJ" &


./bin/1-savalami.exe "Savalami" &
sleep 2
./bin/2-faceavalamer.exe "FaceAvalamer" &
sleep 2
./bin/3-avalamaFache.exe "Avalamafache" &
sleep 2
./bin/4-bahahavalam.exe "Bahahavalam" &
sleep 2
./bin/5-airalam.exe "Airalam" &
sleep 2
./bin/6-swag.exe "Swag" &
sleep 2
./bin/7-patrickBalkalam.exe "PatrickBalkalam" &
sleep 2
./bin/8-AvalamKedavra.exe "AvalamKedavra" &
sleep 2
./bin/9-AvalamCorp.exe "AvalamCorp" &
sleep 2
./bin/10-avalamHub.exe  "AvalamHub" &
sleep 2
./bin/11-hakunamavalam.exe "Hakunamavalam" &
sleep 2
./bin/12-sidAvalam.exe "SidAvalam" &
sleep 2
./bin/13-coronAvalam.exe "CoronAvalam" &
sleep 2
./bin/3-avalam2i-2.exe "2019-Avalam2i" &
sleep 2
./bin/5-vroum-2.exe "2019-Vroum" &
sleep 2
./bin/9-mark5.exe "2019-Mark5" &
sleep 2
./bin/14-kantaou2i-blitz.exe "2019-Kantaou2i" &
sleep 2
#./bin/alexandre.exe "2019-Alexandre" & 
#sleep 2
#./bin/kantalam2i-2.exe "2019-Kantalam2i-v2" & 
#sleep 2
./bin/kantalam2i-blitz.exe "2019-Kantalam2i" & 



