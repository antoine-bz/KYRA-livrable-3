#! /bin/sh 

#	./joueur$numJ.exe "Joueur $numJ" &

./bin/3-avalam2i-2.exe "2019-Avalam2i" &
sleep 2
#./bin/5-vroum-2.exe "2019-Vroum" &
#sleep 2
#./bin/9-mark5.exe "2019-Mark5" &
#sleep 2
./bin/14-kantaou2i-2.exe "2019-Kantaou2i" &
sleep 2
./bin/alexandre.exe "2019-Alexandre" & 
sleep 2
./bin/kantalam2i-2.exe "2019-Kantalam2i-v2" & 
sleep 2
./bin/kantalam2i.exe "2019-Kantalam2i" & 
