#! /bin/sh 

#	./joueur$numJ.exe "Joueur $numJ" &


./bin/floyd2.exe "2018-floyd-v2" &
sleep 2 
./bin/floyd.exe "2018-floyd" &
sleep 2
./bin/naysson.exe "2018-naysson" & 
sleep 2
