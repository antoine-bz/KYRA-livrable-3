#! /bin/sh 

#	./joueur$numJ.exe "Joueur $numJ" &


./bin/3-avalamaFache.exe "Avalamafache" &
sleep 2
./bin/7-patrickBalkalam.exe "PatrickBalkalam" &
sleep 2
./bin/hakunamavalam2.exe "Hakunamavalam2" &
sleep 2
./bin/13-coronAvalam.exe "CoronAvalam" &



