#! /bin/sh 

#	./joueur$numJ.exe "Joueur $numJ" &

./3-avalam2i-2.exe "2019-Avalam2i" &
sleep 2
./5-vroum-2.exe "2019-Vroum" &
sleep 2
./9-mark5.exe "2019-Mark5" &
sleep 2
./14-kantaou2i-2.exe "2019-Kantaou2i" &
sleep 2
./alexandre.exe "2019-Alexandre" & 
sleep 2
./kantalam2i-2.exe "2019-Kantalam2i-v2" & 
sleep 2
./kantalam2i.exe "2019-Kantalam2i" & 
