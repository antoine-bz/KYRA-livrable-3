#! /bin/sh 

#	./joueur$numJ.exe "Joueur $numJ" &

./1-avaltoname.exe "2019-Aval(ton)ame" &
sleep 2
./2-legende.exe "2019-Legende" &
sleep 2
./3-avalam2i.exe "2019-Avalam2i" &
sleep 2
./4-yazur.exe "2019-Yazur" &
sleep 2
./5-vroum.exe "2019-Vroum" &
sleep 2
./6-alexa.exe "2019-Alexa" &
sleep 2
./7-aya.exe "2019-Aya" &
sleep 2
./8-botabdul.exe "2019-Botabdul" &
sleep 2
./9-mark4.exe "2019-Mark4" &
sleep 2
./10-chomage.exe "2019-Chomage" &
sleep 2
./11-neotheone.exe "2019-Neotheone" &
sleep 2
./12-shao.exe "2019-Shao" &
sleep 2
./13-ig22qi.exe "2019-IG22QI" &
sleep 2
./14-kantaou2i.exe "2019-Kantaou2i" &
sleep 2
./15-binks.exe "2019-Binks" &
sleep 2
./16-jarvis.exe "2019-Jarvis" &
sleep 2
./17-tsavalam.exe "2019-T-savalam" &
sleep 2
./alexandre.exe "2019-Alexandre" & 
sleep 2
./kantalam2i-2.exe "2019-Kantalam2i-v2" & 
sleep 2
./kantalam2i.exe "2019-Kantalam2i" & 
