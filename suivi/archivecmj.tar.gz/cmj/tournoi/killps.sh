ps u | grep bin | cut -d  -f2 | xargs kill 
