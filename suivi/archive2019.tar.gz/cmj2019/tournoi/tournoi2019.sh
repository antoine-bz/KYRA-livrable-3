#! /bin/sh 

#	./joueur$numJ.exe "Joueur $numJ" &

./bin/1-avaltoname.exe "Aval(ton)ame" &
sleep 2
./bin/2-legende.exe "Legende" &
sleep 2
./bin/3-avalam2i.exe "Avalam2i" &
sleep 2
./bin/4-yazur.exe "Yazur" &
sleep 2
./bin/5-vroum.exe "Vroum" &
sleep 2
./bin/6-alexa.exe "Alexa" &
sleep 2
./bin/7-aya.exe "Aya" &
sleep 2
./bin/8-botabdul.exe "Botabdul" &
sleep 2
./bin/9-mark4.exe "Mark4" &
sleep 2
./bin/10-chomage.exe "Chomage" &
sleep 2
./bin/11-neotheone.exe "Neotheone" &
sleep 2
./bin/12-shao.exe "Shao" &
sleep 2
./bin/13-ig22qi.exe "IG22QI" &
sleep 2
./bin/14-kantaou2i.exe "Kantaou2i" &
sleep 2
./bin/15-binks.exe "Binks" &
sleep 2
./bin/16-jarvis.exe "Jarvis" &
sleep 2
./bin/17-tsavalam.exe "T-savalam" &
#sleep 2
#./bin/floyd.exe "Floyd" &
#sleep 2
#./bin/floyd2.exe "Floyd2" &
#sleep 2
#./bin/naysson.exe "Naysson" &
#./bin/3-avalam2i-2.exe "Avalam2i" &
#sleep 2
#./bin/5-vroum-2.exe "Vroum" &
#sleep 2
#./bin/9-mark5.exe "Mark5" &
#sleep 2
#./bin/14-kantaou2i-2.exe "Kantaou2i" &
#sleep 2
#./bin/kantalam2i.exe "Kantalam2i" &
#sleep 2


