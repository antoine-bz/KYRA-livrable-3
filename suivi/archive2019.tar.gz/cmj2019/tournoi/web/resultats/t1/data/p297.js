traiterJson({
"j":"exempt",
"r":"Aval(ton)ame",
"ronde":34,
"resultat":"0-1",
"scoreJ":0,
"scoreJ5":0,
"scoreR":1,
"scoreR5":0,
"coups":[

]});