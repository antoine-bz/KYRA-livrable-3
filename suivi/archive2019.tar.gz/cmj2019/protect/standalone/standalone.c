#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <avalam.h>
#include <topologie.h>

#ifndef DEFAULT_JSON_FILE
	#define DEFAULT_JSON_FILE "./web/data/refresh-data.js"
#endif 

void writePos(char * filename, T_Position p) ; 

int main(int argc, char ** argv){
	int numCase, numCaseD; 
	T_Score s ; 

	// on peut fournir le nom du fichier en ligne de commande 
	// sinon, on utilisera un nom de fichier par défaut, dans le répertoire courant
	char * filename; 

	if (argc == 2) filename = argv[1];
	else filename  = DEFAULT_JSON_FILE;

	printf("Utilisation du fichier %s\n",filename);
	printf("Continuer ?"); getchar();

	T_Position p = getPositionInitiale();
	//afficherPosition(p);
	writePos(filename, p);
	
	T_ListeCoups l = getCoupsLegaux(p);
	//afficherListeCoups(l);

	while(l.nb > 0) {
		system("clear");

		s = evaluerScore(p); 
		afficherScore(s);

		printf("Trait aux %ss :\n", COLNAME(p.trait)); 

		//afficherListeCoups(l);

		printf("\tcaseO ? : "); 
		scanf("%d",&numCase);

		printf("\tcaseD ? : "); 
		scanf("%d",&numCaseD);

		//numCase = l.coups[0].origine; 			
		//numCaseD = l.coups[0].destination;
		//sleep(2); 

		printf("\tOn joue %d -> %d\n", numCase, numCaseD); 
		p = jouerCoup(p, numCase,numCaseD); 
		//afficherPosition(p);
		writePos(filename, p);

		l = getCoupsLegaux(p);
		
		
	}

	printf("Partie finie !\n");
	s = evaluerScore(p); 
	printf("score : %d (%d) - %d (%d) ",s.nbJ, s.nbJ5, s.nbR, s.nbR5); 

	if ( s.nbJ > s.nbR) printf("Jaunes gagnent\n");
	else if ( s.nbR > s.nbJ) printf("Rouges gagnent\n");
	else if ( s.nbJ5 > s.nbR5) printf("Jaunes gagnent\n");
	else if ( s.nbR5 > s.nbJ5) printf("Rouges gagnent\n");
	else printf("égalité\n");

}



void writePos(char * filename, T_Position p) {
	FILE * fp; 
	int i;

	T_Score s = evaluerScore(p); 


	// Le fichier ne devrait-il pas être préfixé par le PID du process ? 
	// On devrait lui faire porter le nom du groupe, passé en ligne de commandes
	fp = fopen(filename,"w"); 

	// On écrit le trait 
	fprintf(fp, "traiterJson({\n%s:%d,\n",STR_TURN,p.trait); 

	// On écrit les scores
	fprintf(fp, "%s:%d,\n",STR_SCORE_J,s.nbJ); 
	fprintf(fp, "%s:%d,\n",STR_SCORE_J5,s.nbJ5); 
	fprintf(fp, "%s:%d,\n",STR_SCORE_R,s.nbR); 
	fprintf(fp, "%s:%d,\n",STR_SCORE_R5,s.nbR5);



	// Les colonnes // attention aux "," ?
	fprintf(fp, "%s:[\n",STR_COLS);

	// première 
	fprintf(fp, "\t{%s:%d, %s:%d}",STR_NB,p.cols[0].nb, STR_COULEUR,p.cols[0].couleur); 	

	// autres
	for(i=1;i<NBCASES;i++) {
		fprintf(fp, ",\n\t{%s:%d, %s:%d}",STR_NB,p.cols[i].nb, STR_COULEUR,p.cols[i].couleur); 	
	}
	fprintf(fp,"\n]\n"); // avec ou sans "," ? 

	fprintf(fp,"});");

	fclose(fp);
}







